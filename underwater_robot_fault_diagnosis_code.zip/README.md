# 水下机器人推进器两阶段故障诊断系统
# Two-Stage Fault Diagnosis for Underwater Robot Thrusters

## 代码文件说明 / Code Description

| 文件 | 说明 |
|------|------|
| custom_kan.py | Taylor-KAN自定义层（GPU原生，无需外部编译） |
| unified_data.py | 统一数据加载器（整机数据+推进器数据） |
| integrated_kan_diagnoser.py | 集成KAN双分支诊断网络架构 |
| train_integrated_final.py | 两阶段训练主脚本（最终版，推荐使用） |
| thruster_robot_train_v2.py | 推进器专项训练脚本v2（100%准确率） |
| thruster_robot_data_v2.py | 推进器数据特征提取v2（166维特征） |

## 运行说明 / How to Run

`ash
# 两阶段集成训练（推荐）
python train_integrated_final.py

# 仅推进器诊断
python thruster_robot_train_v2.py
`

## 依赖环境 / Requirements
- Python >= 3.8
- PyTorch >= 1.12 (with CUDA support)
- numpy, pandas, scikit-learn, matplotlib, seaborn, openpyxl

## 数据路径 / Data Paths
- 整机数据: G:/实验数据/0_水池故障模拟实验/Dataset/Tr|Te
- 推进器数据: E:/范小龙/数据/数据/定向数据 + 手柄前推数据

## 结果 / Results
- Stage 1 (系统级故障检测): 100.0% accuracy, 8 classes, 39,676 samples
- Stage 2 (推进器级定位): 100.0% accuracy + 100.0% bitmap, 8 classes, 337 samples
