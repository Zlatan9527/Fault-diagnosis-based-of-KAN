"""
推进器故障诊断 KAN 模型
======================
基于 pykan-master 中的 KANLayer 和 MultKAN 构建分类网络。
"""

import sys
import os
sys.path.insert(0, 'E:/KAN/pykan-master')

import torch
import torch.nn as nn
import numpy as np
from typing import List, Optional

# ─── 尝试导入 KAN ─────────────────────────────────────────────────────────────
try:
    from kan import KAN
    HAS_KAN = True
    print("[KAN] 成功导入 pykan KAN")
except Exception as e:
    HAS_KAN = False
    print(f"[KAN] 导入失败: {e}，将使用 MLP 替代")


# ─── MLP 替代实现（当 KAN 不可用时） ─────────────────────────────────────────

class MLPBlock(nn.Module):
    """带 BatchNorm + Dropout 的 MLP 块"""
    def __init__(self, in_dim, out_dim, dropout=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.BatchNorm1d(out_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
    def forward(self, x):
        return self.net(x)


class ThrusterFaultMLP(nn.Module):
    """MLP 替代模型（与 KAN 接口相同）"""
    def __init__(self, input_dim: int, num_classes: int = 8,
                 hidden_dims: List[int] = None, dropout: float = 0.2):
        super().__init__()
        if hidden_dims is None:
            hidden_dims = [128, 64, 32]

        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.append(MLPBlock(prev, h, dropout))
            prev = h
        layers.append(nn.Linear(prev, num_classes))
        self.net = nn.Sequential(*layers)
        self.input_dim = input_dim
        self.num_classes = num_classes

    def forward(self, x):
        return self.net(x)


# ─── KAN 分类模型 ─────────────────────────────────────────────────────────────

class ThrusterFaultKAN(nn.Module):
    """
    推进器故障诊断 KAN 分类模型。

    先用 MLP 主干降维，再接 KAN 做最终分类（减少 KAN 的输入维度以保证稳定性）。
    """
    def __init__(self, input_dim: int, num_classes: int = 8,
                 kan_width: List[int] = None,
                 mlp_hidden: int = 64,
                 grid: int = 5, k: int = 3,
                 device: str = 'cpu'):
        super().__init__()
        self.input_dim  = input_dim
        self.num_classes = num_classes
        self.device_name = device

        # MLP 前置降维
        self.mlp_encoder = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.BatchNorm1d(128),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(128, mlp_hidden),
            nn.BatchNorm1d(mlp_hidden),
            nn.GELU(),
            nn.Dropout(0.1),
        )

        # KAN 分类头
        if kan_width is None:
            kan_width = [mlp_hidden, 32, num_classes]
        else:
            kan_width = [mlp_hidden] + kan_width + [num_classes]

        if HAS_KAN:
            try:
                self.kan_head = KAN(
                    width=kan_width,
                    grid=grid,
                    k=k,
                    device=device,
                    auto_save=False,
                    first_init=True,
                    seed=42,
                )
                self.use_kan = True
                print(f"[KAN] KAN head 初始化成功: {kan_width}")
            except Exception as e:
                print(f"[KAN] KAN head 初始化失败: {e}，使用 MLP head")
                self.kan_head = self._build_mlp_head(kan_width)
                self.use_kan = False
        else:
            self.kan_head = self._build_mlp_head(kan_width)
            self.use_kan = False

    def _build_mlp_head(self, width: List[int]) -> nn.Module:
        layers = []
        for i in range(len(width) - 1):
            layers.append(nn.Linear(width[i], width[i+1]))
            if i < len(width) - 2:
                layers.append(nn.GELU())
        return nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.mlp_encoder(x)
        if self.use_kan:
            try:
                logits = self.kan_head(feat)
            except Exception:
                logits = self.kan_head(feat) if hasattr(self.kan_head, 'net') \
                         else nn.functional.linear(feat, torch.zeros(self.num_classes, feat.shape[-1]))
        else:
            logits = self.kan_head(feat)
        return logits

    def get_feature(self, x: torch.Tensor) -> torch.Tensor:
        """提取中间特征（用于可视化）"""
        with torch.no_grad():
            return self.mlp_encoder(x)


# ─── 工厂函数 ─────────────────────────────────────────────────────────────────

def create_model(input_dim: int,
                 num_classes: int = 8,
                 arch: str = 'kan',
                 device: str = 'cpu') -> nn.Module:
    """
    创建推进器故障诊断模型。

    Args:
        arch: 'kan' | 'mlp'
    """
    if arch == 'kan' and HAS_KAN:
        model = ThrusterFaultKAN(
            input_dim=input_dim,
            num_classes=num_classes,
            mlp_hidden=64,
            grid=5, k=3,
            device=device,
        )
    else:
        model = ThrusterFaultMLP(
            input_dim=input_dim,
            num_classes=num_classes,
            hidden_dims=[128, 64, 32],
        )
    return model.to(device)


if __name__ == '__main__':
    m = create_model(input_dim=96, num_classes=8)
    x = torch.randn(4, 96)
    out = m(x)
    print(f"输出形状: {out.shape}")  # (4, 8)
