"""
推进器故障诊断数据加载与预处理模块
=====================================
支持两类数据集：
  - 0_水池故障模拟实验: 列 [v, f, c, s]
  - 1_故障仿真模型:     列 [v, v_r, f, c, s]

故障类别（8类）:
  0: normal       正常
  1: cur_sensor_0 电流传感器故障
  2: dr_broken    驱动器断路
  3: dr_short     驱动器短路
  4: lost         推力损失
  5: m_locked     电机锁定
  6: p_locked     桨叶锁定
  7: winding      绕组故障
"""

import os
import glob
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from scipy import signal
from typing import Tuple, List, Optional, Dict
import warnings
warnings.filterwarnings('ignore')


# ─── 类别映射 ────────────────────────────────────────────────────────────────

FAULT_CLASSES = {
    'normal':       0,
    'cur_sensor_0': 1,
    'dr_broken':    2,
    'dr_short':     3,
    'lost':         4,
    'm_locked':     5,
    'p_locked':     6,
    'winding':      7,
}
CLASS_NAMES = {v: k for k, v in FAULT_CLASSES.items()}
NUM_CLASSES  = len(FAULT_CLASSES)


# ─── 时频特征提取 ─────────────────────────────────────────────────────────────

def extract_time_features(seg: np.ndarray) -> np.ndarray:
    """
    从一个信号片段中提取时域统计特征。
    输入 seg: (T, C) — T个时间步, C个通道
    返回: 1D 特征向量
    """
    feats = []
    for ch in range(seg.shape[1]):
        x = seg[:, ch]
        feats += [
            np.mean(x),                            # 均值
            np.std(x),                             # 标准差
            np.max(np.abs(x)),                     # 峰值
            np.sqrt(np.mean(x ** 2)),              # 均方根
            np.mean(np.abs(x)),                    # 平均绝对值
            np.max(np.abs(x)) / (np.sqrt(np.mean(x ** 2)) + 1e-8),  # 峰值因子
            np.sqrt(np.mean(x ** 2)) / (np.mean(np.abs(x)) + 1e-8), # 波形因子
            np.max(np.abs(x)) / (np.mean(np.abs(x)) + 1e-8),        # 脉冲因子
            np.mean((x - np.mean(x)) ** 3) / (np.std(x) ** 3 + 1e-8),  # 偏度
            np.mean((x - np.mean(x)) ** 4) / (np.std(x) ** 4 + 1e-8),  # 峭度
        ]
    return np.array(feats, dtype=np.float32)


def extract_freq_features(seg: np.ndarray, fs: float = 100.0) -> np.ndarray:
    """
    从一个信号片段中提取频域统计特征。
    输入 seg: (T, C)
    返回: 1D 特征向量
    """
    feats = []
    for ch in range(seg.shape[1]):
        x = seg[:, ch]
        f, psd = signal.welch(x, fs=fs, nperseg=min(len(x), 64))
        psd_sum = np.sum(psd) + 1e-8
        # 归一化功率谱
        psd_norm = psd / psd_sum
        feats += [
            np.sum(psd),                                               # 总功率
            np.sum(f * psd_norm),                                      # 平均频率
            np.sqrt(np.sum((f ** 2) * psd_norm)),                      # 均方根频率
            np.sqrt(np.sum(((f - np.sum(f * psd_norm)) ** 2) * psd_norm)),  # 频率标准差
            np.max(psd),                                               # 峰值功率
            f[np.argmax(psd)],                                         # 主频率
        ]
    return np.array(feats, dtype=np.float32)


def extract_features(seg: np.ndarray, fs: float = 100.0,
                     use_raw: bool = True,
                     use_time: bool = True,
                     use_freq: bool = True) -> np.ndarray:
    """
    综合特征提取：可选时域 + 频域 + 原始信号（展平）
    """
    parts = []
    if use_raw:
        parts.append(seg.flatten().astype(np.float32))
    if use_time:
        parts.append(extract_time_features(seg))
    if use_freq:
        parts.append(extract_freq_features(seg, fs=fs))
    return np.concatenate(parts)


# ─── CSV 读取 ─────────────────────────────────────────────────────────────────

def read_csv_file(fpath: str) -> Optional[np.ndarray]:
    """
    读取单个CSV文件，自动识别列数并返回 numpy 数组 (T, C)。
    支持 4列(v,f,c,s) 和 5列(v,v_r,f,c,s) 两种格式。
    """
    try:
        df = pd.read_csv(fpath)
        df = df.apply(pd.to_numeric, errors='coerce').dropna()
        if df.shape[1] == 4:
            # 实验数据: v, f, c, s → 取前3列作为信号特征
            arr = df.iloc[:, :3].values.astype(np.float32)
        elif df.shape[1] == 5:
            # 仿真数据: v, v_r, f, c, s → 取前4列
            arr = df.iloc[:, :4].values.astype(np.float32)
        else:
            arr = df.values.astype(np.float32)
        return arr
    except Exception as e:
        print(f"[警告] 读取 {fpath} 失败: {e}")
        return None


# ─── 滑动窗口分割 ─────────────────────────────────────────────────────────────

def sliding_window(data: np.ndarray,
                   window_size: int = 200,
                   step: int = 100) -> List[np.ndarray]:
    """
    对时序数据进行滑动窗口分割。
    返回: list of (window_size, C) 数组
    """
    segments = []
    T = data.shape[0]
    if T < window_size:
        # 补零到 window_size
        pad = np.zeros((window_size - T, data.shape[1]), dtype=np.float32)
        segments.append(np.vstack([data, pad]))
        return segments
    for start in range(0, T - window_size + 1, step):
        seg = data[start: start + window_size]
        segments.append(seg)
    return segments


# ─── 数据集构建 ───────────────────────────────────────────────────────────────

def load_dataset_from_dir(
    data_dir: str,
    split: str = 'Tr',
    window_size: int = 200,
    step: int = 100,
    feature_mode: str = 'stat',   # 'raw' | 'stat' | 'all'
    fs: float = 100.0,
    valid_classes: Optional[List[str]] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    从数据集目录批量加载数据。

    Args:
        data_dir   : 数据集根目录，下含 Tr/ 或 Te/ 子目录
        split      : 'Tr'（训练）或 'Te'（测试）
        window_size: 滑动窗口大小
        step       : 滑动步长
        feature_mode: 特征提取模式
            'raw'  — 仅原始时序展平
            'stat' — 时域+频域统计特征（推荐，维度低）
            'all'  — 原始+统计混合
        fs         : 采样频率 (Hz)
        valid_classes: 仅加载指定类别，None 表示全部

    Returns:
        X: (N, feature_dim) float32
        y: (N,) int64
    """
    split_dir = os.path.join(data_dir, split)
    if not os.path.isdir(split_dir):
        raise FileNotFoundError(f"目录不存在: {split_dir}")

    X_list, y_list = [], []
    classes_found = sorted(os.listdir(split_dir))

    for cls_name in classes_found:
        if cls_name not in FAULT_CLASSES:
            continue
        if valid_classes and cls_name not in valid_classes:
            continue

        label = FAULT_CLASSES[cls_name]
        cls_dir = os.path.join(split_dir, cls_name)
        csv_files = glob.glob(os.path.join(cls_dir, '*.csv'))

        for fpath in csv_files:
            data = read_csv_file(fpath)
            if data is None or len(data) == 0:
                continue

            segments = sliding_window(data, window_size=window_size, step=step)
            for seg in segments:
                use_raw  = feature_mode in ('raw', 'all')
                use_time = feature_mode in ('stat', 'all')
                use_freq = feature_mode in ('stat', 'all')
                feat = extract_features(seg, fs=fs,
                                        use_raw=use_raw,
                                        use_time=use_time,
                                        use_freq=use_freq)
                X_list.append(feat)
                y_list.append(label)

    if len(X_list) == 0:
        raise RuntimeError(f"在 {split_dir} 中未找到任何有效数据！")

    X = np.stack(X_list, axis=0).astype(np.float32)
    y = np.array(y_list, dtype=np.int64)
    print(f"[{split}] 加载完毕: {X.shape[0]} 样本, 特征维度={X.shape[1]}, "
          f"类别分布: { {CLASS_NAMES[i]: int((y==i).sum()) for i in np.unique(y)} }")
    return X, y


# ─── PyTorch Dataset ─────────────────────────────────────────────────────────

class ThrusterDataset(Dataset):
    """推进器故障诊断 PyTorch Dataset"""

    def __init__(self, X: np.ndarray, y: np.ndarray,
                 scaler: Optional[StandardScaler] = None,
                 fit_scaler: bool = False):
        """
        Args:
            X          : (N, D) 特征矩阵
            y          : (N,)   标签
            scaler     : StandardScaler 实例（外部传入或 None）
            fit_scaler : 若 True，对 X 进行 fit_transform
        """
        if fit_scaler:
            if scaler is None:
                scaler = StandardScaler()
            X = scaler.fit_transform(X)
        elif scaler is not None:
            X = scaler.transform(X)

        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)
        self.scaler = scaler

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

    @property
    def feature_dim(self):
        return self.X.shape[1]


# ─── 便捷接口 ─────────────────────────────────────────────────────────────────

def build_dataloaders(
    data_dir: str,
    batch_size: int = 64,
    window_size: int = 200,
    step: int = 100,
    feature_mode: str = 'stat',
    fs: float = 100.0,
    valid_classes: Optional[List[str]] = None,
    num_workers: int = 0,
    seed: int = 42
) -> Tuple[DataLoader, DataLoader, StandardScaler, int]:
    """
    构建训练/测试 DataLoader。

    Returns:
        train_loader, test_loader, scaler, feature_dim
    """
    torch.manual_seed(seed)
    np.random.seed(seed)

    X_tr, y_tr = load_dataset_from_dir(data_dir, split='Tr',
                                        window_size=window_size, step=step,
                                        feature_mode=feature_mode, fs=fs,
                                        valid_classes=valid_classes)
    X_te, y_te = load_dataset_from_dir(data_dir, split='Te',
                                        window_size=window_size, step=step,
                                        feature_mode=feature_mode, fs=fs,
                                        valid_classes=valid_classes)

    # 用训练集拟合归一化
    scaler = StandardScaler()
    train_ds = ThrusterDataset(X_tr, y_tr, scaler=scaler, fit_scaler=True)
    test_ds  = ThrusterDataset(X_te, y_te, scaler=scaler, fit_scaler=False)

    train_loader = DataLoader(train_ds, batch_size=batch_size,
                              shuffle=True, num_workers=num_workers,
                              drop_last=False)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size,
                              shuffle=False, num_workers=num_workers)

    print(f"[DataLoader] 训练集: {len(train_ds)} 样本 | "
          f"测试集: {len(test_ds)} 样本 | 特征维度: {train_ds.feature_dim}")
    return train_loader, test_loader, scaler, train_ds.feature_dim


def build_kan_dataset(
    data_dir: str,
    window_size: int = 200,
    step: int = 100,
    feature_mode: str = 'stat',
    fs: float = 100.0,
    valid_classes: Optional[List[str]] = None,
    device: str = 'cpu'
) -> Tuple[Dict[str, torch.Tensor], StandardScaler, int]:
    """
    构建符合 MultKAN.fit() 接口的 dataset 字典。

    Returns:
        dataset = {'train_input': ..., 'train_label': ...,
                   'test_input':  ..., 'test_label': ...}
        scaler, feature_dim
    """
    X_tr, y_tr = load_dataset_from_dir(data_dir, split='Tr',
                                        window_size=window_size, step=step,
                                        feature_mode=feature_mode, fs=fs,
                                        valid_classes=valid_classes)
    X_te, y_te = load_dataset_from_dir(data_dir, split='Te',
                                        window_size=window_size, step=step,
                                        feature_mode=feature_mode, fs=fs,
                                        valid_classes=valid_classes)

    scaler = StandardScaler()
    X_tr = scaler.fit_transform(X_tr).astype(np.float32)
    X_te = scaler.transform(X_te).astype(np.float32)

    dataset = {
        'train_input': torch.tensor(X_tr, dtype=torch.float32).to(device),
        'train_label': torch.tensor(y_tr, dtype=torch.long).to(device),
        'test_input':  torch.tensor(X_te, dtype=torch.float32).to(device),
        'test_label':  torch.tensor(y_te, dtype=torch.long).to(device),
    }

    feature_dim = X_tr.shape[1]
    print(f"[KAN Dataset] 特征维度={feature_dim}, "
          f"训练={X_tr.shape[0]}, 测试={X_te.shape[0]}")
    return dataset, scaler, feature_dim


# ─── 调试入口 ─────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    DATA_ROOT = r'G:\实验数据\0_水池故障模拟实验_先看这里面的说明\Dataset'
    train_loader, test_loader, scaler, fdim = build_dataloaders(
        DATA_ROOT,
        batch_size=32,
        window_size=200,
        step=100,
        feature_mode='stat',
    )
    for x, y in train_loader:
        print(f"批次形状: x={x.shape}, y={y.shape}")
        break
