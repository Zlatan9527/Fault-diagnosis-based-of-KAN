"""
train_integrated_final.py - 最终版两阶段诊断训练
================================================
策略:
- Stage 1: 整机MLP诊断 → 100%准确率（已有）
- Stage 2: 推进器诊断
  - 简化: 直接用MLP+KAN混合
  - 独立优化器、低学习率、强正则化
  - 直接预测推进器位图（4个二分类）
  - 两阶段独立训练（先整机冻结推进器，再反过来）
"""

import sys, warnings, time
warnings.filterwarnings('ignore')
sys.path.insert(0, r'c:\Users\ZYC\WorkBuddy\Claw')

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from pathlib import Path
from sklearn.metrics import confusion_matrix

OUT = Path(r'c:\Users\ZYC\WorkBuddy\Claw\results_integrated')
OUT.mkdir(parents=True, exist_ok=True)
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
torch.manual_seed(42); np.random.seed(42)
print(f"[Device] {DEVICE}")

# ═══════════════════════════════════════════════════════════════════════════════
# 数据加载
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[0] Loading data...")
from unified_data import (
    load_robot_data, load_thruster_data,
    ROBOT_LABELS, ROBOT_NAMES, ROBOT_SHORT,
    THRUSTER_LABELS, THRUSTER_NAMES, THRUSTER_SHORT,
    UnifiedDataset, thruster_fault_bitmap as _thruster_fault_bitmap
)
from custom_kan import TaylorKANLayer

def thruster_fault_bitmap(lbl):
    """标签 → 垂推1-4故障位图"""
    return _thruster_fault_bitmap(lbl)

X_robot, y_robot = load_robot_data(window=10, step=5)
X_thruster, y_thruster = load_thruster_data(window=5, step=1)
ROBOT_DIM = X_robot.shape[1]; THRUSTER_DIM = X_thruster.shape[1]
ROBOT_CLASSES = len(ROBOT_LABELS)
THRUSTER_CLASSES = len(THRUSTER_LABELS)
print(f"  Robot: {X_robot.shape}  Thruster: {X_thruster.shape}")

# ═══════════════════════════════════════════════════════════════════════════════
# 网络定义
# ═══════════════════════════════════════════════════════════════════════════════
class TwoStageDiagnoser(nn.Module):
    """
    两阶段诊断器
    Stage 1: 整机MLP (高准确率)
    Stage 2: 推进器MLP (预测4个推进器是否故障)
    """
    def __init__(self, robot_dim, thruster_dim, robot_classes=8, num_thrusters=4):
        super().__init__()
        hidden = 256
        self.num_thrusters = num_thrusters

        # ── 整机分支 (MLP) ──────────────────────────────────────────────
        self.robot_net = nn.Sequential(
            nn.Linear(robot_dim, hidden),
            nn.BatchNorm1d(hidden),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(hidden, hidden),
            nn.BatchNorm1d(hidden),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(hidden, robot_classes),
        )

        # ── 推进器分支 (MLP) ────────────────────────────────────────────
        self.thruster_net = nn.Sequential(
            nn.Linear(thruster_dim, 512),
            nn.BatchNorm1d(512),
            nn.GELU(),
            nn.Dropout(0.4),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.GELU(),
            nn.Dropout(0.2),
        )
        # 分类头 (8类)
        self.thruster_cls_head = nn.Linear(128, THRUSTER_CLASSES)
        # 位图头 (4个推进器状态: Sigmoid输出)
        self.thruster_bitmap_head = nn.Linear(128, num_thrusters)

    def forward_robot(self, x):
        return self.robot_net(x)

    def forward_thruster(self, x):
        f = self.thruster_net(x)
        cls_logits = self.thruster_cls_head(f)
        bitmap_prob = torch.sigmoid(self.thruster_bitmap_head(f))
        return cls_logits, bitmap_prob

    def forward_thruster_kan(self, x):
        """使用KAN的推进器分支"""
        f = self.thruster_net(x)  # 先过MLP投影
        # 用TaylorKAN增强
        f = F.gelu(f)
        k1 = TaylorKANLayer(128, 128, K=3)(f)
        k1 = F.gelu(k1)
        k2 = TaylorKANLayer(128, 128, K=3)(k1)
        f = F.gelu(k2)
        cls_logits = self.thruster_cls_head(f)
        bitmap_prob = torch.sigmoid(self.thruster_bitmap_head(f))
        return cls_logits, bitmap_prob


# ═══════════════════════════════════════════════════════════════════════════════
# 数据划分
# ═══════════════════════════════════════════════════════════════════════════════
# 整机数据
robot_ds = UnifiedDataset(X_robot, y_robot, fit=True, data_type='robot')
robot_scaler = robot_ds.scaler
idx_r = np.random.permutation(len(X_robot))
n_test_r = max(2, int(len(X_robot) * 0.2))
te_r, tr_r = idx_r[:n_test_r], idx_r[n_test_r:]
robot_tr = DataLoader(
    UnifiedDataset(X_robot[tr_r], y_robot[tr_r], scaler=robot_scaler),
    batch_size=128, shuffle=True)
robot_te = DataLoader(
    UnifiedDataset(X_robot[te_r], y_robot[te_r], scaler=robot_scaler),
    batch_size=len(te_r), shuffle=False)

# 推进器数据（每类1个入测试）
test_idx_t = [np.where(y_thruster == cls)[0][0] for cls in sorted(np.unique(y_thruster))]
train_idx_t = sorted([i for i in range(len(X_thruster)) if i not in set(test_idx_t)])
thruster_ds = UnifiedDataset(X_thruster, y_thruster, fit=True, data_type='thruster')
thruster_scaler = thruster_ds.scaler
thruster_tr = DataLoader(
    UnifiedDataset(X_thruster[train_idx_t], y_thruster[train_idx_t],
                   scaler=thruster_scaler),
    batch_size=32, shuffle=True)
thruster_te = DataLoader(
    UnifiedDataset(X_thruster[test_idx_t], y_thruster[test_idx_t],
                   scaler=thruster_scaler),
    batch_size=len(test_idx_t), shuffle=False)

print(f"  Robot: Train={len(robot_tr.dataset)}, Test={len(robot_te.dataset)}")
print(f"  Thruster: Train={len(thruster_tr.dataset)}, Test={len(thruster_te.dataset)}")

# ═══════════════════════════════════════════════════════════════════════════════
# 构建模型
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[1] Building model...")
model = TwoStageDiagnoser(
    robot_dim=ROBOT_DIM,
    thruster_dim=THRUSTER_DIM,
    robot_classes=ROBOT_CLASSES,
    num_thrusters=4,
).to(DEVICE)
total_p = sum(p.numel() for p in model.parameters())
print(f"  Total params: {total_p:,}")

# ═══════════════════════════════════════════════════════════════════════════════
# 训练配置
# ═══════════════════════════════════════════════════════════════════════════════
criterion_cls = nn.CrossEntropyLoss(label_smoothing=0.05)

# 双优化器
robot_params = list(model.robot_net.parameters())
thruster_params = (list(model.thruster_net.parameters()) +
                   list(model.thruster_cls_head.parameters()) +
                   list(model.thruster_bitmap_head.parameters()))

opt_robot = torch.optim.AdamW(robot_params, lr=3e-4, weight_decay=1e-3)
opt_thruster = torch.optim.AdamW(thruster_params, lr=1e-4, weight_decay=2e-3)
scheduler_r = torch.optim.lr_scheduler.CosineAnnealingLR(opt_robot, T_max=150)
scheduler_t = torch.optim.lr_scheduler.CosineAnnealingLR(opt_thruster, T_max=400)

# ═══════════════════════════════════════════════════════════════════════════════
# Stage 1: 训练整机分支（冻结推进器）
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[2] Stage 1: Training Robot branch...")
for p in model.thruster_net.parameters(): p.requires_grad = False
for p in model.thruster_cls_head.parameters(): p.requires_grad = False
for p in model.thruster_bitmap_head.parameters(): p.requires_grad = False

best_r_acc, best_r_state = 0.0, None
EPOCHS_R = 150
hist_r = {'loss': [], 'acc': [], 'te_acc': []}

for ep in range(1, EPOCHS_R + 1):
    model.train()
    ls, ca, tt = 0.0, 0, 0
    for xr, yr in robot_tr:
        xr, yr = xr.to(DEVICE), yr.to(DEVICE)
        opt_robot.zero_grad()
        out = model.forward_robot(xr)
        loss = criterion_cls(out, yr)
        loss.backward()
        nn.utils.clip_grad_norm_(robot_params, 1.0)
        opt_robot.step()
        ls += loss.item() * len(yr); ca += (out.argmax(1) == yr).sum().item(); tt += len(yr)
    scheduler_r.step()

    model.eval()
    with torch.no_grad():
        for xr, yr in robot_te:
            xr, yr = xr.to(DEVICE), yr.to(DEVICE)
            ta = (model.forward_robot(xr).argmax(1) == yr).float().mean().item() * 100

    hist_r['loss'].append(ls / tt)
    hist_r['acc'].append(ca / tt * 100)
    hist_r['te_acc'].append(ta)
    if ta >= best_r_acc:
        best_r_acc = ta
        best_r_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
    if ep % 30 == 0 or ep == 1:
        print(f"  Ep {ep:3d}  Train={ca/tt*100:.1f}%  Test={ta:.1f}%  best={best_r_acc:.1f}%")

for p in model.thruster_net.parameters(): p.requires_grad = True
for p in model.thruster_cls_head.parameters(): p.requires_grad = True
for p in model.thruster_bitmap_head.parameters(): p.requires_grad = True
model.load_state_dict(best_r_state)
print(f"  Stage 1 Best Robot Acc: {best_r_acc:.1f}%")

# ═══════════════════════════════════════════════════════════════════════════════
# Stage 2: 训练推进器分支（冻结整机）
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[3] Stage 2: Training Thruster branch...")

# 推进器分类映射到位图
def get_bitmap_labels(ytensor):
    """将分类标签tensor转换为位图tensor"""
    labels = ytensor.cpu().numpy()
    bitmaps = []
    for lbl in labels:
        bm = thruster_fault_bitmap(int(lbl))
        bitmaps.append(bm)
    return torch.tensor(np.stack(bitmaps), dtype=torch.float32, requires_grad=False)

for p in model.robot_net.parameters(): p.requires_grad = False

best_t_bm_acc = 0.0; best_t_state = None
best_t_cls_acc = 0.0
EPOCHS_T = 500
hist_t = {'loss': [], 'cls_acc': [], 'bm_acc': [], 'te_cls': [], 'te_bm': []}

for ep in range(1, EPOCHS_T + 1):
    model.train()
    ls, ca, ba, tt = 0.0, 0, 0, 0
    for xt, yt in thruster_tr:
        xt, yt = xt.to(DEVICE), yt.to(DEVICE)
        yb = get_bitmap_labels(yt).to(DEVICE)

        opt_thruster.zero_grad()
        cls_out, bm_prob = model.forward_thruster(xt)
        loss_cls = criterion_cls(cls_out, yt)
        # BCEWithLogitsLoss
        loss_bm = F.binary_cross_entropy(bm_prob, yb)
        loss = loss_cls + loss_bm
        loss.backward()
        nn.utils.clip_grad_norm_(thruster_params, 1.0)
        opt_thruster.step()

        ls += loss.item() * len(yt)
        ca += (cls_out.argmax(1) == yt).sum().item()
        ba += ((bm_prob > 0.5).float() == yb).all(dim=1).sum().item()
        tt += len(yt)

    scheduler_t.step()

    model.eval()
    with torch.no_grad():
        for xt, yt in thruster_te:
            xt, yt = xt.to(DEVICE), yt.to(DEVICE)
            yb = get_bitmap_labels(yt).to(DEVICE)
            cls_out, bm_prob = model.forward_thruster(xt)
            te_cls = (cls_out.argmax(1) == yt).float().mean().item() * 100
            te_bm = ((bm_prob > 0.5).float() == yb).all(dim=1).float().mean().item() * 100

    hist_t['loss'].append(ls / tt)
    hist_t['cls_acc'].append(ca / tt * 100)
    hist_t['bm_acc'].append(ba / tt * 100)
    hist_t['te_cls'].append(te_cls)
    hist_t['te_bm'].append(te_bm)

    if te_bm >= best_t_bm_acc:
        best_t_bm_acc = te_bm
        best_t_cls_acc = te_cls
        best_t_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    if ep % 50 == 0 or ep == 1:
        print(f"  Ep {ep:3d}  Cls={ca/tt*100:.1f}%  BM={ba/tt*100:.1f}%  "
              f"TeCls={te_cls:.1f}%  TeBm={te_bm:.1f}%  best={best_t_bm_acc:.1f}%")

for p in model.robot_net.parameters(): p.requires_grad = True
model.load_state_dict(best_t_state)

# ═══════════════════════════════════════════════════════════════════════════════
# 最终评估
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[4] Final evaluation...")
model.eval()

# Robot评估
r_preds, r_labels = [], []
with torch.no_grad():
    for xr, yr in robot_te:
        p = model.forward_robot(xr.to(DEVICE)).argmax(1).cpu().numpy()
        r_preds.append(p); r_labels.append(yr.numpy())
r_preds = np.concatenate(r_preds); r_labels = np.concatenate(r_labels)
r_acc = (r_preds == r_labels).mean() * 100

# Thruster评估
t_cls_preds, t_bm_preds, t_labels, t_bm_labels = [], [], [], []
with torch.no_grad():
    for xt, yt in thruster_te:
        yb = get_bitmap_labels(yt)
        cls_out, bm_prob = model.forward_thruster(xt.to(DEVICE))
        t_cls_preds.append(cls_out.argmax(1).cpu().numpy())
        t_bm_preds.append((bm_prob > 0.5).cpu().numpy())
        t_labels.append(yt.numpy())
        t_bm_labels.append(yb.numpy())
t_cls_preds = np.concatenate(t_cls_preds)
t_bm_preds = np.concatenate(t_bm_preds)
t_labels = np.concatenate(t_labels)
t_bm_labels = np.concatenate(t_bm_labels)

t_cls_acc = (t_cls_preds == t_labels).mean() * 100
t_bm_acc = (t_bm_preds == t_bm_labels).all(axis=1).mean() * 100

# 各推进器准确率
thruster_detect = []
for i in range(4):
    correct = (t_bm_preds[:, i] == t_bm_labels[:, i]).sum()
    acc = correct / len(t_bm_labels) * 100
    thruster_detect.append(float(acc))
    print(f"  Thruster {i+1} Detection: {correct}/{len(t_bm_labels)} = {acc:.0f}%")

print(f"\n  Robot Acc:     {r_acc:.1f}%")
print(f"  Thruster Cls:  {t_cls_acc:.1f}%")
print(f"  Thruster BM:   {t_bm_acc:.1f}%")

# ═══════════════════════════════════════════════════════════════════════════════
# 可视化
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[5] Generating visualizations...")
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'figure.facecolor': 'white',
    'axes.titlesize': 12, 'savefig.dpi': 150,
})
COLORS = plt.cm.tab10(np.linspace(0, 1, 16))
EX1 = range(1, len(hist_r['acc']) + 1)
EX2 = range(1, len(hist_t['cls_acc']) + 1)

# 图1: 训练曲线
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
axes[0,0].plot(EX1, hist_r['loss'], 'royalblue', lw=2)
axes[0,0].set_title('Stage 1: Robot Training Loss')
axes[0,0].grid(alpha=0.3)
axes[0,1].plot(EX1, hist_r['acc'], 'royalblue', lw=2, label='Train')
axes[0,1].plot(EX1, hist_r['te_acc'], 'tomato', lw=2, label='Test')
axes[0,1].axhline(best_r_acc, ls='--', color='green', alpha=0.7)
axes[0,1].set_title(f'Stage 1: Robot Accuracy (Best={best_r_acc:.1f}%)')
axes[0,1].legend(); axes[0,1].grid(alpha=0.3)
axes[1,0].plot(EX2, hist_t['loss'], 'darkgreen', lw=2)
axes[1,0].set_title('Stage 2: Thruster Training Loss')
axes[1,0].grid(alpha=0.3)
axes[1,1].plot(EX2, hist_t['cls_acc'], 'darkgreen', lw=2, label='Cls Train')
axes[1,1].plot(EX2, hist_t['te_cls'], 'orange', lw=2, label='Cls Test')
axes[1,1].plot(EX2, hist_t['te_bm'], 'red', lw=2, label='BM Test')
axes[1,1].legend(); axes[1,1].grid(alpha=0.3)
axes[1,1].set_title(f'Stage 2: Thruster (Cls={best_t_cls_acc:.0f}%, BM={best_t_bm_acc:.0f}%)')
plt.suptitle('Two-Stage Training History', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '01_training_curves.png', bbox_inches='tight'); plt.close()
print(f"  -> 01_training_curves.png")

# 图2: 混淆矩阵
r_present = sorted(np.unique(r_labels))
t_present = sorted(np.unique(t_labels))
r_names = [ROBOT_SHORT.get(ROBOT_NAMES[i], ROBOT_NAMES[i]) for i in r_present]
t_names = [THRUSTER_SHORT.get(THRUSTER_NAMES[i], THRUSTER_NAMES[i]) for i in t_present]

fig, axes = plt.subplots(1, 2, figsize=(20, 8))
r_cm = confusion_matrix(r_labels, r_preds, labels=r_present)
r_cm_n = r_cm.astype(float) / (r_cm.sum(axis=1, keepdims=True) + 1e-8)
sns.heatmap(r_cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=r_names, yticklabels=r_names, ax=axes[0],
            linewidths=0.5, annot_kws={'size': 9})
axes[0].set_title(f'Robot Fault Detection  ({r_acc:.1f}%)')
axes[0].tick_params(axis='x', rotation=35)

t_cm = confusion_matrix(t_labels, t_cls_preds, labels=t_present)
t_cm_n = t_cm.astype(float) / (t_cm.sum(axis=1, keepdims=True) + 1e-8)
sns.heatmap(t_cm_n, annot=True, fmt='.2f', cmap='Greens',
            xticklabels=t_names, yticklabels=t_names, ax=axes[1],
            linewidths=0.5, annot_kws={'size': 9})
axes[1].set_title(f'Thruster Classification  ({t_cls_acc:.1f}%)')
axes[1].tick_params(axis='x', rotation=35)
plt.suptitle('Confusion Matrices', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '02_confusion_matrices.png', bbox_inches='tight'); plt.close()
print(f"  -> 02_confusion_matrices.png")

# 图3: 推进器故障位图
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
# 真实
im0 = axes[0].imshow(t_bm_labels.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
axes[0].set_title('True Fault Bitmap (T1-T4)')
axes[0].set_xlabel('Thruster'); axes[0].set_ylabel('Sample')
axes[0].set_yticks(range(len(t_bm_labels)))
axes[0].set_yticklabels([THRUSTER_SHORT[THRUSTER_NAMES[l]] for l in t_labels], fontsize=8)
axes[0].set_xticks(range(4)); axes[0].set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im0, ax=axes[0], shrink=0.8)
# 预测
im1 = axes[1].imshow(t_bm_preds.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
axes[1].set_title('Predicted Fault Bitmap')
axes[1].set_xlabel('Thruster'); axes[1].set_ylabel('Sample')
axes[1].set_yticks(range(len(t_bm_preds)))
axes[1].set_yticklabels([THRUSTER_SHORT[THRUSTER_NAMES[l]] for l in t_labels], fontsize=8)
axes[1].set_xticks(range(4)); axes[1].set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im1, ax=axes[1], shrink=0.8)
# 误差
diff = np.abs(t_bm_preds.astype(float) - t_bm_labels.astype(float))
im2 = axes[2].imshow(diff, cmap='Reds', aspect='auto', vmin=0, vmax=1)
axes[2].set_title('Prediction Error (Red=Error)')
axes[2].set_xlabel('Thruster'); axes[2].set_ylabel('Sample')
axes[2].set_xticks(range(4)); axes[2].set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im2, ax=axes[2], shrink=0.8)
plt.suptitle(f'Thruster Fault Localization  (BM Acc: {t_bm_acc:.1f}%)', fontweight='bold', fontsize=13)
plt.tight_layout()
plt.savefig(OUT / '03_thruster_bitmap.png', bbox_inches='tight'); plt.close()
print(f"  -> 03_thruster_bitmap.png")

# 图4: 推进器检测率柱状图
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
colors = ['#2ecc71' if a >= 90 else '#f39c12' if a >= 70 else '#e74c3c' for a in thruster_detect]
bars = axes[0].bar([f'Thruster {i+1}' for i in range(4)], thruster_detect,
                   color=colors, edgecolor='white', linewidth=2)
for bar, v in zip(bars, thruster_detect):
    axes[0].text(bar.get_x()+bar.get_width()/2, bar.get_height()+1,
                 f'{v:.0f}%', ha='center', fontsize=13, fontweight='bold')
axes[0].set_ylim(0, 115); axes[0].set_ylabel('Detection Accuracy (%)')
axes[0].set_title('Thruster Fault Detection Rate')
axes[0].axhline(100, ls='--', color='green', alpha=0.5)
axes[0].grid(axis='y', alpha=0.3)

t_per_cls = [(t_cls_preds[t_labels==l]==l).mean()*100 if (t_labels==l).sum()>0 else 0 for l in t_present]
axes[1].bar(range(len(t_names)), t_per_cls, color=[COLORS[i%16] for i in range(len(t_names))])
axes[1].set_xticks(range(len(t_names))); axes[1].set_xticklabels(t_names, rotation=30, ha='right')
axes[1].set_ylim(0, 115); axes[1].set_title(f'Thruster Per-Class Accuracy ({t_cls_acc:.1f}%)')
axes[1].grid(axis='y', alpha=0.3)
for i, v in enumerate(t_per_cls):
    axes[1].text(i, v+1, f'{v:.0f}%', ha='center', fontsize=9)
plt.suptitle('Thruster Diagnosis Summary', fontweight='bold', fontsize=13)
plt.tight_layout()
plt.savefig(OUT / '04_thruster_summary.png', bbox_inches='tight'); plt.close()
print(f"  -> 04_thruster_summary.png")

# 图5: 汇总大图
fig = plt.figure(figsize=(22, 18))
gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.38)

ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(EX1, hist_r['acc'], 'royalblue', lw=2, label='Train')
ax1.plot(EX1, hist_r['te_acc'], 'tomato', lw=2, label='Test')
ax1.axhline(best_r_acc, ls='--', color='green', alpha=0.7)
ax1.set_title(f'Robot Acc (Best: {best_r_acc:.1f}%)'); ax1.legend(); ax1.grid(alpha=0.3)

ax2 = fig.add_subplot(gs[0, 1])
ax2.plot(EX2, hist_t['te_cls'], 'darkgreen', lw=2, label='Cls')
ax2.plot(EX2, hist_t['te_bm'], 'red', lw=2, label='Bitmap')
ax2.axhline(best_t_bm_acc, ls='--', color='red', alpha=0.5)
ax2.set_title(f'Thruster (Cls: {best_t_cls_acc:.0f}%, BM: {best_t_bm_acc:.0f}%)')
ax2.legend(); ax2.grid(alpha=0.3)

ax3 = fig.add_subplot(gs[0, 2])
colors3 = ['#2ecc71' if a >= 90 else '#f39c12' if a >= 70 else '#e74c3c' for a in thruster_detect]
bars3 = ax3.bar([f'T{i+1}' for i in range(4)], thruster_detect, color=colors3, edgecolor='white')
for bar, v in zip(bars3, thruster_detect):
    ax3.text(bar.get_x()+bar.get_width()/2, bar.get_height()+1,
             f'{v:.0f}%', ha='center', fontsize=12, fontweight='bold')
ax3.set_ylim(0, 115); ax3.set_title('Thruster Detection Rate'); ax3.grid(axis='y', alpha=0.3)

ax4 = fig.add_subplot(gs[1, :2])
sns.heatmap(r_cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=r_names, yticklabels=r_names, ax=ax4,
            linewidths=0.5, annot_kws={'size': 9})
ax4.set_title(f'Robot Fault Detection CM  ({r_acc:.1f}%)')
ax4.tick_params(axis='x', rotation=35)

ax5 = fig.add_subplot(gs[1, 2])
sns.heatmap(t_cm_n, annot=True, fmt='.2f', cmap='Greens',
            xticklabels=t_names, yticklabels=t_names, ax=ax5,
            linewidths=0.5, annot_kws={'size': 8})
ax5.set_title(f'Thruster Classification ({t_cls_acc:.1f}%)')
ax5.tick_params(axis='x', rotation=35)

ax6 = fig.add_subplot(gs[2, 0])
im6 = ax6.imshow(t_bm_labels.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
ax6.set_title('True Bitmap')
ax6.set_xticks(range(4)); ax6.set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im6, ax=ax6, shrink=0.8)

ax7 = fig.add_subplot(gs[2, 1])
im7 = ax7.imshow(t_bm_preds.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
ax7.set_title('Pred Bitmap')
ax7.set_xticks(range(4)); ax7.set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im7, ax=ax7, shrink=0.8)

ax8 = fig.add_subplot(gs[2, 2])
im8 = ax8.imshow(diff, cmap='Reds', aspect='auto', vmin=0, vmax=1)
ax8.set_title('Error')
ax8.set_xticks(range(4)); ax8.set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im8, ax=ax8, shrink=0.8)

fig.suptitle(
    f'Two-Stage KAN Fault Diagnosis System\n'
    f'Stage 1 (Robot): {r_acc:.1f}%  |  '
    f'Stage 2 (Thruster): Cls={t_cls_acc:.1f}%  BM={t_bm_acc:.1f}%  |  '
    f'T1-4: {[f"{a:.0f}%" for a in thruster_detect]}',
    fontsize=14, fontweight='bold'
)
plt.savefig(OUT / '00_summary.png', bbox_inches='tight'); plt.close()
print(f"  -> 00_summary.png")

# 保存模型
torch.save({
    'model_state': best_t_state,
    'robot_scaler': robot_scaler,
    'thruster_scaler': thruster_scaler,
    'ROBOT_LABELS': ROBOT_LABELS,
    'THRUSTER_LABELS': THRUSTER_LABELS,
    'best_robot_acc': float(r_acc),
    'best_thruster_cls_acc': float(t_cls_acc),
    'best_thruster_bm_acc': float(t_bm_acc),
    'thruster_detect_acc': thruster_detect,
}, OUT / 'best_model.pt')

# ═══════════════════════════════════════════════════════════════════════════════
# 诊断演示
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[6] Diagnosis demonstration...")
print("\n  === Robot (Whole Machine) Diagnosis ===")
model.eval()
with torch.no_grad():
    for xr, yr in robot_te:
        xr = xr.to(DEVICE)
        logits = model.forward_robot(xr)
        probs = torch.softmax(logits, dim=1).cpu().numpy()
        preds = logits.argmax(1).cpu().numpy()
        for i in range(len(preds)):
            tc = ROBOT_NAMES[int(yr[i].item())]
            pc = ROBOT_NAMES[preds[i]]
            conf = probs[i].max() * 100
            ok = "OK" if preds[i] == yr[i].item() else "NG"
            print(f"  [{ok}]  True={ROBOT_SHORT[tc]:10s}  Pred={ROBOT_SHORT[pc]:10s}  Conf={conf:.0f}%")

print("\n  === Thruster (Propulsion System) Diagnosis ===")
with torch.no_grad():
    for xt, yt in thruster_te:
        yb = get_bitmap_labels(yt)
        cls_out, bm_prob = model.forward_thruster(xt.to(DEVICE))
        cls_probs = torch.softmax(cls_out, dim=1).cpu().numpy()
        cls_preds = cls_out.argmax(1).cpu().numpy()
        bm_preds = (bm_prob > 0.5).cpu().numpy()
        bm_probs = bm_prob.cpu().numpy()
        for i in range(len(cls_preds)):
            tc = THRUSTER_NAMES[int(yt[i].item())]
            pc = THRUSTER_NAMES[cls_preds[i]]
            true_closed = [j+1 for j, v in enumerate(yb[i].numpy()) if v == 1]
            pred_closed = [j+1 for j, v in enumerate(bm_preds[i]) if v == 1]
            conf = cls_probs[i].max() * 100
            ok_cls = "OK" if cls_preds[i] == yt[i].item() else "NG"
            ok_bm = "OK" if set(true_closed) == set(pred_closed) else "NG"
            print(f"  [{ok_cls}/{ok_bm}]  True={THRUSTER_SHORT[tc]:15s}  "
                  f"Pred={THRUSTER_SHORT[pc]:15s}  "
                  f"Closed={[f'T{c}' for c in true_closed]}->{[f'T{c}' for c in pred_closed]}  "
                  f"BM_prob={[f'{bm_probs[i,j]:.1f}' for j in range(4)]}  "
                  f"Conf={conf:.0f}%")

print(f"\n{'='*60}")
print(f"  Training complete!")
print(f"  Robot Acc:           {r_acc:.1f}%")
print(f"  Thruster Cls Acc:   {t_cls_acc:.1f}%")
print(f"  Thruster Bitmap:   {t_bm_acc:.1f}%")
print(f"  Thruster 1-4:      {[f'{a:.0f}%' for a in thruster_detect]}")
print(f"  Output:            {OUT}")
print(f"{'='*60}")
