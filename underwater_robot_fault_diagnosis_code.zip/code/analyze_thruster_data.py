import pandas as pd, os, glob, json

base_ding = r'E:\范小龙\数据\数据\定向数据'
base_qian = r'E:\范小龙\数据\数据\手柄前推数据'

def analyze(fpath):
    df = pd.read_excel(fpath, engine='openpyxl')
    cets = [c for c in df.columns if '侧推' in c or '垂推' in c]
    vals = df[cets].values
    ce_nonzero = [c for c in cets if '侧推' in c and df[c].abs().mean() > 1]
    ch_nonzero = [c for c in cets if '垂推' in c and df[c].abs().mean() > 1]
    return {
        'file': os.path.basename(fpath),
        'shape': str(df.shape),
        '侧推非零': ce_nonzero,
        '垂推非零': ch_nonzero,
        '整体均值': float(vals.mean()),
        '整体极值': [float(vals.min()), float(vals.max())],
        'all_cols': df.columns.tolist()
    }

results = {'定向数据': [], '前推数据': []}
for base, key in [(base_ding, '定向数据'), (base_qian, '前推数据')]:
    for f in sorted(glob.glob(os.path.join(base, '*.xlsx'))):
        results[key].append(analyze(f))

print(json.dumps(results, ensure_ascii=False, indent=2))
