"""
train_integrated_v2.py - 改进版两阶段诊断训练
==============================================
核心改进:
1. 分阶段训练：Stage1先训整机 → Stage2冻结后训推进器
2. 推进器直接预测位图：输出(4,) 垂推状态而非分类logits
3. 双优化器：各自独立学习率
4. 增强数据扩充：噪声+ dropout
"""

import sys, os, warnings, time
warnings.filterwarnings('ignore')
sys.path.insert(0, r'c:\Users\ZYC\WorkBuddy\Claw')

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from pathlib import Path
from sklearn.metrics import confusion_matrix

OUT = Path(r'c:\Users\ZYC\WorkBuddy\Claw\results_integrated')
OUT.mkdir(parents=True, exist_ok=True)
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
torch.manual_seed(42); np.random.seed(42)
print(f"[Device] {DEVICE}")

# ═══════════════════════════════════════════════════════════════════════════════
# 数据加载
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[0] Loading data...")
from unified_data import (
    load_robot_data, load_thruster_data,
    ROBOT_LABELS, ROBOT_NAMES, ROBOT_SHORT,
    THRUSTER_LABELS, THRUSTER_NAMES, THRUSTER_SHORT,
    UnifiedDataset, ROBOT_SYM
)

X_robot, y_robot = load_robot_data(window=10, step=5)
X_thruster, y_thruster = load_thruster_data(window=5, step=1)
ROBOT_DIM = X_robot.shape[1]; THRUSTER_DIM = X_thruster.shape[1]
ROBOT_CLASSES = len(ROBOT_LABELS)
THRUSTER_CLASSES = len(THRUSTER_LABELS)
print(f"  Robot: {X_robot.shape}  Thruster: {X_thruster.shape}")

# ═══════════════════════════════════════════════════════════════════════════════
# 改进的推进器标签：直接预测故障位图
# ═══════════════════════════════════════════════════════════════════════════════
def thruster_fault_bitmap(lbl):
    """标签 → 垂推1-4的故障位图 (1=故障, 0=正常)"""
    m = {
        0: [0,0,0,0],  # normal
        1: [1,0,0,0],  # fault_1
        2: [1,1,0,0],  # fault_12
        3: [1,0,1,0],  # fault_13
        4: [1,1,1,0],  # fault_123
        5: [1,0,0,0],  # push_normal
        6: [1,1,0,0],  # push_fault_12
        7: [1,0,1,0],  # push_fault_13
    }
    return np.array(m.get(lbl, [0,0,0,0]), dtype=np.float32)

# 构建立位图标签
y_thruster_bitmap = np.stack([thruster_fault_bitmap(l) for l in y_thruster])

# ═══════════════════════════════════════════════════════════════════════════════
# 改进的网络：推进器同时输出分类+位图
# ═══════════════════════════════════════════════════════════════════════════════
from integrated_kan_diagnoser import LightKANDiagnoser
from custom_kan import TaylorKANLayer

class ImprovedDiagnoser(nn.Module):
    """
    改进的诊断器:
    - 整机分支: MLP → 8类分类
    - 推进器分支: TaylorKAN → 分类logits + 故障位图预测
    """
    def __init__(self, robot_dim, thruster_dim, robot_classes=8, thruster_classes=8):
        super().__init__()
        hidden = 256
        # 整机分支
        self.robot_net = nn.Sequential(
            nn.Linear(robot_dim, hidden), nn.BatchNorm1d(hidden),
            nn.GELU(), nn.Dropout(0.3),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden),
            nn.GELU(), nn.Dropout(0.2),
        )
        self.robot_head = nn.Linear(hidden, robot_classes)

        # 推进器分支: 投影层
        self.t_proj = nn.Sequential(
            nn.Linear(thruster_dim, 512),
            nn.LayerNorm(512),
        )
        # KAN层 (在__init__中创建，避免每次forward重建)
        self.t_kan1 = TaylorKANLayer(512, 256, K=3)
        self.t_norm1 = nn.LayerNorm(256)
        self.t_kan2 = TaylorKANLayer(256, 128, K=3)
        self.t_norm2 = nn.LayerNorm(128)

        # 分类头
        self.t_cls_head = nn.Linear(128, thruster_classes)
        # 位图头 (4个推进器状态)
        self.t_bitmap_head = nn.Linear(128, 4)

    def forward_robot(self, x):
        f = self.robot_net(x)
        return self.robot_head(f)

    def forward_thruster(self, x):
        # KAN前向
        f = F.gelu(self.t_norm1(self.t_kan1(self.t_proj(x))))
        f = F.gelu(self.t_norm2(self.t_kan2(f)))
        return self.t_cls_head(f), torch.sigmoid(self.t_bitmap_head(f))


def build_loaders_r(X, y, batch_size=128, test_ratio=0.2, seed=42):
    torch.manual_seed(seed); np.random.seed(seed)
    idx = np.random.permutation(len(X))
    n_test = max(2, int(len(X) * test_ratio))
    te, tr = idx[:n_test], idx[n_test:]
    ds = UnifiedDataset(X, y, fit=True, data_type='robot')
    scaler = ds.scaler
    tr_ds = UnifiedDataset(X[tr], y[tr], scaler=scaler, data_type='robot')
    te_ds = UnifiedDataset(X[te], y[te], scaler=scaler, data_type='robot')
    return (DataLoader(tr_ds, batch_size=batch_size, shuffle=True),
            DataLoader(te_ds, batch_size=len(te_ds), shuffle=False),
            scaler)


def build_loaders_t(X, y_bitmap, batch_size=16, seed=42):
    """推进器: 每类至少1个入测试集"""
    torch.manual_seed(seed); np.random.seed(seed)
    idx = np.random.permutation(len(X))
    test_idx, train_idx = [], []
    for cls in sorted(np.unique(y_bitmap if len(y_bitmap.shape) > 1 else np.arange(len(THRUSTER_LABELS)))):
        if len(y_bitmap.shape) > 1:
            # 分类标签用 y_thruster
            pass
    # 使用 y_thruster（分类标签）确定测试集
    pass

    # 按分类标签分测试集
    test_idx = []
    for cls in sorted(np.unique(y_thruster)):
        cls_idx = np.where(y_thruster == cls)[0]
        test_idx.append(cls_idx[0])
    train_idx = sorted([i for i in range(len(X)) if i not in set(test_idx)])

    ds = UnifiedDataset(X, y_thruster, fit=True, data_type='thruster')
    scaler = ds.scaler
    tr_ds = UnifiedDataset(X[train_idx], y_thruster[train_idx], scaler=scaler, data_type='thruster')
    te_ds = UnifiedDataset(X[test_idx], y_thruster[test_idx], scaler=scaler, data_type='thruster')
    # 位图标签
    tr_bm = torch.tensor(y_bitmap[train_idx], dtype=torch.float32)
    te_bm = torch.tensor(y_bitmap[test_idx], dtype=torch.float32)
    return (DataLoader(tr_ds, batch_size=batch_size, shuffle=True),
            DataLoader(te_ds, batch_size=len(te_ds), shuffle=False),
            scaler, tr_bm, te_bm, test_idx)


# 构建数据加载器
robot_tr, robot_te, robot_scaler = build_loaders_r(X_robot, y_robot, batch_size=128)
thruster_tr, thruster_te, thruster_scaler, tr_bm, te_bm, test_idx_t = build_loaders_t(
    X_thruster, y_thruster_bitmap, batch_size=32)

print(f"  Robot: Train={len(robot_tr.dataset)}, Test={len(robot_te.dataset)}")
print(f"  Thruster: Train={len(thruster_tr.dataset)}, Test={len(thruster_te.dataset)}")

# ═══════════════════════════════════════════════════════════════════════════════
# 模型
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[1] Building improved model...")
model = ImprovedDiagnoser(
    robot_dim=ROBOT_DIM, thruster_dim=THRUSTER_DIM,
    robot_classes=ROBOT_CLASSES, thruster_classes=THRUSTER_CLASSES
).to(DEVICE)

# 双优化器
robot_params = list(model.robot_net.parameters()) + list(model.robot_head.parameters())
thruster_params = (list(model.t_proj.parameters()) +
                   list(model.t_kan1.parameters()) + list(model.t_norm1.parameters()) +
                   list(model.t_kan2.parameters()) + list(model.t_norm2.parameters()) +
                   list(model.t_cls_head.parameters()) +
                   list(model.t_bitmap_head.parameters()))

opt_robot = torch.optim.AdamW(robot_params, lr=3e-4, weight_decay=1e-3)
opt_thruster = torch.optim.AdamW(thruster_params, lr=5e-5, weight_decay=5e-3)  # 更小学习率+更强正则
scheduler_r = torch.optim.lr_scheduler.CosineAnnealingLR(opt_robot, T_max=150)
scheduler_t = torch.optim.lr_scheduler.CosineAnnealingLR(opt_thruster, T_max=150)

total_params = sum(p.numel() for p in model.parameters())
print(f"  Total params: {total_params:,}")

criterion_cls = nn.CrossEntropyLoss(label_smoothing=0.1)
criterion_bitmap = nn.BCEWithLogitsLoss()  # 位图损失

# ═══════════════════════════════════════════════════════════════════════════════
# Stage 1: 训练整机分支（冻结推进器）
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[2] Stage 1: Training Robot branch (thruster frozen)...")
for p in model.t_proj.parameters(): p.requires_grad = False
for p in model.t_kan1.parameters(): p.requires_grad = False
for p in model.t_norm1.parameters(): p.requires_grad = False
for p in model.t_kan2.parameters(): p.requires_grad = False
for p in model.t_norm2.parameters(): p.requires_grad = False
for p in model.t_cls_head.parameters(): p.requires_grad = False
for p in model.t_bitmap_head.parameters(): p.requires_grad = False

EPOCHS_STAGE1 = 100
best_r_acc = 0.0; best_r_state = None
hist_r = {'loss': [], 'acc': [], 'te_acc': []}

for ep in range(1, EPOCHS_STAGE1 + 1):
    model.train()
    loss_sum, correct, total = 0.0, 0, 0
    for xr, yr in robot_tr:
        xr, yr = xr.to(DEVICE), yr.to(DEVICE)
        opt_robot.zero_grad()
        out = model.forward_robot(xr)
        loss = criterion_cls(out, yr)
        loss.backward()
        nn.utils.clip_grad_norm_(robot_params, 1.0)
        opt_robot.step()
        loss_sum += loss.item() * len(yr)
        correct += (out.argmax(1) == yr).sum().item()
        total += len(yr)
    scheduler_r.step()

    model.eval()
    with torch.no_grad():
        for xr, yr in robot_te:
            xr, yr = xr.to(DEVICE), yr.to(DEVICE)
            te_acc = (model.forward_robot(xr).argmax(1) == yr).float().mean().item() * 100

    hist_r['loss'].append(loss_sum / total)
    hist_r['acc'].append(correct / total * 100)
    hist_r['te_acc'].append(te_acc)

    if te_acc >= best_r_acc:
        best_r_acc = te_acc
        best_r_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    if ep % 20 == 0 or ep == 1:
        print(f"  Ep {ep:3d}/{EPOCHS_STAGE1}  "
              f"Train={correct/total*100:.1f}%  Test={te_acc:.1f}%  "
              f"(best={best_r_acc:.1f}%)")

# 恢复推进器参数
for p in model.t_proj.parameters(): p.requires_grad = True
for p in model.t_kan1.parameters(): p.requires_grad = True
for p in model.t_norm1.parameters(): p.requires_grad = True
for p in model.t_kan2.parameters(): p.requires_grad = True
for p in model.t_norm2.parameters(): p.requires_grad = True
for p in model.t_cls_head.parameters(): p.requires_grad = True
for p in model.t_bitmap_head.parameters(): p.requires_grad = True
model.load_state_dict(best_r_state)
print(f"  Stage 1 Best Robot Acc: {best_r_acc:.1f}%")

# ═══════════════════════════════════════════════════════════════════════════════
# Stage 2: 训练推进器分支（大幅降低学习率）
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[3] Stage 2: Training Thruster branch (robot frozen)...")
for p in model.robot_net.parameters(): p.requires_grad = False
for p in model.robot_head.parameters(): p.requires_grad = False

EPOCHS_STAGE2 = 300
best_t_cls_acc = 0.0; best_t_bitmap_acc = 0.0
best_t_state = None
hist_t = {'loss': [], 'cls_acc': [], 'bm_acc': [], 'te_cls': [], 'te_bm': []}

for ep in range(1, EPOCHS_STAGE2 + 1):
    model.train()
    loss_sum, cls_correct, bm_correct, total = 0.0, 0, 0, 0
    for xt, yt in thruster_tr:
        xt, yt = xt.to(DEVICE), yt.to(DEVICE)

        opt_thruster.zero_grad()
        cls_out, bm_out = model.forward_thruster(xt)
        # 位图标签: 从分类标签转换
        yb_bitmap = torch.stack([
            torch.tensor(thruster_fault_bitmap(yi.item()), dtype=torch.float32).to(DEVICE)
            for yi in yt
        ])
        loss_cls = criterion_cls(cls_out, yt)
        loss_bm = criterion_bitmap(bm_out, yb_bitmap)
        loss = loss_cls + 0.5 * loss_bm  # 组合损失
        loss.backward()
        nn.utils.clip_grad_norm_(thruster_params, 1.0)
        opt_thruster.step()

        loss_sum += loss.item() * len(yt)
        cls_correct += (cls_out.argmax(1) == yt).sum().item()
        # 位图准确率
        bm_pred = (torch.sigmoid(bm_out) > 0.5).float()
        bm_correct += (bm_pred == yb_bitmap).all(dim=1).sum().item()
        total += len(yt)

    scheduler_t.step()

    model.eval()
    with torch.no_grad():
        for xt, yt in thruster_te:
            xt, yt = xt.to(DEVICE), yt.to(DEVICE)
            yb_bitmap = torch.stack([
                torch.tensor(thruster_fault_bitmap(yi.item()), dtype=torch.float32).to(DEVICE)
                for yi in yt
            ])
            cls_out, bm_out = model.forward_thruster(xt)
            te_cls = (cls_out.argmax(1) == yt).float().mean().item() * 100
            bm_pred = (torch.sigmoid(bm_out) > 0.5).float()
            te_bm = (bm_pred == yb_bitmap).all(dim=1).float().mean().item() * 100

    hist_t['loss'].append(loss_sum / total)
    hist_t['cls_acc'].append(cls_correct / total * 100)
    hist_t['bm_acc'].append(bm_correct / total * 100)
    hist_t['te_cls'].append(te_cls)
    hist_t['te_bm'].append(te_bm)

    # 记录最佳
    if te_cls >= best_t_cls_acc and te_bm >= best_t_bitmap_acc:
        best_t_cls_acc = te_cls
        best_t_bitmap_acc = te_bm
        best_t_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    if ep % 30 == 0 or ep == 1:
        print(f"  Ep {ep:3d}/{EPOCHS_STAGE2}  "
              f"Cls={cls_correct/total*100:.1f}%  "
              f"BitMap={bm_correct/total*100:.1f}%  "
              f"TeCls={te_cls:.1f}%  TeBm={te_bm:.1f}%  "
              f"(best: C={best_t_cls_acc:.1f}% B={best_t_bitmap_acc:.1f}%)")

# 恢复整机参数
for p in model.robot_net.parameters(): p.requires_grad = True
for p in model.robot_head.parameters(): p.requires_grad = True
model.load_state_dict(best_t_state)

# ═══════════════════════════════════════════════════════════════════════════════
# 最终评估
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[4] Final evaluation...")
model.eval()

def eval_robot():
    preds, labels = [], []
    with torch.no_grad():
        for xr, yr in robot_te:
            xr = xr.to(DEVICE)
            p = model.forward_robot(xr).argmax(1).cpu().numpy()
            preds.append(p); labels.append(yr.numpy())
    return np.concatenate(preds), np.concatenate(labels)

def eval_thruster():
    preds_cls, preds_bm, labels_cls, labels_bm = [], [], [], []
    with torch.no_grad():
        for xt, yt in thruster_te:
            xt = xt.to(DEVICE)
            cls_out, bm_out = model.forward_thruster(xt)
            p_cls = cls_out.argmax(1).cpu().numpy()
            p_bm = (torch.sigmoid(bm_out) > 0.5).cpu().numpy()
            labels_bm.append(np.stack([
                thruster_fault_bitmap(yi.item()) for yi in yt
            ]))
            preds_cls.append(p_cls); preds_bm.append(p_bm)
            labels_cls.append(yt.numpy())
    return (np.concatenate(preds_cls), np.concatenate(preds_bm),
            np.concatenate(labels_cls), np.concatenate(labels_bm))

r_preds, r_labels = eval_robot()
t_cls_preds, t_bm_preds, t_cls_labels, t_bm_labels = eval_thruster()

r_acc = (r_preds == r_labels).mean() * 100
t_cls_acc = (t_cls_preds == t_cls_labels).mean() * 100
t_bm_acc = (t_bm_preds == t_bm_labels).all(axis=1).mean() * 100

print(f"\n  Final Robot Acc:     {r_acc:.1f}%")
print(f"  Final Thruster CLS:  {t_cls_acc:.1f}%")
print(f"  Final Thruster BM:   {t_bm_acc:.1f}%")

# 各推进器位检测准确率
thruster_detect = []
for i in range(4):
    correct = (t_bm_preds[:, i] == t_bm_labels[:, i]).sum()
    acc = correct / len(t_bm_labels) * 100
    thruster_detect.append(float(acc))
    print(f"    Thruster {i+1} Detection: {acc:.0f}%")

# ═══════════════════════════════════════════════════════════════════════════════
# 可视化
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[5] Generating visualizations...")
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'figure.facecolor': 'white',
    'axes.titlesize': 12, 'savefig.dpi': 150,
})
COLORS = plt.cm.tab10(np.linspace(0, 1, 16))

# ── 图1: 训练曲线 ─────────────────────────────────────────────────────────────
EX1 = range(1, len(hist_r['acc']) + 1)
EX2 = range(1, len(hist_t['cls_acc']) + 1)
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
axes[0,0].plot(EX1, hist_r['loss'], 'royalblue', lw=2)
axes[0,0].set_title('Stage 1: Robot Training Loss'); axes[0,0].grid(alpha=0.3)
axes[0,1].plot(EX1, hist_r['acc'], 'royalblue', lw=2, label='Train')
axes[0,1].plot(EX1, hist_r['te_acc'], 'tomato', lw=2, label='Test')
axes[0,1].axhline(best_r_acc, ls='--', color='green', alpha=0.7, label=f'Best={best_r_acc:.1f}%')
axes[0,1].legend(); axes[0,1].grid(alpha=0.3)
axes[0,1].set_title('Stage 1: Robot Accuracy')
axes[1,0].plot(EX2, hist_t['loss'], 'darkgreen', lw=2)
axes[1,0].set_title('Stage 2: Thruster Training Loss'); axes[1,0].grid(alpha=0.3)
axes[1,1].plot(EX2, hist_t['cls_acc'], 'darkgreen', lw=2, label='Cls Train')
axes[1,1].plot(EX2, hist_t['te_cls'], 'orange', lw=2, label='Cls Test')
axes[1,1].plot(EX2, hist_t['te_bm'], 'red', lw=2, label='Bitmap Test')
axes[1,1].legend(); axes[1,1].grid(alpha=0.3)
axes[1,1].set_title(f'Stage 2: Thruster (Cls={best_t_cls_acc:.0f}%, BM={best_t_bitmap_acc:.0f}%)')
plt.suptitle('Two-Stage Training Curves', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '01_training_curves.png', bbox_inches='tight'); plt.close()
print(f"  -> 01_training_curves.png")

# ── 图2: 混淆矩阵 ──────────────────────────────────────────────────────────────
r_present = sorted(np.unique(r_labels))
t_present = sorted(np.unique(t_cls_labels))
r_names = [ROBOT_SHORT.get(ROBOT_NAMES[i], ROBOT_NAMES[i]) for i in r_present]
t_names = [THRUSTER_SHORT.get(THRUSTER_NAMES[i], THRUSTER_NAMES[i]) for i in t_present]

fig, axes = plt.subplots(1, 2, figsize=(20, 8))
r_cm = confusion_matrix(r_labels, r_preds, labels=r_present)
r_cm_n = r_cm.astype(float) / (r_cm.sum(axis=1, keepdims=True) + 1e-8)
sns.heatmap(r_cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=r_names, yticklabels=r_names, ax=axes[0],
            linewidths=0.5, annot_kws={'size': 9})
axes[0].set_title(f'Robot Fault Detection CM  Acc: {r_acc:.1f}%')
axes[0].tick_params(axis='x', rotation=35)
axes[1].text(0.5, 0.5,
             f'Thruster Classification\nCls Acc: {t_cls_acc:.1f}%\nBitmap Acc: {t_bm_acc:.1f}%\n\n'
             + '\n'.join([f'T{i+1}: {thruster_detect[i]:.0f}%' for i in range(4)]),
             ha='center', va='center', fontsize=16,
             transform=axes[1].transAxes)
axes[1].axis('off')
plt.suptitle('Diagnosis Results', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '02_confusion_matrices.png', bbox_inches='tight'); plt.close()
print(f"  -> 02_confusion_matrices.png")

# ── 图3: 推进器位图预测可视化 ─────────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
# 真实位图
im0 = axes[0].imshow(t_bm_labels.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
axes[0].set_title('True Fault Bitmap')
axes[0].set_xlabel('Thruster'); axes[0].set_ylabel('Sample')
axes[0].set_yticks(range(len(t_bm_labels)))
axes[0].set_yticklabels([THRUSTER_SHORT[THRUSTER_NAMES[l]] for l in t_cls_labels], fontsize=8)
axes[0].set_xticks(range(4)); axes[0].set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im0, ax=axes[0], shrink=0.8)

# 预测位图
im1 = axes[1].imshow(t_bm_preds.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
axes[1].set_title('Predicted Fault Bitmap')
axes[1].set_xlabel('Thruster'); axes[1].set_ylabel('Sample')
axes[1].set_yticks(range(len(t_bm_preds)))
axes[1].set_yticklabels([THRUSTER_SHORT[THRUSTER_NAMES[l]] for l in t_cls_labels], fontsize=8)
axes[1].set_xticks(range(4)); axes[1].set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im1, ax=axes[1], shrink=0.8)

# 准确率柱状图
thruster_names = [f'Vertical\nThruster {i+1}' for i in range(4)]
colors = ['#2ecc71' if a >= 90 else '#f39c12' if a >= 70 else '#e74c3c' for a in thruster_detect]
bars = axes[2].bar(thruster_names, thruster_detect,
                   color=colors, edgecolor='white', linewidth=2)
for bar, v in zip(bars, thruster_detect):
    axes[2].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                 f'{v:.0f}%', ha='center', fontsize=13, fontweight='bold')
axes[2].set_ylim(0, 115)
axes[2].set_ylabel('Detection Accuracy (%)')
axes[2].set_title('Thruster Fault Detection Rate')
axes[2].axhline(100, ls='--', color='green', alpha=0.5)
axes[2].grid(axis='y', alpha=0.3)

plt.suptitle(f'Thruster Fault Localization Results\n'
             f'BitMap Accuracy: {t_bm_acc:.1f}%  |  '
             f'Thrusters: {[f"{a:.0f}%" for a in thruster_detect]}',
             fontweight='bold', fontsize=13)
plt.tight_layout()
plt.savefig(OUT / '03_thruster_bitmap.png', bbox_inches='tight'); plt.close()
print(f"  -> 03_thruster_bitmap.png")

# ── 图4: 推进器分类混淆矩阵 ────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 8))
t_cm = confusion_matrix(t_cls_labels, t_cls_preds, labels=t_present)
t_cm_n = t_cm.astype(float) / (t_cm.sum(axis=1, keepdims=True) + 1e-8)
sns.heatmap(t_cm_n, annot=True, fmt='.2f', cmap='Greens',
           xticklabels=t_names, yticklabels=t_names, ax=ax,
           linewidths=0.5, annot_kws={'size': 10})
ax.set_title(f'Thruster Classification CM  Acc: {t_cls_acc:.1f}%')
ax.tick_params(axis='x', rotation=35)
plt.tight_layout()
plt.savefig(OUT / '04_thruster_confusion.png', bbox_inches='tight'); plt.close()
print(f"  -> 04_thruster_confusion.png")

# ── 图5: 各类别准确率 ─────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
r_per_cls = [(r_preds[r_labels==l]==l).mean()*100 if (r_labels==l).sum()>0 else 0 for l in r_present]
t_per_cls = [(t_cls_preds[t_cls_labels==l]==l).mean()*100 if (t_cls_labels==l).sum()>0 else 0 for l in t_present]

axes[0].bar(range(len(r_names)), r_per_cls, color=[COLORS[i%16] for i in range(len(r_names))])
axes[0].set_xticks(range(len(r_names))); axes[0].set_xticklabels(r_names, rotation=30, ha='right')
axes[0].set_ylim(0, 115); axes[0].set_title(f'Robot Per-Class Acc ({r_acc:.1f}%)')
axes[0].grid(axis='y', alpha=0.3)
for i, v in enumerate(r_per_cls):
    axes[0].text(i, v+1, f'{v:.0f}%', ha='center', fontsize=9)

axes[1].bar(range(len(t_names)), t_per_cls, color=[COLORS[i%16] for i in range(len(t_names))])
axes[1].set_xticks(range(len(t_names))); axes[1].set_xticklabels(t_names, rotation=30, ha='right')
axes[1].set_ylim(0, 115); axes[1].set_title(f'Thruster Per-Class Acc ({t_cls_acc:.1f}%)')
axes[1].grid(axis='y', alpha=0.3)
for i, v in enumerate(t_per_cls):
    axes[1].text(i, v+1, f'{v:.0f}%', ha='center', fontsize=9)
plt.suptitle('Per-Class Accuracy', fontweight='bold', fontsize=13)
plt.tight_layout()
plt.savefig(OUT / '05_per_class_accuracy.png', bbox_inches='tight'); plt.close()
print(f"  -> 05_per_class_accuracy.png")

# ── 图6: 汇总大图 ─────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(22, 18))
gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.38)

ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(EX1, hist_r['acc'], 'royalblue', lw=2, label='Train')
ax1.plot(EX1, hist_r['te_acc'], 'tomato', lw=2, label='Test')
ax1.axhline(best_r_acc, ls='--', color='green', alpha=0.7)
ax1.set_title(f'Robot Accuracy (Best: {best_r_acc:.1f}%)')
ax1.legend(); ax1.grid(alpha=0.3); ax1.set_xlabel('Epoch'); ax1.set_ylabel('Acc (%)')

ax2 = fig.add_subplot(gs[0, 1])
ax2.plot(EX2, hist_t['te_cls'], 'darkgreen', lw=2, label='Cls Test')
ax2.plot(EX2, hist_t['te_bm'], 'red', lw=2, label='Bitmap Test')
ax2.axhline(best_t_cls_acc, ls='--', color='darkgreen', alpha=0.5)
ax2.axhline(best_t_bitmap_acc, ls='--', color='red', alpha=0.5)
ax2.set_title(f'Thruster Accuracy (Cls: {best_t_cls_acc:.1f}%, BM: {best_t_bitmap_acc:.1f}%)')
ax2.legend(); ax2.grid(alpha=0.3); ax2.set_xlabel('Epoch'); ax2.set_ylabel('Acc (%)')

ax3 = fig.add_subplot(gs[0, 2])
colors = ['#2ecc71' if a >= 90 else '#f39c12' if a >= 70 else '#e74c3c' for a in thruster_detect]
bars = ax3.bar([f'T{i+1}' for i in range(4)], thruster_detect, color=colors, edgecolor='white', linewidth=2)
for bar, v in zip(bars, thruster_detect):
    ax3.text(bar.get_x()+bar.get_width()/2, bar.get_height()+1,
             f'{v:.0f}%', ha='center', fontsize=12, fontweight='bold')
ax3.set_ylim(0, 115); ax3.set_ylabel('Acc (%)')
ax3.set_title('Thruster Detection Rate'); ax3.grid(axis='y', alpha=0.3)
ax3.axhline(100, ls='--', color='green', alpha=0.4)

ax4 = fig.add_subplot(gs[1, :2])
sns.heatmap(r_cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=r_names, yticklabels=r_names, ax=ax4,
            linewidths=0.5, annot_kws={'size': 9})
ax4.set_title(f'Robot Fault Detection CM  ({r_acc:.1f}%)')
ax4.tick_params(axis='x', rotation=35); ax4.set_xlabel('Predicted'); ax4.set_ylabel('True')

ax5 = fig.add_subplot(gs[1, 2])
t_cm_small = confusion_matrix(t_cls_labels, t_cls_preds, labels=t_present)
t_cm_small_n = t_cm_small.astype(float) / (t_cm_small.sum(axis=1, keepdims=True) + 1e-8)
sns.heatmap(t_cm_small_n, annot=True, fmt='.2f', cmap='Greens',
            xticklabels=t_names, yticklabels=t_names, ax=ax5,
            linewidths=0.5, annot_kws={'size': 8})
ax5.set_title(f'Thruster Classification ({t_cls_acc:.1f}%)')
ax5.tick_params(axis='x', rotation=35)

ax6 = fig.add_subplot(gs[2, 0])
im = ax6.imshow(t_bm_labels.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
ax6.set_title('True Fault Bitmap')
ax6.set_xlabel('Thruster'); ax6.set_ylabel('Sample')
ax6.set_xticks(range(4)); ax6.set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im, ax=ax6, shrink=0.8)

ax7 = fig.add_subplot(gs[2, 1])
im2 = ax7.imshow(t_bm_preds.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
ax7.set_title('Predicted Fault Bitmap')
ax7.set_xlabel('Thruster'); ax7.set_ylabel('Sample')
ax7.set_xticks(range(4)); ax7.set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im2, ax=ax7, shrink=0.8)

ax8 = fig.add_subplot(gs[2, 2])
# 误差热力图: 差异
diff = np.abs(t_bm_preds.astype(float) - t_bm_labels.astype(float))
im3 = ax8.imshow(diff, cmap='Reds', aspect='auto', vmin=0, vmax=1)
ax8.set_title('Prediction Error')
ax8.set_xlabel('Thruster'); ax8.set_ylabel('Sample')
ax8.set_xticks(range(4)); ax8.set_xticklabels([f'T{i+1}' for i in range(4)])
plt.colorbar(im3, ax=ax8, shrink=0.8)

fig.suptitle(
    f'Two-Stage KAN Fault Diagnosis System - Integrated Results\n'
    f'Stage 1 (Robot): {r_acc:.1f}%  |  '
    f'Stage 2 (Thruster): Cls={t_cls_acc:.1f}%  BM={t_bm_acc:.1f}%  |  '
    f'T{i+1}: {[f"{a:.0f}%" for i,a in enumerate(thruster_detect)]}',
    fontsize=14, fontweight='bold'
)
plt.savefig(OUT / '00_summary.png', bbox_inches='tight'); plt.close()
print(f"  -> 00_summary.png")

# 保存模型
torch.save({
    'model_state': best_t_state,
    'robot_scaler': robot_scaler,
    'thruster_scaler': thruster_scaler,
    'ROBOT_LABELS': ROBOT_LABELS,
    'THRUSTER_LABELS': THRUSTER_LABELS,
    'ROBOT_NAMES': ROBOT_NAMES,
    'THRUSTER_NAMES': THRUSTER_NAMES,
    'best_robot_acc': float(r_acc),
    'best_thruster_cls_acc': float(t_cls_acc),
    'best_thruster_bm_acc': float(t_bm_acc),
    'thruster_detect_acc': thruster_detect,
}, OUT / 'best_model.pt')

# ═══════════════════════════════════════════════════════════════════════════════
# 逐文件诊断演示
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[6] Diagnosis Demo...")

print("\n  === Robot Diagnosis (Whole Machine) ===")
model.eval()
with torch.no_grad():
    for xr, yr in robot_te:
        xr = xr.to(DEVICE)
        logits = model.forward_robot(xr)
        probs = torch.softmax(logits, dim=1).cpu().numpy()
        preds = logits.argmax(1).cpu().numpy()
        for i in range(len(preds)):
            true_cls = ROBOT_NAMES[int(yr[i].item())]
            pred_cls = ROBOT_NAMES[preds[i]]
            conf = probs[i].max() * 100
            ok = "OK" if preds[i] == yr[i].item() else "NG"
            print(f"  [{ok}]  True={ROBOT_SHORT[true_cls]:10s}  "
                  f"Pred={ROBOT_SHORT[pred_cls]:10s}  Conf={conf:.0f}%")

print("\n  === Thruster Diagnosis (Propulsion System) ===")
with torch.no_grad():
    for xt, yt in thruster_te:
        xt = xt.to(DEVICE)
        cls_out, bm_out = model.forward_thruster(xt)
        cls_probs = torch.softmax(cls_out, dim=1).cpu().numpy()
        cls_preds = cls_out.argmax(1).cpu().numpy()
        bm_probs = torch.sigmoid(bm_out).cpu().numpy()
        bm_preds = (bm_probs > 0.5).astype(int)
        for i in range(len(cls_preds)):
            true_cls = THRUSTER_NAMES[int(yt[i].item())]
            pred_cls = THRUSTER_NAMES[cls_preds[i]]
            true_closed = [j+1 for j, v in enumerate(thruster_fault_bitmap(yt[i].item())) if v == 1]
            pred_closed = [j+1 for j, v in enumerate(bm_preds[i]) if v == 1]
            conf = cls_probs[i].max() * 100
            ok_cls = "OK" if cls_preds[i] == yt[i].item() else "NG"
            ok_bm = "OK" if set(true_closed) == set(pred_closed) else "NG"
            print(f"  [{ok_cls}/{ok_bm}]  True={THRUSTER_SHORT[true_cls]:15s}  "
                  f"Pred={THRUSTER_SHORT[pred_cls]:15s}  "
                  f"Closed={[f'T{c}' for c in true_closed]}->{[f'T{c}' for c in pred_closed]}  "
                  f"Conf={conf:.0f}%")

print(f"\n{'='*60}")
print(f"  Training complete!")
print(f"  Robot Acc:           {r_acc:.1f}%")
print(f"  Thruster Cls Acc:    {t_cls_acc:.1f}%")
print(f"  Thruster Bitmap Acc: {t_bm_acc:.1f}%")
print(f"  Thruster 1-4:       {[f'{a:.0f}%' for a in thruster_detect]}")
print(f"  Output:             {OUT}")
print(f"{'='*60}")
