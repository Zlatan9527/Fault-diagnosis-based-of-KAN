"""
推进器故障诊断 - 机器人数据加载模块
===================================
数据来源: E:\范小龙\数据\数据\

推进器编号:
  垂推1-4 (Vertical thrusters 1-4)  → 编号 1-4
  侧推1-4 (Lateral thrusters 1-4)   → 编号 5-8

故障描述:
  定向数据（使用垂推定向）:
    - normal: 垂推1,2,3,4 全部正常工作
    - fault_1_off: 垂推1 故障（输出≈0）
    - fault_12_off: 垂推1,2 同时故障
    - fault_13_off: 垂推1,3 同时故障
    - fault_123_off: 仅垂推4 工作

  前推数据（使用垂推产生前进力）:
    - normal_push: 垂推1,2,3,4 全部正常工作
    - fault_1_off: 垂推1 故障
    - fault_12_off: 垂推1,2 同时故障
    - fault_13_off: 垂推1,3 同时故障
"""

import os, sys
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from pathlib import Path
from typing import Tuple, List, Optional, Dict
from scipy import signal
import warnings
warnings.filterwarnings('ignore')

# ── 8个推进器 ──────────────────────────────────────────────────────────────────
THRUSTER_NAMES = ['垂推1', '垂推2', '垂推3', '垂推4', '侧推1', '侧推2', '侧推3', '侧推4']
NUM_THRUSTERS  = 8

# ── 故障标签定义 ──────────────────────────────────────────────────────────────
FAULT_LABELS = {
    # 定向数据标签
    'normal':         0,
    'ding_fault_1':   1,   # 垂推1故障
    'ding_fault_12':  2,   # 垂推1+2故障
    'ding_fault_13':  3,   # 垂推1+3故障
    'ding_fault_123': 4,   # 垂推1+2+3故障
    # 前推数据标签
    'normal_push':    5,   # 前推正常
    'push_fault_1':   6,   # 前推-垂推1故障
    'push_fault_12':  7,   # 前推-垂推1+2故障
    'push_fault_13':  8,   # 前推-垂推1+3故障
}
LABEL_NAMES = {v: k for k, v in FAULT_LABELS.items()}
NUM_CLASSES  = len(FAULT_LABELS)


# ── 文件 → 标签 映射 ──────────────────────────────────────────────────────────
# 基于 txt 描述和数据特征分析确定
DING_FILES = {
    '2025-01-05_17-26-54': 'normal',         # 正常定向
    '2025-01-05_17-29-52': 'ding_fault_1',  # 关闭1号
    '2025-01-05_17-32-17': 'ding_fault_12', # 关闭12号
    '2025-01-05_17-34-39': 'ding_fault_12', # 关闭12号（同上，重复数据）
    '2025-01-05_17-36-18': 'ding_fault_13', # 关闭13号
    '2025-01-05_17-41-23': 'ding_fault_123',# 只留4（仅垂推4工作）
}

QIAN_FILES = {
    '2025-01-05_17-45-03': 'normal_push',   # 正常前推
    '2025-01-05_18-00-14': 'push_fault_12',# 关闭12号
    '2025-01-05_18-02-16': 'push_fault_13',# 关闭13号
}

BASE_DING = Path(r'E:\范小龙\数据\数据\定向数据')
BASE_QIAN = Path(r'E:\范小龙\数据\数据\手柄前推数据')


# ── 数据读取 ──────────────────────────────────────────────────────────────────
def read_excel_robust(fpath: str) -> Optional[pd.DataFrame]:
    """读取 xlsx 文件，忽略临时文件"""
    try:
        if os.path.basename(fpath).startswith('~$'):
            return None
        df = pd.read_excel(str(fpath))
        df = df.apply(pd.to_numeric, errors='coerce').dropna()
        if df.shape[0] < 5:
            return None
        return df
    except Exception:
        return None


# ── 特征提取 ──────────────────────────────────────────────────────────────────
def extract_thruster_features(df: pd.DataFrame) -> np.ndarray:
    """
    从单个数据文件提取统计特征。
    返回: (D,) 特征向量
    """
    parts = []
    for col in THRUSTER_NAMES:
        if col not in df.columns:
            parts.append(np.zeros(12, dtype=np.float32))
            continue
        x = df[col].values.astype(np.float32)

        # 时域统计
        parts.append(np.array([
            np.mean(x), np.std(x),
            np.max(np.abs(x)),
            np.sqrt(np.mean(x**2)),           # RMS
            np.mean(np.abs(x)),
            np.max(np.abs(x)) / (np.sqrt(np.mean(x**2)) + 1e-8),  # 峰值因子
            np.mean((x-np.mean(x))**3) / (np.std(x)**3 + 1e-8),  # 偏度
            np.mean((x-np.mean(x))**4) / (np.std(x)**4 + 1e-8),  # 峭度
            np.min(x),                       # 最小值
            np.max(x) - np.min(x),           # 峰峰值
            np.percentile(x, 25),            # Q1
            np.percentile(x, 75),             # Q3
        ], dtype=np.float32))

    return np.concatenate(parts)  # (96,)


def extract_row_features(df: pd.DataFrame) -> np.ndarray:
    """
    将每个数据文件视为一个时序，对每行提取特征后做滑动窗口增强。
    返回: (num_windows, D) 特征矩阵
    """
    feat_dim = len(THRUSTER_NAMES) * 12  # 96
    rows = []
    for _, row in df.iterrows():
        parts = []
        for col in THRUSTER_NAMES:
            if col not in df.columns:
                parts.append(np.zeros(12, dtype=np.float32))
            else:
                val = float(row[col])
                parts.append(np.array([val]*12, dtype=np.float32))
        rows.append(np.concatenate(parts))
    return np.stack(rows)  # (T, 96)


# ── 数据扩充：滑动窗口 ────────────────────────────────────────────────────────
def sliding_window_rows(X: np.ndarray, window: int = 5, step: int = 1) -> np.ndarray:
    """对行特征做滑动窗口平滑/扩充"""
    if len(X) < window:
        pad = np.tile(X[-1:], (window - len(X), 1))
        X = np.vstack([X, pad])
    feats = []
    for i in range(0, len(X) - window + 1, step):
        feats.append(X[i:i+window].mean(axis=0))
    return np.stack(feats)


# ── 主加载函数 ────────────────────────────────────────────────────────────────
def load_robot_dataset(
    augment: bool = True,
    window: int = 5,
    step: int = 1,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    加载并整合所有定向+前推数据。

    Returns:
        X: (N, D) 特征
        y: (N,) 标签
    """
    X_list, y_list = [], []

    # ── 定向数据 ──
    for fname, label_key in DING_FILES.items():
        fpath = BASE_DING / f'{fname}.xlsx'
        if not fpath.exists():
            print(f"[跳过] {fpath} 不存在")
            continue
        df = read_excel_robust(str(fpath))
        if df is None:
            continue

        feat = extract_thruster_features(df)  # (96,) 文件级统计

        if augment:
            row_feats = extract_row_features(df)  # (T, 96)
            win_feats = sliding_window_rows(row_feats, window=window, step=step)
            X_list.append(win_feats)
        else:
            X_list.append(feat[None, :])

        label = FAULT_LABELS[label_key]
        n = len(X_list[-1])
        y_list.append(np.full(n, label, dtype=np.int64))
        print(f"  [定向] {fname:35s} → {label_key:20s}  样本数={n}")

    # ── 前推数据 ──
    for fname, label_key in QIAN_FILES.items():
        fpath = BASE_QIAN / f'{fname}.xlsx'
        if not fpath.exists():
            print(f"[跳过] {fpath} 不存在")
            continue
        df = read_excel_robust(str(fpath))
        if df is None:
            continue

        feat = extract_thruster_features(df)

        if augment:
            row_feats = extract_row_features(df)
            win_feats = sliding_window_rows(row_feats, window=window, step=step)
            X_list.append(win_feats)
        else:
            X_list.append(feat[None, :])

        label = FAULT_LABELS[label_key]
        n = len(X_list[-1])
        y_list.append(np.full(n, label, dtype=np.int64))
        print(f"  [前推] {fname:35s} → {label_key:20s}  样本数={n}")

    X = np.concatenate(X_list, axis=0).astype(np.float32)
    y = np.concatenate(y_list, axis=0)

    print(f"\n[总计] X={X.shape}  y={y.shape}")
    for lbl in np.unique(y):
        print(f"  {LABEL_NAMES[lbl]:20s} (id={lbl}): {(y==lbl).sum():4d} 样本")
    return X, y


# ── PyTorch Dataset ──────────────────────────────────────────────────────────
class RobotThrusterDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray,
                 scaler: Optional[StandardScaler] = None,
                 fit: bool = False):
        if fit:
            scaler = StandardScaler()
            Xs = scaler.fit_transform(X)
        elif scaler is not None:
            Xs = scaler.transform(X)
        else:
            Xs = X
        self.X   = torch.tensor(Xs, dtype=torch.float32)
        self.y   = torch.tensor(y,  dtype=torch.long)
        self.scaler = scaler

    def __len__(self): return len(self.y)
    def __getitem__(self, idx): return self.X[idx], self.y[idx]

    @property
    def feature_dim(self): return self.X.shape[1]


def build_loaders(X, y, batch_size=32, test_ratio=0.2, seed=42):
    """划分训练/测试集并返回 DataLoader"""
    torch.manual_seed(seed); np.random.seed(seed)
    idx = np.random.permutation(len(X))
    n_test = max(1, int(len(X) * test_ratio))
    train_idx, test_idx = idx[n_test:], idx[:n_test]

    ds = RobotThrusterDataset(X, y, fit=True)
    scaler = ds.scaler

    train_ds = RobotThrusterDataset(X[train_idx], y[train_idx], scaler=scaler)
    test_ds  = RobotThrusterDataset(X[test_idx],  y[test_idx],  scaler=scaler)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size, shuffle=False)

    return train_loader, test_loader, scaler, train_ds.feature_dim


# ── 数据检查入口 ──────────────────────────────────────────────────────────────
if __name__ == '__main__':
    X, y = load_robot_dataset(augment=True, window=5, step=1)
