"""
推进器故障诊断 - 训练 + 可视化
==============================
"""
import sys, os, warnings, time
warnings.filterwarnings('ignore')
sys.path.insert(0, r'c:\Users\ZYC\WorkBuddy\Claw')

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.model_selection import StratifiedKFold
import seaborn as sns
from pathlib import Path

# ── 路径 ──────────────────────────────────────────────────────────────────────
OUT = Path(r'c:\Users\ZYC\WorkBuddy\Claw\results_robot')
OUT.mkdir(parents=True, exist_ok=True)

DEVICE  = 'cuda' if torch.cuda.is_available() else 'cpu'
EPOCHS  = 120
BATCH   = 16
LR      = 5e-4
SEED    = 42

torch.manual_seed(SEED); np.random.seed(SEED)
print(f"[设备] {DEVICE}")

# ── 数据 ──────────────────────────────────────────────────────────────────────
from thruster_robot_data import (load_robot_dataset, build_loaders,
                                  LABEL_NAMES, NUM_CLASSES, FAULT_LABELS)

print("\n[1/6] 加载数据...")
X, y = load_robot_dataset(augment=True, window=5, step=1)
train_loader, test_loader, scaler, feat_dim = build_loaders(X, y, batch_size=BATCH)
print(f"      特征维度={feat_dim}  类别数={NUM_CLASSES}")

# ── 模型 ──────────────────────────────────────────────────────────────────────
print("\n[2/6] 初始化模型...")

class ResBlock(nn.Module):
    def __init__(self, d, dr=0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d, d), nn.LayerNorm(d), nn.GELU(), nn.Dropout(dr),
            nn.Linear(d, d), nn.LayerNorm(d))
    def forward(self, x): return x + self.net(x)

class ThrusterDiagnoser(nn.Module):
    """8故障分类模型"""
    def __init__(self, din, ncls):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Linear(din, 256), nn.BatchNorm1d(256), nn.GELU(), nn.Dropout(0.3),
            nn.Linear(256, 128), nn.BatchNorm1d(128), nn.GELU(), nn.Dropout(0.2),
            ResBlock(128), ResBlock(128),
            nn.Linear(128, 64), nn.BatchNorm1d(64), nn.GELU(), nn.Dropout(0.1))
        self.head = nn.Linear(64, ncls)

    def forward(self, x):
        return self.head(self.backbone(x))

    def get_feat(self, x):
        with torch.no_grad():
            return self.backbone(x)

model = ThrusterDiagnoser(feat_dim, NUM_CLASSES).to(DEVICE)
print(f"      参数量: {sum(p.numel() for p in model.parameters()):,}")

criterion = nn.CrossEntropyLoss(label_smoothing=0.05)
optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=30, T_mult=2)

# ── 训练 ──────────────────────────────────────────────────────────────────────
print("\n[3/6] 训练...")
tr_ls, tr_ac, va_ls, va_ac = [], [], [], []
best_acc, best_state = 0.0, None

for ep in range(1, EPOCHS+1):
    model.train()
    tl, tc, tt = 0.0, 0, 0
    for xb, yb in train_loader:
        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
        optimizer.zero_grad()
        loss = criterion(model(xb), yb)
        loss.backward(); optimizer.step()
        tl += loss.item()*len(yb); tc += (model(xb).argmax(1)==yb).sum().item(); tt += len(yb)
    scheduler.step()

    model.eval()
    vl, vc, vt = 0.0, 0, 0
    with torch.no_grad():
        for xb, yb in test_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            logits = model(xb)
            vl += criterion(logits, yb).item()*len(yb)
            vc += (logits.argmax(1)==yb).sum().item(); vt += len(yb)

    tr_ls.append(tl/tt); tr_ac.append(tc/tt*100)
    va_ls.append(vl/vt); va_ac.append(vc/vt*100)

    if va_ac[-1] > best_acc:
        best_acc = va_ac[-1]
        best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    if ep % 20 == 0 or ep == 1:
        print(f"  Ep {ep:3d}/{EPOCHS}  loss={tr_ls[-1]:.4f} acc={tr_ac[-1]:.1f}%  "
              f"val_loss={va_ls[-1]:.4f} val_acc={va_ac[-1]:.1f}%")

print(f"\n  最佳验证准确率: {best_acc:.2f}%")
model.load_state_dict(best_state)

# ── 评估 ──────────────────────────────────────────────────────────────────────
print("\n[4/6] 最终评估...")
model.eval()
all_p, all_l, all_f = [], [], []
with torch.no_grad():
    for xb, yb in test_loader:
        xb = xb.to(DEVICE)
        logits = model(xb)
        all_p.append(logits.argmax(1).cpu().numpy())
        all_l.append(yb.numpy())
        all_f.append(model.get_feat(xb).cpu().numpy())

preds  = np.concatenate(all_p)
labels = np.concatenate(all_l)
feats  = np.concatenate(all_f)

present = sorted(np.unique(labels))
cnames  = [LABEL_NAMES[i] for i in present]
test_acc = (preds == labels).mean()*100
print(f"  测试准确率: {test_acc:.2f}%")
print(classification_report(labels, preds, target_names=cnames, zero_division=0))

# ── 可视化 ───────────────────────────────────────────────────────────────────
print("\n[5/6] 生成可视化...")
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10,
    'axes.titlesize': 13, 'axes.labelsize': 11,
    'figure.dpi': 120, 'savefig.dpi': 150,
    'figure.facecolor': 'white'})
COLORS = plt.cm.tab10(np.linspace(0, 1, 12))

def short_name(n):
    """缩略标签名"""
    m = {
        'normal': 'Normal', 'normal_push': 'Normal(P)',
        'ding_fault_1': 'D-F1', 'ding_fault_12': 'D-F12',
        'ding_fault_13': 'D-F13', 'ding_fault_123': 'D-F123',
        'push_fault_1': 'P-F1', 'push_fault_12': 'P-F12',
        'push_fault_13': 'P-F13',
    }
    return m.get(n, n)

snames = [short_name(cnames[i]) for i in range(len(cnames))]

# ── 图1: 训练曲线 ──
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
ex = range(1, EPOCHS+1)
axes[0].plot(ex, tr_ls, label='Train Loss', color='royalblue', lw=2)
axes[0].plot(ex, va_ls, label='Val Loss',   color='tomato',    lw=2)
axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('Loss')
axes[0].set_title('Loss Curve'); axes[0].legend(); axes[0].grid(alpha=0.3)

axes[1].plot(ex, tr_ac, label='Train Acc', color='royalblue', lw=2)
axes[1].plot(ex, va_ac, label='Val Acc',   color='tomato',    lw=2)
axes[1].axhline(best_acc, ls='--', color='green', alpha=0.7, label=f'Best={best_acc:.1f}%')
axes[1].set_xlabel('Epoch'); axes[1].set_ylabel('Accuracy (%)')
axes[1].set_title('Accuracy Curve'); axes[1].legend(); axes[1].grid(alpha=0.3)

plt.suptitle('Robot Thruster Fault Diagnosis - Training', fontsize=14, fontweight='bold')
plt.tight_layout()
p1 = OUT/'01_training_curves.png'
plt.savefig(p1); plt.close()
print(f"  -> {p1}")

# ── 图2: 混淆矩阵 ──
cm = confusion_matrix(labels, preds, labels=present)
cm_n = cm.astype(float) / (cm.sum(axis=1, keepdims=True)+1e-8)

fig, axes = plt.subplots(1, 2, figsize=(18, 7))
for ax, d, t, fmt in zip(axes, [cm, cm_n],
        ['Confusion Matrix (Counts)', 'Confusion Matrix (Normalized)'], ['d', '.2f']):
    sns.heatmap(d, annot=True, fmt=fmt, cmap='Blues',
                xticklabels=snames, yticklabels=snames,
                ax=ax, linewidths=0.5, annot_kws={'size': 10})
    ax.set_xlabel('Predicted'); ax.set_ylabel('True'); ax.set_title(t)
    ax.tick_params(axis='x', rotation=35)

plt.suptitle(f'Confusion Matrix  Test Acc: {test_acc:.2f}%', fontsize=14, fontweight='bold')
plt.tight_layout()
p2 = OUT/'02_confusion_matrix.png'
plt.savefig(p2); plt.close()
print(f"  -> {p2}")

# ── 图3: t-SNE + PCA ──
print("  计算 t-SNE（样本数:", len(feats), ")...")
tsne = TSNE(n_components=2, perplexity=min(30, len(feats)-1), n_iter=1000, random_state=SEED)
tsne_emb = tsne.fit_transform(feats)
pca_emb  = PCA(n_components=2, random_state=SEED).fit_transform(feats)

fig, axes = plt.subplots(1, 2, figsize=(16, 7))
for ax, emb, title in zip(axes, [tsne_emb, pca_emb],
        ['t-SNE Feature Visualization', 'PCA Feature Visualization']):
    for ci, (lbl, sname) in enumerate(zip(present, snames)):
        m = labels == lbl
        ax.scatter(emb[m, 0], emb[m, 1], label=sname, alpha=0.75, s=30,
                   color=COLORS[ci%12])
    ax.set_title(title); ax.legend(fontsize=9, markerscale=1.5)
    ax.set_xlabel('Component 1'); ax.set_ylabel('Component 2'); ax.grid(alpha=0.2)

plt.suptitle('Feature Space Visualization', fontsize=14, fontweight='bold')
plt.tight_layout()
p3 = OUT/'03_feature_tsne.png'
plt.savefig(p3); plt.close()
print(f"  -> {p3}")

# ── 图4: 各类准确率 ──
per_cls = []
for lbl in present:
    m = labels == lbl
    per_cls.append((preds[m]==labels[m]).mean()*100 if m.sum()>0 else 0.0)

fig, ax = plt.subplots(figsize=(14, 6))
bars = ax.bar(range(len(cnames)), per_cls,
              color=[COLORS[i%12] for i in range(len(cnames))], edgecolor='white')
for bar, v in zip(bars, per_cls):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.5,
            f'{v:.0f}%', ha='center', va='bottom', fontsize=10)
ax.set_xticks(range(len(cnames))); ax.set_xticklabels(snames, fontsize=10)
ax.set_ylim(0, 115); ax.set_ylabel('Accuracy (%)')
ax.set_title(f'Per-Class Accuracy  (Overall: {test_acc:.2f}%)', fontweight='bold')
ax.axhline(test_acc, ls='--', color='gray', alpha=0.6)
ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
p4 = OUT/'04_per_class_accuracy.png'
plt.savefig(p4); plt.close()
print(f"  -> {p4}")

# ── 图5: 原始数据热力图 ──
print("\n[6/6] 生成诊断报告图...")
try:
    from thruster_robot_data import DING_FILES, QIAN_FILES, BASE_DING, BASE_QIAN, read_excel_robust, THRUSTER_NAMES
    import pandas as pd

    fig, axes = plt.subplots(3, 3, figsize=(20, 16))
    axes = axes.flatten()

    all_files = []
    for fname, lbl in list(DING_FILES.items()) + list(QIAN_FILES.items()):
        all_files.append((fname, lbl, BASE_DING if fname in DING_FILES else BASE_QIAN))

    for idx, (fname, lbl, base) in enumerate(all_files[:9]):
        if idx >= 9: break
        ax = axes[idx]
        fpath = base / f'{fname}.xlsx'
        df = read_excel_robust(str(fpath))
        if df is None:
            ax.text(0.5, 0.5, f'Not found:\n{fname}', ha='center', va='center', transform=ax.transAxes)
            ax.set_title(short_name(lbl))
            continue
        tnames = [n for n in THRUSTER_NAMES if n in df.columns]
        vals = df[tnames].values.astype(float)
        vals_norm = (vals - vals.mean(axis=0, keepdims=True)) / (vals.std(axis=0, keepdims=True)+1e-8)
        sns.heatmap(vals_norm.T, ax=ax, cmap='RdBu_r', center=0,
                    yticklabels=tnames, xticklabels=False,
                    cbar_kws={'shrink': 0.6})
        ax.set_title(f'{short_name(lbl)} ({fname[-14:-5]})', fontsize=11)
        ax.set_ylabel('Thruster'); ax.set_xlabel('Time')

    for i in range(len(all_files), 9):
        axes[i].axis('off')

    plt.suptitle('Thruster Signal Heatmap by Fault Type', fontsize=14, fontweight='bold')
    plt.tight_layout()
    p5 = OUT/'05_thruster_heatmaps.png'
    plt.savefig(p5); plt.close()
    print(f"  -> {p5}")
except Exception as e:
    print(f"  热力图跳过: {e}")

# ── 图6: 汇总 ──
fig = plt.figure(figsize=(22, 18))
gs  = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(range(1, EPOCHS+1), tr_ls, label='Train', color='royalblue', lw=2)
ax1.plot(range(1, EPOCHS+1), va_ls, label='Val',   color='tomato',    lw=2)
ax1.set_title('Loss'); ax1.legend(); ax1.grid(alpha=0.3)

ax2 = fig.add_subplot(gs[0, 1])
ax2.plot(range(1, EPOCHS+1), tr_ac, label='Train', color='royalblue', lw=2)
ax2.plot(range(1, EPOCHS+1), va_ac, label='Val',   color='tomato',    lw=2)
ax2.axhline(best_acc, ls='--', color='green', alpha=0.7)
ax2.set_title('Accuracy'); ax2.legend(); ax2.grid(alpha=0.3)

ax3 = fig.add_subplot(gs[0, 2])
ax3.bar(range(len(cnames)), per_cls, color=[COLORS[i%12] for i in range(len(cnames))])
ax3.set_xticks(range(len(cnames))); ax3.set_xticklabels(snames, rotation=30, ha='right', fontsize=9)
ax3.set_title('Per-Class Acc'); ax3.grid(axis='y', alpha=0.3)

ax4 = fig.add_subplot(gs[1, 0:2])
sns.heatmap(cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=snames, yticklabels=snames,
            ax=ax4, linewidths=0.5, annot_kws={'size': 9})
ax4.set_xlabel('Predicted'); ax4.set_ylabel('True')
ax4.set_title('Normalized Confusion Matrix')
ax4.tick_params(axis='x', rotation=35)

ax5 = fig.add_subplot(gs[1, 2])
for ci, (lbl, sname) in enumerate(zip(present, snames)):
    m = labels == lbl
    ax5.scatter(tsne_emb[m,0], tsne_emb[m,1], label=sname, alpha=0.7, s=20, color=COLORS[ci%12])
ax5.set_title('t-SNE'); ax5.legend(fontsize=8, markerscale=1.2); ax5.grid(alpha=0.2)

fig.suptitle(f'Robot Thruster Fault Diagnosis — Complete Results\n'
             f'Best Val Acc: {best_acc:.2f}%  |  Test Acc: {test_acc:.2f}%',
             fontsize=15, fontweight='bold')
p0 = OUT/'00_summary.png'
plt.savefig(p0, bbox_inches='tight'); plt.close()
print(f"  -> {p0}")

# ── 保存模型 ──────────────────────────────────────────────────────────────────
torch.save({'model_state': best_state, 'feat_dim': feat_dim,
            'scaler': scaler, 'best_acc': best_acc, 'label_names': LABEL_NAMES,
            'fault_labels': FAULT_LABELS},
           OUT/'best_model.pt')

print(f"\n{'='*60}")
print(f"  训练完成！")
print(f"  最佳验证准确率: {best_acc:.2f}%")
print(f"  最终测试准确率: {test_acc:.2f}%")
print(f"  结果保存至:     {OUT}")
print(f"{'='*60}")

# ── 诊断演示：对每个测试文件做预测 ─────────────────────────────────────────────
print("\n[诊断演示] 对原始数据文件进行逐一诊断...")
model.eval()
demo_results = []

for fname, lbl_key in list(DING_FILES.items()) + list(QIAN_FILES.items()):
    base = BASE_DING if fname in DING_FILES else BASE_QIAN
    fpath = base / f'{fname}.xlsx'
    df = read_excel_robust(str(fpath))
    if df is None:
        continue
    from thruster_robot_data import extract_thruster_features
    feat = extract_thruster_features(df)[None, :]
    feat_s = scaler.transform(feat)
    xb = torch.tensor(feat_s, dtype=torch.float32).to(DEVICE)
    with torch.no_grad():
        logits = model(xb)
        probs  = torch.softmax(logits, dim=1)[0].cpu().numpy()
        pred   = logits.argmax(1).item()

    true_lbl = FAULT_LABELS[lbl_key]
    status = "OK" if pred == true_lbl else "NG"
    print(f"  {status} {fname}  真实={short_name(lbl_key):12s}  预测={short_name(LABEL_NAMES[pred]):12s}  " 
          f"置信度={probs[pred]*100:.1f}%")
    demo_results.append({
        'file': fname, 'true': lbl_key, 'pred': LABEL_NAMES[pred],
        'correct': pred==true_lbl, 'confidence': probs[pred]*100})

print(f"\n  文件级诊断准确率: {sum(1 for r in demo_results if r['correct'])/len(demo_results)*100:.1f}%")
