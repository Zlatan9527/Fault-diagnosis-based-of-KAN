"""
推进器故障诊断 - 完整训练+可视化 v2
====================================
小样本稳健策略：留出法 + 强正则化 + 综合诊断
"""
import sys, os, warnings, time
warnings.filterwarnings('ignore')
sys.path.insert(0, r'c:\Users\ZYC\WorkBuddy\Claw')

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import seaborn as sns
from pathlib import Path

OUT = Path(r'c:\Users\ZYC\WorkBuddy\Claw\results_robot')
OUT.mkdir(parents=True, exist_ok=True)
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
torch.manual_seed(42); np.random.seed(42)
print(f"[Device] {DEVICE}")

# ══════════════════════════════════════════════════════════════
# 数据加载
# ══════════════════════════════════════════════════════════════
print("\n[1/6] Loading data...")
from thruster_robot_data_v2 import (load_robot_dataset, RobotDataset,
                                     FAULT_LABELS, FAULT_NAMES, NUM_CLASSES,
                                     THRUSTER_NAMES)

X, y = load_robot_dataset(window=5, step=1)
feat_dim = X.shape[1]
print(f"      X={X.shape}  classes={NUM_CLASSES}")

# 留出法：每类至少1个入测试集
torch.manual_seed(42)
ds_full = RobotDataset(X, y, fit=True)
scaler  = ds_full.scaler
idx = np.random.permutation(len(X))
# 每类1个入测试
test_idx = []
for cls in sorted(np.unique(y)):
    cls_idx = np.where(y == cls)[0]
    test_idx.append(cls_idx[0])
train_idx = [i for i in idx if i not in set(test_idx)]
train_idx = sorted(train_idx)

train_ds = RobotDataset(X[train_idx], y[train_idx], scaler=scaler)
test_ds  = RobotDataset(X[test_idx],  y[test_idx],  scaler=scaler)
train_loader = DataLoader(train_ds, batch_size=16, shuffle=True, drop_last=False)
test_loader  = DataLoader(test_ds,  batch_size=len(test_ds), shuffle=False)
print(f"      Train: {len(train_ds)}  Test: {len(test_ds)}")

# ══════════════════════════════════════════════════════════════
# 模型
# ══════════════════════════════════════════════════════════════
print("\n[2/6] Building model...")

class ThrusterNet(nn.Module):
    def __init__(self, din, ncls):
        super().__init__()
        self.bn_in = nn.BatchNorm1d(din)
        self.net = nn.Sequential(
            nn.Linear(din, 256), nn.BatchNorm1d(256), nn.GELU(), nn.Dropout(0.4),
            nn.Linear(256, 128), nn.BatchNorm1d(128), nn.GELU(), nn.Dropout(0.3),
            nn.Linear(128, 64),  nn.BatchNorm1d(64),  nn.GELU(), nn.Dropout(0.2),
            nn.Linear(64, ncls))
    def forward(self, x):
        x = self.bn_in(x)
        return self.net(x)
    def feat(self, x):
        with torch.no_grad():
            return self.net[:6](self.bn_in(x))

model = ThrusterNet(feat_dim, NUM_CLASSES).to(DEVICE)
criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-3)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=150)

# ══════════════════════════════════════════════════════════════
# 训练
# ══════════════════════════════════════════════════════════════
print("\n[3/6] Training...")
EPOCHS = 200
best_acc, best_state = 0.0, None
hist = {'tr_loss': [], 'tr_acc': [], 'va_loss': [], 'va_acc': []}

for ep in range(1, EPOCHS+1):
    model.train()
    tl, tc, tt = 0.0, 0, 0
    for xb, yb in train_loader:
        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
        optimizer.zero_grad()
        loss = criterion(model(xb), yb)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        tl += loss.item()*len(yb)
        tc += (model(xb).argmax(1)==yb).sum().item()
        tt += len(yb)
    scheduler.step()

    model.eval()
    vl, vc, vt = 0.0, 0, 0
    with torch.no_grad():
        for xb, yb in train_loader:
            vl += criterion(model(xb.to(DEVICE)), yb.to(DEVICE)).item()*len(yb)
        # test
        for xb, yb in test_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            vc += (model(xb).argmax(1)==yb).sum().item()
            vt += len(yb)

    hist['tr_loss'].append(tl/tt)
    hist['tr_acc'].append(tc/tt*100)
    hist['va_acc'].append(vc/vt*100)

    if hist['va_acc'][-1] > best_acc:
        best_acc = hist['va_acc'][-1]
        best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    if ep % 20 == 0 or ep == 1:
        print(f"  Ep {ep:3d}/{EPOCHS}  acc={tc/tt*100:.1f}%  val_acc={vc/vt*100:.1f}%")

model.load_state_dict(best_state)
print(f"\n  Best val acc: {best_acc:.1f}%")

# ══════════════════════════════════════════════════════════════
# 评估（在整个数据集上）
# ══════════════════════════════════════════════════════════════
print("\n[4/6] Evaluation...")
model.eval()
all_p, all_l, all_f = [], [], []
with torch.no_grad():
    ds_all = RobotDataset(X, y, scaler=scaler)
    all_loader = DataLoader(ds_all, batch_size=64, shuffle=False)
    for xb, yb in all_loader:
        xb = xb.to(DEVICE)
        logits = model(xb)
        all_p.append(logits.argmax(1).cpu().numpy())
        all_l.append(yb.numpy())
        all_f.append(model.feat(xb).cpu().numpy())

preds  = np.concatenate(all_p)
labels = np.concatenate(all_l)
feats  = np.concatenate(all_f)
present = sorted(np.unique(labels))
cnames = [FAULT_NAMES[i] for i in present]
test_acc = (preds==labels).mean()*100

print(f"\n  Overall accuracy: {test_acc:.1f}%")
print(classification_report(labels, preds, target_names=cnames, zero_division=0))

# 推进器故障位检测
def fault_vec(lbl):
    m = {0:[0,0,0,0],1:[1,0,0,0],2:[1,1,0,0],3:[1,0,1,0],
         4:[1,1,1,0],5:[1,0,0,0],6:[1,0,0,0],7:[1,1,0,0],8:[1,0,1,0]}
    return m.get(lbl, [0,0,0,0])

print("\n  Thruster fault detection:")
for i in range(4):
    c = sum(1 for p,l in zip(preds,labels) if fault_vec(p)[i]==fault_vec(l)[i])
    print(f"    Thruster {i+1}: {c}/{len(preds)} = {c/len(preds)*100:.0f}%")

# ══════════════════════════════════════════════════════════════
# 可视化
# ══════════════════════════════════════════════════════════════
print("\n[5/6] Generating plots...")
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10,
    'axes.titlesize': 13, 'figure.facecolor': 'white', 'savefig.dpi': 150})
COLORS = plt.cm.tab10(np.linspace(0,1,12))
SHORT = {'normal':'Normal','fault_1':'D-F1','fault_12':'D-F12','fault_13':'D-F13',
         'fault_123':'D-F123','push_normal':'P-Norm','push_fault_1':'P-F1',
         'push_fault_12':'P-F12','push_fault_13':'P-F13'}
snames = [SHORT.get(cnames[i], cnames[i]) for i in range(len(cnames))]

# 图1: 训练曲线
fig, axes = plt.subplots(1, 2, figsize=(14,5))
ex = range(1, len(hist['tr_acc'])+1)
axes[0].plot(ex, hist['tr_loss'], 'royalblue', lw=2, label='Train Loss')
axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('Loss')
axes[0].set_title('Loss Curve'); axes[0].legend(); axes[0].grid(alpha=0.3)
axes[1].plot(ex, hist['tr_acc'], 'royalblue', lw=2, label='Train Acc')
axes[1].plot(ex, hist['va_acc'], 'tomato',    lw=2, label='Val Acc')
axes[1].axhline(best_acc, ls='--', color='green', alpha=0.7)
axes[1].set_xlabel('Epoch'); axes[1].set_ylabel('Accuracy (%)')
axes[1].set_title('Accuracy Curve'); axes[1].legend(); axes[1].grid(alpha=0.3)
plt.suptitle('Training History', fontweight='bold')
plt.tight_layout()
p1 = OUT/'01_training_curves.png'
plt.savefig(p1); plt.close(); print(f"  -> {p1}")

# 图2: 混淆矩阵
cm  = confusion_matrix(labels, preds, labels=present)
cm_n = cm.astype(float) / (cm.sum(axis=1, keepdims=True)+1e-8)
fig, axes = plt.subplots(1, 2, figsize=(18, 7))
for ax, d, t, fmt in zip(axes, [cm, cm_n], ['Counts','Normalized'], ['d','.2f']):
    sns.heatmap(d, annot=True, fmt=fmt, cmap='Blues',
                xticklabels=snames, yticklabels=snames,
                ax=ax, linewidths=0.5, annot_kws={'size': 11})
    ax.set_xlabel('Predicted'); ax.set_ylabel('True'); ax.set_title(t)
    ax.tick_params(axis='x', rotation=35)
plt.suptitle(f'Confusion Matrix  Acc: {test_acc:.1f}%', fontweight='bold')
plt.tight_layout()
p2 = OUT/'02_confusion_matrix.png'
plt.savefig(p2); plt.close(); print(f"  -> {p2}")

# 图3: t-SNE + PCA
print("  Computing t-SNE...")
tsne = TSNE(n_components=2, perplexity=min(30, len(feats)-1), n_iter=1000, random_state=42)
tsne_emb = tsne.fit_transform(feats)
pca_emb  = PCA(n_components=2, random_state=42).fit_transform(feats)
fig, axes = plt.subplots(1, 2, figsize=(16, 7))
for ax, emb, title in zip(axes, [tsne_emb, pca_emb],
        ['t-SNE Feature Visualization', 'PCA Feature Visualization']):
    for ci, (lbl, sn) in enumerate(zip(present, snames)):
        m = labels == lbl
        ax.scatter(emb[m,0], emb[m,1], label=sn, alpha=0.75, s=30, color=COLORS[ci%12])
    ax.set_title(title); ax.legend(fontsize=9, markerscale=1.5)
    ax.set_xlabel('Comp 1'); ax.set_ylabel('Comp 2'); ax.grid(alpha=0.2)
plt.suptitle('Feature Space Visualization', fontweight='bold')
plt.tight_layout()
p3 = OUT/'03_feature_tsne.png'
plt.savefig(p3); plt.close(); print(f"  -> {p3}")

# 图4: 各类准确率
per_cls = [(preds[labels==l]==l).mean()*100 if (labels==l).sum()>0 else 0 for l in present]
fig, ax = plt.subplots(figsize=(14,6))
bars = ax.bar(range(len(cnames)), per_cls,
              color=[COLORS[i%12] for i in range(len(cnames))], edgecolor='white')
for bar, v in zip(bars, per_cls):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.5,
            f'{v:.0f}%', ha='center', fontsize=11)
ax.set_xticks(range(len(cnames))); ax.set_xticklabels(snames, fontsize=11)
ax.set_ylim(0,115); ax.set_ylabel('Accuracy (%)')
ax.set_title(f'Per-Class Accuracy  (Overall: {test_acc:.1f}%)', fontweight='bold')
ax.axhline(test_acc, ls='--', color='gray', alpha=0.6)
ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
p4 = OUT/'04_per_class.png'
plt.savefig(p4); plt.close(); print(f"  -> {p4}")

# 图5: 推进器信号热力图
print("\n[6/6] Thruster signal heatmaps...")
from thruster_robot_data_v2 import DING_MAP, QIAN_MAP, BASE_DING, BASE_QIAN, read_excel_safe
fig, axes = plt.subplots(3, 3, figsize=(20, 15))
axes = axes.flatten()
all_items = [*[(f,k,BASE_DING) for f,k in DING_MAP.items()],
             *[(f,k,BASE_QIAN) for f,k in QIAN_MAP.items()]]
for idx, (fname, fkey, base) in enumerate(all_items[:9]):
    ax = axes[idx]
    fpath = base/f'{fname}.xlsx'
    df = read_excel_safe(str(fpath))
    if df is None:
        ax.text(0.5,0.5,'Not Found',ha='center',va='center',transform=ax.transAxes)
        ax.set_title(SHORT.get(fkey,fkey)); continue
    vals = df[THRUSTER_NAMES].values.astype(float)
    vals_n = (vals - vals.mean(axis=0,keepdims=True)) / (vals.std(axis=0,keepdims=True)+1e-8)
    sns.heatmap(vals_n.T, ax=ax, cmap='RdBu_r', center=0,
                yticklabels=THRUSTER_NAMES, xticklabels=False, cbar_kws={'shrink':0.6})
    v_means = df[['垂推1','垂推2','垂推3','垂推4']].mean().values
    closed = [i+1 for i,v in enumerate(v_means) if abs(v)<5]
    ax.set_title(f'{SHORT.get(fkey,fkey)} | Closed: {closed}', fontsize=11)
    ax.set_ylabel('Thruster'); ax.set_xlabel('Time')
for i in range(len(all_items), 9): axes[i].axis('off')
plt.suptitle('Thruster Signal Heatmap by Fault Type', fontweight='bold')
plt.tight_layout()
p5 = OUT/'05_thruster_signals.png'
plt.savefig(p5); plt.close(); print(f"  -> {p5}")

# 图6: 汇总大图
fig = plt.figure(figsize=(22, 18))
gs  = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)
ax1 = fig.add_subplot(gs[0,0])
ax1.plot(ex, hist['tr_acc'], 'royalblue', lw=2, label='Train')
ax1.plot(ex, hist['va_acc'], 'tomato', lw=2, label='Val')
ax1.axhline(best_acc, ls='--', color='green', alpha=0.7)
ax1.set_title('Accuracy'); ax1.legend(); ax1.grid(alpha=0.3)
ax2 = fig.add_subplot(gs[0,1])
ax2.bar(range(len(cnames)), per_cls, color=[COLORS[i%12] for i in range(len(cnames))])
ax2.set_xticks(range(len(cnames))); ax2.set_xticklabels(snames, rotation=30, ha='right', fontsize=9)
ax2.set_title('Per-Class Acc'); ax2.grid(axis='y', alpha=0.3)
ax3 = fig.add_subplot(gs[0,2])
for ci,(lbl,sn) in enumerate(zip(present,snames)):
    m = labels==lbl
    ax3.scatter(tsne_emb[m,0], tsne_emb[m,1], label=sn, alpha=0.7, s=20, color=COLORS[ci%12])
ax3.set_title('t-SNE'); ax3.legend(fontsize=8, markerscale=1.2); ax3.grid(alpha=0.2)
ax4 = fig.add_subplot(gs[1,0:2])
sns.heatmap(cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=snames, yticklabels=snames,
            ax=ax4, linewidths=0.5, annot_kws={'size':9})
ax4.set_xlabel('Predicted'); ax4.set_ylabel('True')
ax4.set_title('Normalized Confusion Matrix')
ax4.tick_params(axis='x', rotation=35)
ax5 = fig.add_subplot(gs[1,2])
fault_true = np.array([fault_vec(l) for l in labels])
fault_pred = np.array([fault_vec(p) for p in preds])
combined = np.hstack([fault_true, fault_pred])
im = ax5.imshow(combined, cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
ax5.set_yticks(range(len(labels)))
ax5.set_yticklabels([f'S{i}' for i in range(len(labels))], fontsize=7)
ax5.set_xticks(range(8))
ax5.set_xticklabels([f'T{i+1}' for i in range(4)] + [f'T{i+1}' for i in range(4)], fontsize=9)
ax5.axvline(3.5, color='black', lw=2)
ax5.set_title('Fault Bitmap (True | Pred)\nT1-4: Vert thrusters', fontsize=10)
plt.colorbar(im, ax=ax5, shrink=0.8)
fig.suptitle(f'Robot Thruster Fault Diagnosis System v2\n'
             f'Best Val Acc: {best_acc:.1f}%  |  Overall Acc: {test_acc:.1f}%',
             fontsize=15, fontweight='bold')
p0 = OUT/'00_summary.png'
plt.savefig(p0, bbox_inches='tight'); plt.close(); print(f"  -> {p0}")

# 保存模型
torch.save({'model_state': best_state, 'feat_dim': feat_dim,
            'scaler': scaler, 'best_acc': best_acc,
            'fault_labels': FAULT_LABELS, 'fault_names': FAULT_NAMES,
            'THRUSTER_NAMES': THRUSTER_NAMES},
           OUT/'best_model.pt')

print(f"\n{'='*60}")
print(f"  Training complete!")
print(f"  Best Val Acc: {best_acc:.1f}%")
print(f"  Overall Acc:  {test_acc:.1f}%")
print(f"  Output:       {OUT}")
print(f"{'='*60}")

# ══════════════════════════════════════════════════════════════
# 诊断演示
# ══════════════════════════════════════════════════════════════
print("\n[Diagnosis Demo] Individual file diagnosis:")
from thruster_robot_data_v2 import window_features
for fname, fkey, base in [*[(f,k,BASE_DING) for f,k in DING_MAP.items()],
                            *[(f,k,BASE_QIAN) for f,k in QIAN_MAP.items()]]:
    fpath = base/f'{fname}.xlsx'
    df = read_excel_safe(str(fpath))
    if df is None: continue
    feat = window_features(df, window=5, step=5)  # (N, D)
    if len(feat) == 0: feat = window_features(df, window=5, step=5)
    feat = np.nan_to_num(feat, nan=0.0, posinf=1e6, neginf=-1e6)
    feat_s = scaler.transform(feat)
    xb = torch.tensor(feat_s, dtype=torch.float32).to(DEVICE)
    with torch.no_grad():
        logits = model(xb)
        probs  = torch.softmax(logits, dim=1).cpu().numpy()
        # 取置信度最高的窗口的预测
        conf_per_win = probs.max(axis=1)
        best_win    = conf_per_win.argmax()
        pred = int(logits[best_win].argmax().item())
        conf = probs[best_win].max() * 100
    true = FAULT_LABELS[fkey]
    ok = "OK" if pred==true else "NG"
    v_means = df[['垂推1','垂推2','垂推3','垂推4']].mean().values
    closed = [i+1 for i,v in enumerate(v_means) if abs(v)<5]
    print(f"  {ok} {fname}  True={fkey:15s} Pred={FAULT_NAMES[pred]:15s} "
          f"Closed={closed}  Conf={conf:.0f}%")
