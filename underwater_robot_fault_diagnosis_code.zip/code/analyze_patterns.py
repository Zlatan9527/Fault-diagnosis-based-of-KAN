import pandas as pd, numpy as np
from pathlib import Path

BASE_DING = Path(r'E:\范小龙\数据\数据\定向数据')
BASE_QIAN = Path(r'E:\范小龙\数据\数据\手柄前推数据')

files = {
    'D-normal':     BASE_DING / '2025-01-05_17-26-54.xlsx',
    'D-f1_off':     BASE_DING / '2025-01-05_17-29-52.xlsx',
    'D-f12_off':    BASE_DING / '2025-01-05_17-32-17.xlsx',
    'D-f12_off2':   BASE_DING / '2025-01-05_17-34-39.xlsx',
    'D-f13_off':    BASE_DING / '2025-01-05_17-36-18.xlsx',
    'D-f123_off':   BASE_DING / '2025-01-05_17-41-23.xlsx',
    'P-normal':     BASE_QIAN / '2025-01-05_17-45-03.xlsx',
    'P-f12_off':    BASE_QIAN / '2025-01-05_18-00-14.xlsx',
    'P-f13_off':    BASE_QIAN / '2025-01-05_18-02-16.xlsx',
}

labels = {
    'D-normal':   ('D', ''),
    'D-f1_off':   ('D', 'f1'),
    'D-f12_off':  ('D', 'f1+2'),
    'D-f12_off2': ('D', 'f1+2'),
    'D-f13_off':  ('D', 'f1+3'),
    'D-f123_off': ('D', 'f1+2+3'),
    'P-normal':   ('P', ''),
    'P-f12_off':  ('P', 'f1+2'),
    'P-f13_off':  ('P', 'f1+3'),
}

print('='*100)
print(f'{"文件":25s} {"模式":6s} {"故障":12s} {"垂1":>8s} {"垂2":>8s} {"垂3":>8s} {"垂4":>8s} {"行数":>5s} {"关闭":>10s}')
print('='*100)

for name, fpath in files.items():
    if not fpath.exists():
        print(f'{name:25s} FILE NOT FOUND')
        continue
    df = pd.read_excel(str(fpath))
    mode, off = labels[name]
    ct_cols = [c for c in df.columns if '垂推' in c]
    means = [df[c].mean() for c in ct_cols]
    zero_thrusters = [i+1 for i, m in enumerate(means) if abs(m) < 5]
    print(f'{name:25s} {mode:6s} f{off:>11s} '
          f'{means[0]:8.1f} {means[1]:8.1f} {means[2]:8.1f} {means[3]:8.1f} '
          f'{len(df):5d}  '
          f'{str(zero_thrusters):>10s}')
