"""
推进器故障诊断 - 训练 + 可视化一体脚本
运行方式: python train_and_visualize.py
"""
import sys, os, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, 'E:/KAN/pykan-master')
sys.path.insert(0, r'c:\Users\ZYC\WorkBuddy\Claw')

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import seaborn as sns
from pathlib import Path
import time

# ── 路径配置 ──────────────────────────────────────────────────────────────────
DATA_DIR   = r'G:\实验数据\0_水池故障模拟实验_先看这里面的说明\Dataset'
OUTPUT_DIR = r'c:\Users\ZYC\WorkBuddy\Claw\results'
Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

DEVICE     = 'cuda' if torch.cuda.is_available() else 'cpu'
EPOCHS     = 60
BATCH_SIZE = 64
LR         = 1e-3
SEED       = 42

torch.manual_seed(SEED)
np.random.seed(SEED)
print(f"[设备] {DEVICE}")

# ── 导入自定义模块 ─────────────────────────────────────────────────────────────
from data_loader import (build_dataloaders, CLASS_NAMES, NUM_CLASSES,
                         load_dataset_from_dir, ThrusterDataset)
from sklearn.preprocessing import StandardScaler

# ── 模型定义（内嵌，不依赖 thruster_kan.py） ──────────────────────────────────
class ResBlock(nn.Module):
    def __init__(self, dim, dropout=0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim), nn.LayerNorm(dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(dim, dim), nn.LayerNorm(dim),
        )
    def forward(self, x): return x + self.net(x)

class ThrusterNet(nn.Module):
    def __init__(self, input_dim, num_classes=8):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256), nn.LayerNorm(256), nn.GELU(), nn.Dropout(0.2),
            nn.Linear(256, 128), nn.LayerNorm(128), nn.GELU(), nn.Dropout(0.15),
            ResBlock(128), ResBlock(128),
            nn.Linear(128, 64), nn.LayerNorm(64), nn.GELU(), nn.Dropout(0.1),
        )
        self.head = nn.Linear(64, num_classes)

    def forward(self, x):
        feat = self.encoder(x)
        return self.head(feat)

    def get_feature(self, x):
        with torch.no_grad():
            return self.encoder(x)

# ── 数据加载 ──────────────────────────────────────────────────────────────────
print("\n[1/5] 加载数据...")
train_loader, test_loader, scaler, feat_dim = build_dataloaders(
    DATA_DIR, batch_size=BATCH_SIZE, window_size=200, step=100,
    feature_mode='stat', fs=100.0)

# ── 模型 / 损失 / 优化器 ──────────────────────────────────────────────────────
print("\n[2/5] 初始化模型...")
model = ThrusterNet(input_dim=feat_dim, num_classes=NUM_CLASSES).to(DEVICE)
total_params = sum(p.numel() for p in model.parameters())
print(f"      参数量: {total_params:,}  输入维度: {feat_dim}")

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

# ── 训练循环 ──────────────────────────────────────────────────────────────────
print("\n[3/5] 开始训练...")
train_losses, train_accs, val_losses, val_accs = [], [], [], []
best_val_acc = 0.0
best_state   = None

for epoch in range(1, EPOCHS + 1):
    # --- train ---
    model.train()
    t_loss, t_correct, t_total = 0.0, 0, 0
    for xb, yb in train_loader:
        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
        optimizer.zero_grad()
        logits = model(xb)
        loss   = criterion(logits, yb)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        t_loss    += loss.item() * len(yb)
        t_correct += (logits.argmax(1) == yb).sum().item()
        t_total   += len(yb)
    scheduler.step()

    # --- val ---
    model.eval()
    v_loss, v_correct, v_total = 0.0, 0, 0
    with torch.no_grad():
        for xb, yb in test_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            logits  = model(xb)
            v_loss += criterion(logits, yb).item() * len(yb)
            v_correct += (logits.argmax(1) == yb).sum().item()
            v_total   += len(yb)

    tr_loss = t_loss / t_total;  tr_acc = t_correct / t_total * 100
    va_loss = v_loss / v_total;  va_acc = v_correct / v_total * 100
    train_losses.append(tr_loss); train_accs.append(tr_acc)
    val_losses.append(va_loss);   val_accs.append(va_acc)

    if va_acc > best_val_acc:
        best_val_acc = va_acc
        best_state   = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    if epoch % 10 == 0 or epoch == 1:
        print(f"  Epoch {epoch:3d}/{EPOCHS}  "
              f"train_loss={tr_loss:.4f}  train_acc={tr_acc:.1f}%  "
              f"val_loss={va_loss:.4f}  val_acc={va_acc:.1f}%")

print(f"\n  最佳验证准确率: {best_val_acc:.2f}%")
model.load_state_dict(best_state)
torch.save({'model_state': best_state, 'feat_dim': feat_dim,
            'scaler': scaler, 'best_val_acc': best_val_acc},
           os.path.join(OUTPUT_DIR, 'best_model.pt'))
print(f"  模型已保存到 {OUTPUT_DIR}/best_model.pt")

# ── 评估 & 收集预测 ───────────────────────────────────────────────────────────
print("\n[4/5] 最终评估...")
model.eval()
all_preds, all_labels, all_feats = [], [], []
with torch.no_grad():
    for xb, yb in test_loader:
        xb = xb.to(DEVICE)
        logits = model(xb)
        feat   = model.get_feature(xb)
        all_preds.append(logits.argmax(1).cpu().numpy())
        all_labels.append(yb.numpy())
        all_feats.append(feat.cpu().numpy())

preds  = np.concatenate(all_preds)
labels = np.concatenate(all_labels)
feats  = np.concatenate(all_feats)

# 类别名列表（按标签排序）
present_classes = sorted(np.unique(labels))
class_name_list = [CLASS_NAMES[i] for i in present_classes]
test_acc = (preds == labels).mean() * 100
print(f"  测试准确率: {test_acc:.2f}%")
print("\n  分类报告:")
print(classification_report(labels, preds,
      target_names=class_name_list, zero_division=0))

# ── 可视化 ────────────────────────────────────────────────────────────────────
print("\n[5/5] 生成可视化结果...")
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 11,
    'axes.titlesize': 13, 'axes.labelsize': 11,
    'figure.dpi': 120, 'savefig.dpi': 150,
    'figure.facecolor': 'white',
})
COLORS = plt.cm.tab10(np.linspace(0, 1, 10))

# ── 图1: 训练曲线 ─────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
epochs_x = range(1, EPOCHS + 1)

axes[0].plot(epochs_x, train_losses, label='Train Loss', color='royalblue', lw=2)
axes[0].plot(epochs_x, val_losses,   label='Val Loss',   color='tomato',    lw=2)
axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('Loss')
axes[0].set_title('Training & Validation Loss')
axes[0].legend(); axes[0].grid(alpha=0.3)

axes[1].plot(epochs_x, train_accs, label='Train Acc', color='royalblue', lw=2)
axes[1].plot(epochs_x, val_accs,   label='Val Acc',   color='tomato',    lw=2)
axes[1].axhline(best_val_acc, ls='--', color='green', alpha=0.7,
                label=f'Best={best_val_acc:.1f}%')
axes[1].set_xlabel('Epoch'); axes[1].set_ylabel('Accuracy (%)')
axes[1].set_title('Training & Validation Accuracy')
axes[1].legend(); axes[1].grid(alpha=0.3)

plt.suptitle('Thruster Fault Diagnosis - Training History', fontsize=14, fontweight='bold')
plt.tight_layout()
p1 = os.path.join(OUTPUT_DIR, '01_training_curves.png')
plt.savefig(p1); plt.close()
print(f"  -> {p1}")

# ── 图2: 混淆矩阵 ─────────────────────────────────────────────────────────────
cm = confusion_matrix(labels, preds, labels=present_classes)
cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-8)

fig, axes = plt.subplots(1, 2, figsize=(16, 7))
for ax, data, title, fmt in zip(
        axes,
        [cm, cm_norm],
        ['Confusion Matrix (Counts)', 'Confusion Matrix (Normalized)'],
        ['d', '.2f']):
    sns.heatmap(data, annot=True, fmt=fmt, cmap='Blues',
                xticklabels=class_name_list,
                yticklabels=class_name_list,
                ax=ax, linewidths=0.5)
    ax.set_xlabel('Predicted'); ax.set_ylabel('True')
    ax.set_title(title)
    ax.tick_params(axis='x', rotation=30)

plt.suptitle(f'Confusion Matrix  (Test Acc: {test_acc:.2f}%)',
             fontsize=14, fontweight='bold')
plt.tight_layout()
p2 = os.path.join(OUTPUT_DIR, '02_confusion_matrix.png')
plt.savefig(p2); plt.close()
print(f"  -> {p2}")

# ── 图3: t-SNE 特征可视化 ─────────────────────────────────────────────────────
print("  计算 t-SNE（可能需要约30秒）...")
# 若样本太多，随机采样 2000 个
if len(feats) > 2000:
    idx = np.random.choice(len(feats), 2000, replace=False)
    feats_s, labels_s = feats[idx], labels[idx]
else:
    feats_s, labels_s = feats, labels

tsne = TSNE(n_components=2, perplexity=30, n_iter=1000, random_state=SEED)
tsne_emb = tsne.fit_transform(feats_s)

pca  = PCA(n_components=2, random_state=SEED)
pca_emb = pca.fit_transform(feats_s)

fig, axes = plt.subplots(1, 2, figsize=(16, 7))
for ax, emb, title in zip(
        axes, [tsne_emb, pca_emb],
        ['t-SNE Feature Visualization', 'PCA Feature Visualization']):
    for ci, cls_idx in enumerate(present_classes):
        mask = labels_s == cls_idx
        ax.scatter(emb[mask, 0], emb[mask, 1],
                   label=CLASS_NAMES[cls_idx], alpha=0.7, s=18,
                   color=COLORS[ci % 10])
    ax.set_title(title); ax.legend(fontsize=9, markerscale=1.5)
    ax.set_xlabel('Component 1'); ax.set_ylabel('Component 2')
    ax.grid(alpha=0.2)

plt.suptitle('Feature Space Visualization', fontsize=14, fontweight='bold')
plt.tight_layout()
p3 = os.path.join(OUTPUT_DIR, '03_feature_visualization.png')
plt.savefig(p3); plt.close()
print(f"  -> {p3}")

# ── 图4: 各类准确率柱状图 ────────────────────────────────────────────────────
per_class_acc = []
for cls_idx in present_classes:
    mask = labels == cls_idx
    acc  = (preds[mask] == labels[mask]).mean() * 100 if mask.sum() > 0 else 0.0
    per_class_acc.append(acc)

fig, ax = plt.subplots(figsize=(12, 6))
bars = ax.bar(class_name_list, per_class_acc,
              color=[COLORS[i % 10] for i in range(len(class_name_list))],
              edgecolor='white', linewidth=0.8)
for bar, acc in zip(bars, per_class_acc):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
            f'{acc:.1f}%', ha='center', va='bottom', fontsize=10)
ax.set_ylim(0, 115)
ax.set_xlabel('Fault Class'); ax.set_ylabel('Accuracy (%)')
ax.set_title(f'Per-Class Accuracy  (Overall: {test_acc:.2f}%)',
             fontsize=14, fontweight='bold')
ax.axhline(test_acc, ls='--', color='gray', alpha=0.6, label=f'Mean={test_acc:.1f}%')
ax.legend(); ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
p4 = os.path.join(OUTPUT_DIR, '04_per_class_accuracy.png')
plt.savefig(p4); plt.close()
print(f"  -> {p4}")

# ── 图5: 汇总大图 ─────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(20, 16))
gs  = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

# 5-1 Loss 曲线
ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(epochs_x, train_losses, label='Train', color='royalblue', lw=2)
ax1.plot(epochs_x, val_losses,   label='Val',   color='tomato',    lw=2)
ax1.set_title('Loss Curve'); ax1.set_xlabel('Epoch'); ax1.legend(); ax1.grid(alpha=0.3)

# 5-2 Acc 曲线
ax2 = fig.add_subplot(gs[0, 1])
ax2.plot(epochs_x, train_accs, label='Train', color='royalblue', lw=2)
ax2.plot(epochs_x, val_accs,   label='Val',   color='tomato',    lw=2)
ax2.axhline(best_val_acc, ls='--', color='green', alpha=0.7)
ax2.set_title('Accuracy Curve'); ax2.set_xlabel('Epoch'); ax2.legend(); ax2.grid(alpha=0.3)

# 5-3 柱状图
ax3 = fig.add_subplot(gs[0, 2])
ax3.bar(range(len(class_name_list)), per_class_acc,
        color=[COLORS[i % 10] for i in range(len(class_name_list))])
ax3.set_xticks(range(len(class_name_list)))
ax3.set_xticklabels(class_name_list, rotation=30, ha='right', fontsize=9)
ax3.set_title('Per-Class Accuracy'); ax3.set_ylabel('Acc (%)'); ax3.grid(axis='y', alpha=0.3)

# 5-4 混淆矩阵（归一化）
ax4 = fig.add_subplot(gs[1, 0:2])
sns.heatmap(cm_norm, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=class_name_list, yticklabels=class_name_list,
            ax=ax4, linewidths=0.5, annot_kws={'size': 9})
ax4.set_xlabel('Predicted'); ax4.set_ylabel('True')
ax4.set_title('Normalized Confusion Matrix')
ax4.tick_params(axis='x', rotation=30)

# 5-5 t-SNE
ax5 = fig.add_subplot(gs[1, 2])
for ci, cls_idx in enumerate(present_classes):
    mask = labels_s == cls_idx
    ax5.scatter(tsne_emb[mask, 0], tsne_emb[mask, 1],
                label=CLASS_NAMES[cls_idx], alpha=0.65, s=12,
                color=COLORS[ci % 10])
ax5.set_title('t-SNE'); ax5.legend(fontsize=7, markerscale=1.2); ax5.grid(alpha=0.2)

fig.suptitle(f'Thruster Fault Diagnosis - Complete Results\n'
             f'Best Val Acc: {best_val_acc:.2f}%  |  Test Acc: {test_acc:.2f}%',
             fontsize=15, fontweight='bold')
p5 = os.path.join(OUTPUT_DIR, '00_summary.png')
plt.savefig(p5, bbox_inches='tight'); plt.close()
print(f"  -> {p5}")

print(f"\n{'='*60}")
print(f"  训练完成！")
print(f"  最佳验证准确率 : {best_val_acc:.2f}%")
print(f"  最终测试准确率 : {test_acc:.2f}%")
print(f"  结果图已保存至 : {OUTPUT_DIR}/")
print(f"{'='*60}")
