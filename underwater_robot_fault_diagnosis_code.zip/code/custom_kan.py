"""
CustomKAN - Kolmogorov-Arnold Network Layer (Hermite & Taylor 版本)
===================================================================
实现两种KAN层:
1. TaylorKANLayer: 基于Taylor多项式展开，极快，适合小样本
2. BSplineKANLayer: 基于三次B样条，局部性更强，适合大数据

两个版本均GPU原生支持，无需外部库，无编译问题。
"""

import torch
import torch.nn as nn
import math


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Taylor KAN Layer (推荐: 极快 + 可解释 + 小样本友好)
# ═══════════════════════════════════════════════════════════════════════════════
class TaylorKANLayer(nn.Module):
    """
    Taylor KAN: out_j = Σ_i Σ_{k=0}^{K} w[i,j,k] · x_i^k + base(x_i)
    
    基于Taylor展开，系数可学习，是KAN的核心思想。
    K=3 (三次)，x^0=1, x^1=x, x^2=x², x^3=x³
    
    优点: 计算极快(矩阵乘法)，梯度稳定，可解释(每个系数对应幂次)
    """
    def __init__(self, din: int, dout: int,
                 K: int = 3, base_fun: str = 'silu'):
        super().__init__()
        self.din = din
        self.dout = dout
        self.K = K
        # 可学习Taylor系数: (din, dout, K+1)
        self.coeff = nn.Parameter(torch.zeros(din, dout, K + 1))
        nn.init.xavier_normal_(self.coeff)
        # 基础线性变换
        self.base_w = nn.Parameter(
            torch.randn(dout, din) * math.sqrt(2.0 / din)
        )
        # 基础激活
        if base_fun == 'silu':
            self.base_fn = nn.SiLU(inplace=False)
        elif base_fun == 'gelu':
            self.base_fn = nn.GELU()
        elif base_fun == 'relu':
            self.base_fn = nn.ReLU(inplace=False)
        else:
            self.base_fn = nn.SiLU(inplace=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (B, din)
        Returns: (B, dout)
        """
        B, din = x.shape
        K = self.K

        # 归一化 x 到 [0,1] per feature
        x_min = x.amin(dim=0, keepdim=True)
        x_max = x.amax(dim=0, keepdim=True)
        x_range = (x_max - x_min).clamp(min=1e-8)
        x_n = (x - x_min) / x_range

        # 计算 x_n 的各阶幂: (B, din, K+1)
        powers = [x_n]
        xp = x_n.clone()
        for _ in range(1, K + 1):
            xp = xp * x_n
            powers.append(xp)
        x_pow = torch.stack(powers, dim=2)  # (B, din, K+1)

        # Taylor求和: out[b,j] = Σ_i Σ_k x_pow[b,i,k] * coeff[i,j,k]
        coeff = self.coeff                                          # (din, dout, K+1)
        spline = torch.einsum('bid,ckd->bck', x_pow, coeff).sum(dim=1)  # (B, dout)

        # Base激活 (用归一化后的 x_n)
        if self.base_fn is not None:
            base = self.base_fn(x_n) @ self.base_w.T
        else:
            base = x_n @ self.base_w.T

        return spline + base


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Cubic Hermite Spline KAN Layer (精确三次样条)
# ═══════════════════════════════════════════════════════════════════════════════
class BSplineKANLayer(nn.Module):
    """
    Cubic Hermite Spline KAN
    
    每个 (din, dout) 对用 G 个三次Hermite样条基函数。
    基函数由均匀节点上的节点值插值得来。
    
    对输入 x，先找对应的样条段，计算4个Hermite基函数(φ_0,h, φ_1,h, φ_0,d, φ_1,d)
    然后用可学习的节点值和导数值做插值。
    
    这等价于一个 G×4 维的B样条表示。
    """
    def __init__(self, din: int, dout: int,
                 num_grids: int = 8, k: int = 3,
                 base_fun: str = 'silu'):
        super().__init__()
        self.din = din
        self.dout = dout
        self.num_grids = num_grids
        self.k = k

        # 可学习系数: (din, dout, G, 4) = 每个基函数的Hermite系数
        self.coeff = nn.Parameter(
            torch.zeros(din, dout, num_grids, 4).uniform_(-0.05, 0.05)
        )
        nn.init.xavier_normal_(self.coeff.view(din, dout, -1))

        # 基础激活
        if base_fun == 'silu':
            self.base_fn = nn.SiLU(inplace=False)
        elif base_fun == 'gelu':
            self.base_fn = nn.GELU()
        elif base_fun == 'relu':
            self.base_fn = nn.ReLU(inplace=False)
        else:
            self.base_fn = nn.SiLU(inplace=False)

        self.base_w = nn.Parameter(
            torch.randn(dout, din) * math.sqrt(2.0 / din)
        )

    @staticmethod
    def _hermite_eval(x: torch.Tensor, coeff: torch.Tensor) -> torch.Tensor:
        """
        x: (B,) 输入
        coeff: (G, 4) Hermite系数
        返回: (B,) 插值结果
        """
        G = coeff.shape[0]
        B = x.shape[0]
        device = x.device

        # 均匀网格 [0,1]
        t = torch.linspace(0, 1, G, device=device)
        # 找x落在哪个区间 [t[i], t[i+1]]
        idx = torch.searchsorted(t, x.clamp(0.0, 1.0))  # (B,)
        idx = idx.clamp(1, G - 1)                        # clamp到[1, G-1]

        # 局部参数 s ∈ [0,1]
        t_i = t[idx - 1]    # (B,)
        t_ip1 = t[idx]       # (B,)
        s = (x - t_i) / (t_ip1 - t_i + 1e-12)  # (B,)

        # Hermite基函数
        s2 = s * s
        s3 = s2 * s
        h00 =  2*s3 - 3*s2 + 1          # φ_0,h
        h10 =  s3 - 2*s2 + s            # φ_0,d
        h01 = -2*s3 + 3*s2              # φ_1,h
        h11 =  s3 - s2                   # φ_1,d

        # Gather系数: coeff[idx-1, :] 和 coeff[idx, :]
        idx0 = (idx - 1).clamp(0, G - 1)   # (B,)
        idx1 = idx.clamp(0, G - 1)          # (B,)
        c0 = coeff[idx0]   # (B, 4)
        c1 = coeff[idx1]   # (B, 4)

        # H = c0[:0]*h00 + c0[:1]*h10 + c1[:0]*h01 + c1[:1]*h11
        H = (c0[:, 0] * h00 + c0[:, 1] * h10 +
             c1[:, 0] * h01 + c1[:, 1] * h11)  # (B,)

        return H

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, din = x.shape
        G = self.num_grids
        device = x.device

        # 归一化到 [0,1]
        x_min = x.amin(dim=0, keepdim=True)
        x_max = x.amax(dim=0, keepdim=True)
        x_range = (x_max - x_min).clamp(min=1e-8)
        x_n = (x - x_min) / x_range  # (B, din) ∈ [0,1]

        # 计算每个维度的Hermite样条
        # coeff: (din, dout, G, 4)
        coeff = self.coeff  # (din, dout, G, 4)

        # 合并din和dout: (din*dout, G, 4)
        coeff_flat = coeff.view(din * self.dout, G, 4)

        # 对每个(B, din)维计算
        results = []
        for i in range(din):
            xi_n = x_n[:, i]  # (B,)
            # 对所有(dout)组合计算
            xi_rep = xi_n.unsqueeze(0).expand(self.dout, B)  # (dout, B)
            xi_flat = xi_rep.T.reshape(B * self.dout)         # (dout*B,)

            # Hermite评估: (dout*B,) → (dout*B,)
            spline_flat = self._hermite_eval(xi_flat, coeff_flat)  # (dout*B,)
            spline = spline_flat.view(B, self.dout)                # (B, dout)
            results.append(spline)

        # Sum over input dimensions: (B, dout) for each i
        # 每个 i 的 spline 对应 Din 的不同输出维度
        # 我需要把结果按 din 维度相加
        # 实际上: 每个 dim i 有 dout 个输出
        # spline_i[j] = Σ_k coeff[i,j,k] * H_k(x_i)
        # 这里 spline[i][j] 是 j 维输出，系数来自 coeff[i,j,:,:]

        # 重新组织: (B, din, dout)
        spline_stack = torch.stack(results, dim=2)  # (B, din, dout)
        spline = spline_stack.sum(dim=1)            # (B, dout)

        # Base激活
        if self.base_fn is not None:
            base = self.base_fn(x.clone()) @ self.base_w.T
        else:
            base = x.clone() @ self.base_w.T

        return spline + base


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Fast CubicBSpline KAN (精确版，预计算B样条矩阵)
# ═══════════════════════════════════════════════════════════════════════════════
class FastBSplineKANLayer(nn.Module):
    """
    快速精确B样条KAN。
    
    预计算: 在G+3个等距节点上计算B样条基函数值，
    得到形状为 (G, G+3) 的B样条矩阵。
    前向传播时: spline_out = x_n @ spline_matrix @ coeff
    
    等价于三次均匀B样条，完全可微，GPU快速。
    """
    def __init__(self, din: int, dout: int,
                 num_grids: int = 8, k: int = 3,
                 base_fun: str = 'silu'):
        super().__init__()
        self.din = din
        self.dout = dout
        self.num_grids = num_grids
        self.k = k

        # 可学习B样条系数: (din, dout, G)
        self.coeff = nn.Parameter(
            torch.zeros(din, dout, num_grids).uniform_(-0.05, 0.05)
        )
        nn.init.xavier_normal_(self.coeff)

        # 基础激活
        if base_fun == 'silu':
            self.base_fn = nn.SiLU(inplace=False)
        elif base_fun == 'gelu':
            self.base_fn = nn.GELU()
        elif base_fun == 'relu':
            self.base_fn = nn.ReLU(inplace=False)
        else:
            self.base_fn = nn.SiLU(inplace=False)

        self.base_w = nn.Parameter(
            torch.randn(dout, din) * math.sqrt(2.0 / din)
        )

        # 预计算B样条矩阵
        G = num_grids
        # 评估点: G 个区间 × 1 个中点 = G 个点
        eval_pts = torch.linspace(0.0, 1.0, G + 1)[:-1] + 0.5 / G  # (G,) 区间中点
        spline_matrix = self._build_bspline_matrix(eval_pts, k)  # (G, G+k+1)
        self.register_buffer('_spline_matrix', spline_matrix)

    @staticmethod
    def _build_bspline_matrix(eval_pts: torch.Tensor, k: int) -> torch.Tensor:
        """
        构建B样条基函数矩阵。
        eval_pts: (G,) 评估点
        k: 阶数 (默认3)
        返回: (G, G+k+1) B样条值矩阵
        """
        G = len(eval_pts)
        # 扩展网格: 首尾各扩展k个点
        t = torch.linspace(0.0, 1.0, G + 1)  # (G+1,) 节点
        t_ext = torch.cat([
            t[0].expand(k),
            t,
            t[-1].expand(k),
        ])  # (G+2k+1,)
        T = len(t_ext)  # = G + 2k + 1
        n_basis = T - k - 1  # 基函数数量 = G

        # 对每个评估点计算每个基函数值
        result = torch.zeros(G, n_basis)
        for gi, gx in enumerate(eval_pts):
            # 找区间
            for bi in range(n_basis):
                # de Boor 算法
                knots = t_ext[bi:bi+k+2]  # (k+2,) knots for B_{bi,k}
                if len(knots) < k + 2:
                    continue
                x = gx
                h = [1.0] * (k + 1)
                for r in range(1, k + 1):
                    for i in range(k, r - 1, -1):
                        alpha = (x - knots[i]) / (knots[i + k + 1 - r] - knots[i] + 1e-12)
                        h[i] = (1 - alpha) * h[i - 1] + alpha * h[i]
                result[gi, bi] = h[0]
        return result  # (G, n_basis) = (G, G)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, din = x.shape
        G = self.num_grids
        device = x.device

        # 归一化到 [0,1]
        x_min = x.amin(dim=0, keepdim=True)
        x_max = x.amax(dim=0, keepdim=True)
        x_range = (x_max - x_min).clamp(min=1e-8)
        x_n = ((x - x_min) / x_range).clamp(0.0, 1.0)  # (B, din)

        # 插值到网格
        # x ∈ [0,1] → 对应 G 个区间
        x_idx_float = x_n * G  # (B, din)
        x_idx = x_idx_float.long().clamp(0, G - 1)  # (B, din)
        x_frac = x_idx_float - x_idx.float()         # (B, din) 小数部分

        # B样条插值: 用相邻G个基函数的线性组合
        # spline_matrix: (G, G)
        # 对每个dim: x[i] → spline_value
        spline_matrix = self._spline_matrix.to(device)  # (G, G)

        # (B, din) → (din, B)
        x_n_t = x_n.permute(1, 0)  # (din, B)

        # 初始化输出
        spline_out = torch.zeros(B, self.dout, device=device)

        # 对每个dim
        coeff = self.coeff  # (din, dout, G)

        # For each (i, j) pair:
        # spline[b, j] = Σ_g coeff[i, j, g] * φ_g(x_i[b])
        # φ_g: 用 spline_matrix 插值
        # x_idx[i,b] tells which grid interval we're in

        # 更简洁的方式: 用插值
        # (din, dout, G) @ (G, G) → (din, dout, G)
        coeff_spline = torch.einsum('idg,gg->idg', coeff, spline_matrix)  # (din, dout, G)

        # 对每个batch和每个dim，用对应的基函数
        # φ_g(x) 用 4 个相邻的矩阵条目插值
        for d in range(din):
            xi = x_n_t[d]         # (B,)
            gi = x_idx.float()[:, d]  # (B,)
            gi_int = gi.long().clamp(1, G - 2)   # (B,) 区间起点

            # 取4个相邻基函数
            # basis[b, g] = spline_matrix[gi[b]+g%G, :] @ local_weights
            # 近似: 线性插值
            f = gi - gi_int.float()  # (B,)

            # 4个相邻基函数的权重 (Catmull-Rom 样条)
            g0 = (gi_int - 1).clamp(0, G - 1)
            g1 = gi_int
            g2 = (gi_int + 1).clamp(0, G - 1)
            g3 = (gi_int + 2).clamp(0, G - 1)

            # 取对应的矩阵值
            m0 = spline_matrix[g0, :]  # (B, G)
            m1 = spline_matrix[g1, :]  # (B, G)
            m2 = spline_matrix[g2, :]  # (B, G)
            m3 = spline_matrix[g3, :]  # (B, G)

            # Catmull-Rom 权重
            w0 = -0.5 * f * (1 - f) * (2 - f)
            w1 = 1 + 0.5 * f * (2 - f)
            w2 = 0.5 * f * (1 + f)
            w3 = -0.5 * f * (1 - f) * f

            phi = w0.unsqueeze(-1) * m0 + w1.unsqueeze(-1) * m1 + \
                  w2.unsqueeze(-1) * m2 + w3.unsqueeze(-1) * m3  # (B, G)

            # spline contribution: (B, G) @ (G, dout) for each i
            phi_w = torch.einsum('bg,gdo->bdo', phi, coeff[d])  # (B, dout)
            spline_out += phi_w

        # Base
        if self.base_fn is not None:
            base = self.base_fn(x) @ self.base_w.T
        else:
            base = x @ self.base_w.T

        return spline_out + base


# ═══════════════════════════════════════════════════════════════════════════════
# API: 默认使用 FastBSplineKANLayer
# ═══════════════════════════════════════════════════════════════════════════════
# 默认导出: TaylorKANLayer (最可靠)
# 也可选择 BSplineKANLayer 或 FastBSplineKANLayer
KANLayer = TaylorKANLayer   # 推荐默认选择


class KANBlock(nn.Module):
    """KAN块: KANLayer + LayerNorm + Dropout + Residual"""
    def __init__(self, dim: int, num_grids: int = 8, k: int = 3,
                 dropout: float = 0.1, layer_type='taylor'):
        super().__init__()
        if layer_type == 'taylor':
            self.kan = TaylorKANLayer(dim, dim, K=k)
        elif layer_type == 'bspline':
            self.kan = BSplineKANLayer(dim, dim, num_grids, k)
        else:
            self.kan = FastBSplineKANLayer(dim, dim, num_grids, k)
        self.norm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.drop(self.norm(self.kan(x)))


class KANNet(nn.Module):
    """多层KAN网络"""
    def __init__(self, in_dim: int, hidden: list, out_dim: int,
                 num_grids: int = 8, k: int = 3,
                 dropout: float = 0.1, layer_type='taylor'):
        super().__init__()
        layers = []
        dims = [in_dim] + hidden + [out_dim]
        for i in range(len(dims) - 1):
            if layer_type == 'taylor':
                layers.append(TaylorKANLayer(dims[i], dims[i+1], K=k))
            elif layer_type == 'bspline':
                layers.append(BSplineKANLayer(dims[i], dims[i+1], num_grids, k))
            else:
                layers.append(FastBSplineKANLayer(dims[i], dims[i+1], num_grids, k))
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ═══════════════════════════════════════════════════════════════════════════════
# Test
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"[{dev}] Running KAN tests...")

    x = torch.randn(32, 4, requires_grad=True).to(dev)

    # Taylor KAN
    layer = TaylorKANLayer(4, 8, K=3).to(dev)
    out = layer(x)
    loss = out.sum()
    loss.backward()
    print(f"  TaylorKAN(4→8): {x.shape} → {out.shape}, grad OK OK")

    # Full network
    net = KANNet(4, [16, 32], 8, k=3, layer_type='taylor').to(dev)
    nout = net(x)
    nloss = nout.sum()
    nloss.backward()
    print(f"  KANNet(4→[16,32]→8): {x.shape} → {nout.shape}, grad OK OK")

    # KANBlock
    block = KANBlock(4, k=3, layer_type='taylor').to(dev)  # dim=4 to match x
    bout = block(x)
    print(f"  KANBlock(8→8): {x[:,:8].shape} → {bout.shape}, OK OK")

    # Speed benchmark
    import time
    t0 = time.time()
    for _ in range(500):
        loss = layer(x).sum()
        loss.backward()
    dt = (time.time() - t0) * 1000
    print(f"\n  500 iter TaylorKAN: {dt:.1f}ms on {dev}")
    print(f"  → {dt/500:.2f}ms per iter")

    print("\n  OK All KAN tests PASSED!")
