"""
integrated_kan_diagnoser.py - 两阶段KAN故障诊断网络
====================================================
架构:
  Stage 1 (整机检测):
    整机数据(80D) → RobotBranch → 共享融合层 → 故障检测头(8类)

  Stage 2 (推进器定位):
    推进器数据(163D) → ThrusterBranch → 共享融合层 → 推进器定位头(8类)

  共享融合层确保两阶段知识共享，提升泛化能力。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import sys
sys.path.insert(0, r'c:\Users\ZYC\WorkBuddy\Claw')
from custom_kan import TaylorKANLayer


# ═══════════════════════════════════════════════════════════════════════════════
# 分支网络
# ═══════════════════════════════════════════════════════════════════════════════
class RobotBranch(nn.Module):
    """
    整机数据分支: (B, 80) → (B, 128)
    使用 TaylorKAN 处理80维整机特征
    """
    def __init__(self, din: int = 80, hidden: int = 128, k: int = 3):
        super().__init__()
        self.net = nn.Sequential(
            TaylorKANLayer(din, 256, K=k),
            nn.LayerNorm(256),
            nn.GELU(),
            nn.Dropout(0.3),
            TaylorKANLayer(256, hidden, K=k),
            nn.LayerNorm(hidden),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ThrusterBranch(nn.Module):
    """
    推进器数据分支: (B, 163) → (B, 128)
    使用 TaylorKAN 处理163维推进器特征
    """
    def __init__(self, din: int = 163, hidden: int = 128, k: int = 3):
        super().__init__()
        self.net = nn.Sequential(
            TaylorKANLayer(din, 512, K=k),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(0.3),
            TaylorKANLayer(512, 256, K=k),
            nn.LayerNorm(256),
            nn.GELU(),
            nn.Dropout(0.2),
            TaylorKANLayer(256, hidden, K=k),
            nn.LayerNorm(hidden),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ═══════════════════════════════════════════════════════════════════════════════
# 共享融合 + 诊断头
# ═══════════════════════════════════════════════════════════════════════════════
class SharedFusion(nn.Module):
    """
    共享融合层: 融合两个分支的特征表示
    """
    def __init__(self, robot_dim: int = 128, thruster_dim: int = 128,
                 fusion_dim: int = 256, k: int = 3):
        super().__init__()
        self.net = nn.Sequential(
            TaylorKANLayer(robot_dim + thruster_dim, fusion_dim, K=k),
            nn.LayerNorm(fusion_dim),
            nn.GELU(),
            nn.Dropout(0.2),
            TaylorKANLayer(fusion_dim, fusion_dim, K=k),
            nn.LayerNorm(fusion_dim),
        )
        self.fusion_dim = fusion_dim

    def forward(self, robot_feat: torch.Tensor,
                thruster_feat: torch.Tensor) -> torch.Tensor:
        fused = torch.cat([robot_feat, thruster_feat], dim=1)
        return self.net(fused)


class DiagnosisHead(nn.Module):
    """诊断头: 融合特征 → 分类logits"""
    def __init__(self, in_dim: int, num_classes: int, k: int = 3):
        super().__init__()
        self.net = nn.Sequential(
            TaylorKANLayer(in_dim, 128, K=k),
            nn.LayerNorm(128),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ═══════════════════════════════════════════════════════════════════════════════
# 完整两阶段KAN诊断网络
# ═══════════════════════════════════════════════════════════════════════════════
class IntegratedKANDiagnoser(nn.Module):
    """
    集成KAN故障诊断系统

    支持两种模式:
    1. 两阶段联合推理: 同时给出整机故障类型 + 推进器故障位置
    2. 单阶段推理: 任意一个分支单独推理
    """
    def __init__(self,
                 robot_dim: int = 80,
                 thruster_dim: int = 163,
                 robot_classes: int = 8,
                 thruster_classes: int = 8,
                 fusion_dim: int = 256,
                 k: int = 3,
                 use_fusion: bool = True):
        super().__init__()
        self.use_fusion = use_fusion
        self.robot_classes = robot_classes
        self.thruster_classes = thruster_classes

        # 两个独立分支
        self.robot_branch = RobotBranch(din=robot_dim, hidden=128, k=k)
        self.thruster_branch = ThrusterBranch(din=thruster_dim, hidden=128, k=k)

        if use_fusion:
            # 共享融合
            self.fusion = SharedFusion(
                robot_dim=128, thruster_dim=128,
                fusion_dim=fusion_dim, k=k
            )
            # 诊断头
            self.robot_head = DiagnosisHead(fusion_dim, robot_classes, k=k)
            self.thruster_head = DiagnosisHead(fusion_dim, thruster_classes, k=k)
        else:
            # 独立模式（不共享参数）
            self.robot_head = DiagnosisHead(128, robot_classes, k=k)
            self.thruster_head = DiagnosisHead(128, thruster_classes, k=k)

    def forward_robot(self, x: torch.Tensor) -> torch.Tensor:
        """Stage 1: 整机故障检测"""
        feat = self.robot_branch(x)
        if self.use_fusion:
            # 拼接零填充的thruster特征
            thruster_zeros = torch.zeros_like(feat)
            fused = self.fusion(feat, thruster_zeros)
            return self.robot_head(fused)
        else:
            return self.robot_head(feat)

    def forward_thruster(self, x: torch.Tensor) -> torch.Tensor:
        """Stage 2: 推进器故障定位"""
        feat = self.thruster_branch(x)
        if self.use_fusion:
            robot_zeros = torch.zeros_like(feat)
            fused = self.fusion(robot_zeros, feat)
            return self.thruster_head(fused)
        else:
            return self.thruster_head(feat)

    def forward_both(self, x_robot: torch.Tensor,
                     x_thruster: torch.Tensor) -> tuple:
        """两阶段联合推理"""
        robot_feat = self.robot_branch(x_robot)
        thruster_feat = self.thruster_branch(x_thruster)

        if self.use_fusion:
            fused = self.fusion(robot_feat, thruster_feat)
            robot_out = self.robot_head(fused)
            thruster_out = self.thruster_head(fused)
        else:
            robot_out = self.robot_head(robot_feat)
            thruster_out = self.thruster_head(thruster_feat)

        return robot_out, thruster_out

    def forward(self, x: torch.Tensor,
                mode: str = 'robot') -> torch.Tensor:
        """
        统一前向接口
        mode: 'robot' | 'thruster'
        """
        if mode == 'robot':
            return self.forward_robot(x)
        elif mode == 'thruster':
            return self.forward_thruster(x)
        else:
            raise ValueError(f"Unknown mode: {mode}")


# ═══════════════════════════════════════════════════════════════════════════════
# 轻量版（用于快速实验）
# ═══════════════════════════════════════════════════════════════════════════════
class LightKANDiagnoser(nn.Module):
    """
    轻量版KAN诊断器，使用标准MLP作为备选
    """
    def __init__(self, robot_dim: int = 80, thruster_dim: int = 163,
                 robot_classes: int = 8, thruster_classes: int = 8,
                 hidden: int = 256, k: int = 3):
        super().__init__()
        self.robot_classes = robot_classes
        self.thruster_classes = thruster_classes

        # 整机分支: MLP
        self.robot_net = nn.Sequential(
            nn.Linear(robot_dim, hidden),
            nn.BatchNorm1d(hidden),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(hidden, hidden // 2),
            nn.BatchNorm1d(hidden // 2),
            nn.GELU(),
            nn.Dropout(0.2),
        )

        # 推进器分支: KAN
        self.thruster_kan1 = TaylorKANLayer(thruster_dim, 512, K=k)
        self.thruster_norm1 = nn.LayerNorm(512)
        self.thruster_kan2 = TaylorKANLayer(512, 256, K=k)
        self.thruster_norm2 = nn.LayerNorm(256)
        self.thruster_kan3 = TaylorKANLayer(256, hidden // 2, K=k)
        self.thruster_norm3 = nn.LayerNorm(hidden // 2)

        # 融合
        self.fusion_fc = nn.Sequential(
            nn.Linear(hidden // 2 * 2, hidden),
            nn.BatchNorm1d(hidden),
            nn.GELU(),
            nn.Dropout(0.2),
        )

        # 诊断头（各自处理自己的分支特征）
        self.robot_head = nn.Linear(hidden // 2, robot_classes)
        self.thruster_head = nn.Linear(hidden // 2, thruster_classes)

    def forward_robot(self, x: torch.Tensor) -> torch.Tensor:
        f = self.robot_net(x)
        return self.robot_head(f)

    def forward_thruster(self, x: torch.Tensor) -> torch.Tensor:
        f = F.gelu(self.thruster_norm1(self.thruster_kan1(x)))
        f = F.dropout(f, 0.2, training=self.training)
        f = F.gelu(self.thruster_norm2(self.thruster_kan2(f)))
        f = F.gelu(self.thruster_norm3(self.thruster_kan3(f)))
        return self.thruster_head(f)

    def forward_both(self, x_robot: torch.Tensor,
                     x_thruster: torch.Tensor) -> tuple:
        r_f = self.robot_net(x_robot)
        t_f = F.gelu(self.thruster_norm1(self.thruster_kan1(x_thruster)))
        t_f = F.dropout(t_f, 0.2, training=self.training)
        t_f = F.gelu(self.thruster_norm2(self.thruster_kan2(t_f)))
        t_f = F.gelu(self.thruster_norm3(self.thruster_kan3(t_f)))

        # 分别用各自的特征过各自的诊断头
        return self.robot_head(r_f), self.thruster_head(t_f)


# ═══════════════════════════════════════════════════════════════════════════════
# 测试
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"[{dev}] Testing integrated model...")

    x_r = torch.randn(16, 80).to(dev)
    x_t = torch.randn(16, 163).to(dev)

    # Full model
    model = IntegratedKANDiagnoser(k=3).to(dev)
    r_out = model.forward_robot(x_r)
    t_out = model.forward_thruster(x_t)
    r_b, t_b = model.forward_both(x_r, x_t)
    print(f"  IntegratedKANDiagnoser:")
    print(f"    Robot branch: {x_r.shape} → {r_out.shape}  OK")
    print(f"    Thruster branch: {x_t.shape} → {t_out.shape}  OK")
    print(f"    Both: ({x_r.shape},{x_t.shape}) → ({r_b.shape},{t_b.shape})  OK")

    # Light model
    lmodel = LightKANDiagnoser(k=3).to(dev)
    lr = lmodel.forward_robot(x_r)
    lt = lmodel.forward_thruster(x_t)
    print(f"  LightKANDiagnoser:")
    print(f"    Robot: {x_r.shape} → {lr.shape}  OK")
    print(f"    Thruster: {x_t.shape} → {lt.shape}  OK")

    # Gradients
    loss = r_out.sum() + t_out.sum()
    loss.backward()
    print(f"\n  Gradient test: PASSED")
    print(f"\n  All model tests PASSED!")
