"""
unified_data.py - 统一数据加载器
================================
加载两类数据:
1. 整机实验数据 (G:\实验数据\0_水池故障模拟实验\Dataset)
   - 用途: 整机故障检测（Stage 1）
   - 标签: 8类 (normal + 7种故障)
   
2. 推进器独立数据 (E:\范小龙\数据\定向数据 + 手柄前推数据)
   - 用途: 推进器精准定位（Stage 2）
   - 标签: 9类 (normal + 推进器故障)
"""

import os, sys
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from pathlib import Path
from typing import Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# ── 路径 ──────────────────────────────────────────────────────────────────────
BASE_ROBOT = Path(r'G:\实验数据\0_水池故障模拟实验_先看这里里的说明\Dataset')
BASE_DING  = Path(r'E:\范小龙\数据\数据\定向数据')
BASE_QIAN  = Path(r'E:\范小龙\数据\数据\手柄前推数据')
BASE_ROBOT = Path(r'G:\实验数据\0_水池故障模拟实验_先看这里面的说明\Dataset')

# ── 标签 ──────────────────────────────────────────────────────────────────────
# 整机实验标签
ROBOT_LABELS = {
    'normal':        0,
    'lost':          1,
    'dr_broken':     2,
    'dr_short':      3,
    'winding':       4,
    'm_locked':      5,
    'p_locked':      6,
    'cur_sensor_0':  7,
}
ROBOT_CLASSES = list(ROBOT_LABELS.keys())
ROBOT_NAMES   = {v: k for k, v in ROBOT_LABELS.items()}
ROBOT_SHORT   = {
    'normal': 'Normal', 'lost': 'Lost', 'dr_broken': 'Dr_Brk',
    'dr_short': 'Dr_Sht', 'winding': 'Wind', 'm_locked': 'MLocked',
    'p_locked': 'PLocked', 'cur_sensor_0': 'CurSns',
}

# 推进器实验标签
THRUSTER_LABELS = {
    'normal':        0,
    'fault_1':       1,
    'fault_12':      2,
    'fault_13':      3,
    'fault_123':     4,
    'push_normal':   5,
    'push_fault_12': 6,
    'push_fault_13': 7,
}
THRUSTER_NAMES  = {v: k for k, v in THRUSTER_LABELS.items()}
THRUSTER_SHORT  = {
    'normal': 'D-Norm', 'fault_1': 'D-F1', 'fault_12': 'D-F12',
    'fault_13': 'D-F13', 'fault_123': 'D-F123',
    'push_normal': 'P-Norm', 'push_fault_12': 'P-F12', 'push_fault_13': 'P-F13',
}

def thruster_fault_bitmap(lbl):
    """
    分类标签 -> 垂推1-4故障位图 [T1, T2, T3, T4]
    0=正常, 1=关闭/故障
    """
    mapping = {
        0: [0, 0, 0, 0],  # normal
        1: [1, 0, 0, 0],  # fault_1  (T1关闭)
        2: [1, 1, 0, 0],  # fault_12 (T1,T2关闭)
        3: [1, 0, 1, 0],  # fault_13 (T1,T3关闭)
        4: [1, 1, 1, 0],  # fault_123(T1,T2,T3关闭)
        5: [1, 0, 0, 0],  # push_normal (前推时T1工作，故障时T1关闭)
        6: [1, 1, 0, 0],  # push_fault_12
        7: [1, 0, 1, 0],  # push_fault_13
    }
    return mapping.get(int(lbl), [0, 0, 0, 0])

# 定向/前推 文件映射
DING_MAP = {
    '2025-01-05_17-26-54': 'normal',
    '2025-01-05_17-29-52': 'fault_1',
    '2025-01-05_17-32-17': 'fault_12',
    '2025-01-05_17-34-39': 'fault_12',   # 与上一个相同标签
    '2025-01-05_17-36-18': 'fault_13',
    '2025-01-05_17-41-23': 'fault_123',
}
QIAN_MAP = {
    '2025-01-05_17-45-03': 'push_normal',
    '2025-01-05_18-00-14': 'push_fault_12',
    '2025-01-05_18-02-16': 'push_fault_13',
}


# ═══════════════════════════════════════════════════════════════════════════════
# 1. 整机实验数据特征提取
# ═══════════════════════════════════════════════════════════════════════════════
ROBOT_COLS = ['v', 'f', 'c', 's']
ROBOT_SYM  = ['垂推1', '垂推2', '垂推3', '垂推4', '侧推1', '侧推2', '侧推3', '侧推4']


def robot_row_features(vals: np.ndarray) -> np.ndarray:
    """
    对一行（1个时刻的4个变量）提取特征。
    vals: (4,) = [v, f, c, s]
    返回: 特征向量
    """
    feats = []
    for v in vals:
        x = float(v)
        abs_x = abs(x)
        feats.extend([
            x,                          # 原始值
            abs_x,                      # 绝对值
            np.log1p(abs_x),            # 对数
            1.0 if abs_x > 1.0 else 0.0,  # 活跃标记
        ])
    return np.array(feats, dtype=np.float32)  # 16维


def robot_window_features(df: pd.DataFrame, window: int = 10, step: int = 5) -> np.ndarray:
    """
    对滑动窗口提取统计特征。
    返回: (N, D) 特征矩阵
    """
    vals = df[ROBOT_COLS].values.astype(np.float32)
    T = len(vals)
    if T < window:
        pad = np.zeros((window - T, 4), dtype=np.float32)
        vals = np.vstack([vals, pad])

    feats_list = []
    for start in range(0, len(vals) - window + 1, step):
        win = vals[start:start+window]  # (window, 4)
        row_feats = []

        for ch in range(4):
            x = win[:, ch]
            x_nz = np.where(np.abs(x) > 1, x, 0)
            nz_cnt = np.sum(np.abs(x) > 1)

            # 统计特征
            row_feats.extend([
                np.mean(x), np.std(x),
                np.min(x), np.max(x),
                np.max(np.abs(x)),
                np.sqrt(np.mean(x**2)),
                np.mean(np.abs(x)),
                # 偏度/峭度（安全版）
                np.mean((x - np.mean(x))**3) / (np.std(x)**3 + 1e-8),
                np.mean((x - np.mean(x))**4) / (np.std(x)**4 + 1e-8),
                np.percentile(x, 25), np.percentile(x, 75),
                np.sum(x < 0) / window, np.sum(x > 0) / window,
                nz_cnt / window,
                np.mean(x_nz),
                np.max(np.abs(x)) / (np.sqrt(np.mean(x**2)) + 1e-8),  # 峰值因子
                np.sum(x**2) / window,  # 能量
            ])

        # 跨通道特征
        # v vs f 的相关性
        row_feats.extend([
            np.corrcoef(win[:, 0], win[:, 1])[0, 1] if np.std(win[:, 0]) > 0 else 0,
            np.corrcoef(win[:, 0], win[:, 2])[0, 1] if np.std(win[:, 2]) > 0 else 0,
            np.corrcoef(win[:, 1], win[:, 2])[0, 1] if np.std(win[:, 1]) > 0 else 0,
        ])

        # v 的梯度
        dv = np.diff(win[:, 0])
        row_feats.extend([
            np.mean(np.abs(dv)),
            np.std(dv),
            np.max(np.abs(dv)),
        ])

        # f 的变化
        df_grad = np.diff(win[:, 1])
        row_feats.extend([
            np.mean(df_grad),
            np.std(df_grad),
        ])

        # c 的瞬时值（电流传感器）
        c_mean = np.mean(win[:, 2])
        c_std  = np.std(win[:, 2])
        row_feats.extend([c_mean, c_std])

        # s 的值（传感器状态）
        s_val = np.mean(win[:, 3])
        row_feats.extend([s_val])

        # 能量
        row_feats.append(np.sum(win[:, 1]**2) / window)  # f能量

        feats_list.append(np.array(row_feats, dtype=np.float32))

    return np.stack(feats_list)


def load_robot_data(window: int = 10, step: int = 5,
                    use_test: bool = True) -> Tuple[np.ndarray, np.ndarray]:
    """
    加载所有整机实验数据。
    Returns: X (N, D), y (N,) - 类别标签
    """
    X_list, y_list = [], []

    for subset in ['Tr', 'Te'] if use_test else ['Tr']:
        base = BASE_ROBOT / subset
        if not base.exists(): continue

        for cls in ROBOT_CLASSES:
            cls_dir = base / cls
            if not cls_dir.exists(): continue
            csv_files = list(cls_dir.glob('*.csv'))
            if not csv_files: continue

            for fpath in csv_files:
                df = pd.read_csv(fpath)
                # 只保留有4列的文件
                if df.shape[1] < 4: continue
                df = df.iloc[:, :4]
                df = df.apply(pd.to_numeric, errors='coerce').dropna()
                if len(df) < window: continue

                feat = robot_window_features(df, window=window, step=step)
                feat = np.nan_to_num(feat, nan=0.0, posinf=1e6, neginf=-1e6)
                if len(feat) == 0: continue

                X_list.append(feat)
                y_list.append(np.full(len(feat), ROBOT_LABELS[cls], dtype=np.int64))
                print(f"  [Robot/{subset}] {cls:15s}  {fpath.name:30s}  "
                      f"样本={len(feat):4d}  shape={feat.shape}")

    if not X_list:
        return np.array([]), np.array([])

    X = np.concatenate(X_list, axis=0)
    y = np.concatenate(y_list, axis=0)
    return X, y


# ═══════════════════════════════════════════════════════════════════════════════
# 2. 推进器数据特征提取（复用v2版增强版）
# ═══════════════════════════════════════════════════════════════════════════════
def thruster_read_safe(fpath) -> Optional[pd.DataFrame]:
    if os.path.basename(str(fpath)).startswith('~$'):
        return None
    try:
        df = pd.read_excel(str(fpath))
        df = df.apply(pd.to_numeric, errors='coerce').dropna()
        return df if df.shape[0] >= 5 else None
    except:
        return None


def thruster_window_features(df: pd.DataFrame, window: int, step: int) -> np.ndarray:
    """
    推进器滑动窗口特征（增强版，包含更多跨通道特征）。
    返回: (N, D)
    """
    vals = df[ROBOT_SYM].values.astype(np.float32)  # (T, 8)
    T = len(vals)
    if T < window:
        pad = np.zeros((window - T, 8), dtype=np.float32)
        vals = np.vstack([vals, pad])

    feats_list = []
    for start in range(0, len(vals) - window + 1, step):
        win = vals[start:start+window]  # (window, 8)
        row_feats = []

        # ── G1: 单通道时序统计 ─────────────────────────────────────────
        for ch in range(8):
            x = win[:, ch]
            x_nz = np.where(np.abs(x) > 5, x, 0)
            nz_cnt = np.sum(np.abs(x) > 5)

            row_feats.extend([
                np.mean(x), np.std(x),
                np.max(np.abs(x)),
                np.sqrt(np.mean(x**2)),
                np.mean(np.abs(x)),
                np.mean((x - np.mean(x))**3) / (np.std(x)**3 + 1e-8),   # 偏度
                np.mean((x - np.mean(x))**4) / (np.std(x)**4 + 1e-8),   # 峭度
                np.min(x), np.max(x) - np.min(x),
                np.percentile(x, 25), np.percentile(x, 75),
                nz_cnt / window,
                np.mean(x_nz),
                np.sum(np.sign(x[x<0])), np.sum(np.sign(x[x>0])),
            ])

        # ── G2: 垂推结构特征（诊断关键）────────────────────────────────
        v_means = win[:, :4].mean(axis=0)  # 垂推1-4均值

        # 符号模式（关键诊断特征）
        signs = np.sign(v_means)
        row_feats.extend(signs.tolist())   # 4维

        # 故障位图
        fault_bmp = (np.abs(v_means) < 5).astype(float)
        row_feats.extend(fault_bmp.tolist())  # 4维

        # 活跃数
        row_feats.append(np.sum(np.abs(v_means) >= 5))  # 1维

        # 推力差值/比值
        for i in range(4):
            for j in range(i+1, 4):
                row_feats.append(v_means[j] - v_means[i])
        for i in range(4):
            for j in range(i+1, 4):
                row_feats.append(v_means[i] / (v_means[j] + 1e-8))

        # 推力和
        row_feats.extend([
            np.sum(v_means), np.sum(np.abs(v_means)),
            np.abs(v_means[0]+v_means[1]),
            np.abs(v_means[2]+v_means[3]),
            np.abs(v_means[0]+v_means[3]),
            np.abs(v_means[1]+v_means[2]),
        ])

        # 正负比
        neg = np.sum(v_means[v_means<0])
        pos = np.sum(v_means[v_means>0])
        row_feats.extend([neg, pos, neg/(pos+1e-8)])

        # ── G3: 侧推特征 ──────────────────────────────────────────────
        c_means = win[:, 4:].mean(axis=0)  # 侧推均值
        row_feats.extend([
            np.sum(c_means), np.sum(np.abs(c_means)),
            np.std(c_means),
            np.mean(np.abs(c_means[0]+c_means[1])),
            np.mean(np.abs(c_means[2]+c_means[3])),
        ])

        # ── G4: 控制上下文 ─────────────────────────────────────────────
        ctrl_cols = ['深度', '航向', '俯仰', '横滚']
        for col in ctrl_cols:
            if col in df.columns:
                cx = df[col].values.astype(np.float32)
                row_feats.extend([np.mean(cx), np.std(cx)])
            else:
                row_feats.extend([0.0, 0.0])

        feats_list.append(np.array(row_feats, dtype=np.float32))

    return np.stack(feats_list)


def load_thruster_data(window: int = 5, step: int = 1) -> Tuple[np.ndarray, np.ndarray]:
    """
    加载推进器实验数据。
    Returns: X (N, D), y (N,)
    """
    X_list, y_list = [], []

    for fname, fkey, base in [
        *[(f, k, BASE_DING) for f, k in DING_MAP.items()],
        *[(f, k, BASE_QIAN) for f, k in QIAN_MAP.items()],
    ]:
        fpath = base / f'{fname}.xlsx'
        if not fpath.exists(): continue
        df = thruster_read_safe(fpath)
        if df is None: continue

        feat = thruster_window_features(df, window=window, step=step)
        feat = np.nan_to_num(feat, nan=0.0, posinf=1e6, neginf=-1e6)
        if len(feat) == 0: continue

        X_list.append(feat)
        y_list.append(np.full(len(feat), THRUSTER_LABELS[fkey], dtype=np.int64))

        v_means = df[['垂推1','垂推2','垂推3','垂推4']].mean().values
        closed = [i+1 for i, v in enumerate(v_means) if abs(v) < 5]
        print(f"  [Thruster] {fname} -> {fkey:15s}  样本={len(feat):4d}  "
              f"关闭垂推: {closed}  feat_dim={feat.shape[1]}")

    if not X_list:
        return np.array([]), np.array([])

    X = np.concatenate(X_list, axis=0)
    y = np.concatenate(y_list, axis=0)
    return X, y


# ═══════════════════════════════════════════════════════════════════════════════
# 3. PyTorch Dataset
# ═══════════════════════════════════════════════════════════════════════════════
class UnifiedDataset(Dataset):
    """
    统一数据集，支持两类数据源分别归一化。
    data_type: 'robot' 或 'thruster'
    """
    def __init__(self, X: np.ndarray, y: np.ndarray,
                 scaler: Optional[StandardScaler] = None,
                 fit: bool = False,
                 data_type: str = 'robot'):
        self.data_type = data_type
        if fit:
            scaler = StandardScaler()
            Xs = scaler.fit_transform(X)
        else:
            Xs = scaler.transform(X) if scaler else X
        self.X = torch.tensor(Xs, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)
        self.scaler = scaler

    def __len__(self): return len(self.y)
    def __getitem__(self, i): return self.X[i], self.y[i]


def build_loaders(X: np.ndarray, y: np.ndarray,
                  batch_size: int = 16,
                  data_type: str = 'robot',
                  test_ratio: float = 0.2,
                  seed: int = 42) -> Tuple:
    """留出法构建 DataLoader"""
    torch.manual_seed(seed)
    np.random.seed(seed)
    idx = np.random.permutation(len(X))
    n_test = max(2, int(len(X) * test_ratio))
    te, tr = idx[:n_test], idx[n_test:]

    ds_full = UnifiedDataset(X, y, fit=True, data_type=data_type)
    scaler = ds_full.scaler

    tr_ds = UnifiedDataset(X[tr], y[tr], scaler=scaler, data_type=data_type)
    te_ds = UnifiedDataset(X[te], y[te], scaler=scaler, data_type=data_type)

    tr_loader = DataLoader(tr_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    te_loader = DataLoader(te_ds, batch_size=len(te_ds), shuffle=False)

    return tr_loader, te_loader, scaler, ds_full.feat_dim


if __name__ == '__main__':
    print("=" * 60)
    print("Loading ROBOT data...")
    X_r, y_r = load_robot_data(window=10, step=5)
    print(f"  Robot: X={X_r.shape}  y={y_r.shape}")
    for lbl in sorted(np.unique(y_r)):
        print(f"    {ROBOT_NAMES[lbl]:15s}: {(y_r==lbl).sum():5d}")

    print("\nLoading THRUSTER data...")
    X_t, y_t = load_thruster_data(window=5, step=1)
    print(f"  Thruster: X={X_t.shape}  y={y_t.shape}")
    for lbl in sorted(np.unique(y_t)):
        print(f"    {THRUSTER_NAMES[lbl]:15s}: {(y_t==lbl).sum():5d}")
