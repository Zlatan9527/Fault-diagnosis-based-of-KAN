"""
train_integrated.py - 两阶段KAN故障诊断训练+可视化
=================================================
Stage 1: 整机故障检测（Whole Robot Data, 8类）
Stage 2: 推进器精准定位（Thruster Data, 8类）

使用双分支架构:
  整机分支(MLP) + 推进器分支(KAN) → 共享诊断头
"""

import sys, os, warnings, time, json
warnings.filterwarnings('ignore')
sys.path.insert(0, r'c:\Users\ZYC\WorkBuddy\Claw')

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from pathlib import Path
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA

# ── 输出目录 ─────────────────────────────────────────────────────────────────
OUT = Path(r'c:\Users\ZYC\WorkBuddy\Claw\results_integrated')
OUT.mkdir(parents=True, exist_ok=True)

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
torch.manual_seed(42)
np.random.seed(42)
print(f"[Device] {DEVICE}")

# ═══════════════════════════════════════════════════════════════════════════════
# 0. 数据加载
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[Stage 0] Loading data...")
from unified_data import (
    load_robot_data, load_thruster_data,
    ROBOT_LABELS, ROBOT_NAMES, ROBOT_SHORT,
    THRUSTER_LABELS, THRUSTER_NAMES, THRUSTER_SHORT,
    UnifiedDataset, build_loaders
)

# 加载整机数据（训练集+测试集）
X_robot, y_robot = load_robot_data(window=10, step=5)
print(f"\n  Robot data: X={X_robot.shape}, y unique={len(np.unique(y_robot))}")

# 加载推进器数据
X_thruster, y_thruster = load_thruster_data(window=5, step=1)
print(f"  Thruster data: X={X_thruster.shape}, y unique={len(np.unique(y_thruster))}")

ROBOT_DIM = X_robot.shape[1]
THRUSTER_DIM = X_thruster.shape[1]
ROBOT_CLASSES = len(ROBOT_LABELS)
THRUSTER_CLASSES = len(THRUSTER_LABELS)
print(f"  Robot feat dim: {ROBOT_DIM}, Thruster feat dim: {THRUSTER_DIM}")

# ═══════════════════════════════════════════════════════════════════════════════
# 1. 构建数据加载器
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[Stage 1] Building data loaders...")

# 整机数据
robot_ds = UnifiedDataset(X_robot, y_robot, fit=True, data_type='robot')
robot_scaler = robot_ds.scaler
idx = np.random.permutation(len(X_robot))
n_test_r = max(2, int(len(X_robot) * 0.2))
te_r, tr_r = idx[:n_test_r], idx[n_test_r:]
robot_tr = DataLoader(
    UnifiedDataset(X_robot[tr_r], y_robot[tr_r], scaler=robot_scaler, data_type='robot'),
    batch_size=128, shuffle=True, drop_last=False)
robot_te = DataLoader(
    UnifiedDataset(X_robot[te_r], y_robot[te_r], scaler=robot_scaler, data_type='robot'),
    batch_size=len(te_r), shuffle=False)

# 推进器数据（留出法）
thruster_ds = UnifiedDataset(X_thruster, y_thruster, fit=True, data_type='thruster')
thruster_scaler = thruster_ds.scaler
idx_t = np.random.permutation(len(X_thruster))
# 每类至少1个入测试
test_idx_t = []
for cls in sorted(np.unique(y_thruster)):
    cls_idx = np.where(y_thruster == cls)[0]
    test_idx_t.append(cls_idx[0])
train_idx_t = sorted([i for i in idx_t if i not in set(test_idx_t)])
thruster_tr = DataLoader(
    UnifiedDataset(X_thruster[train_idx_t], y_thruster[train_idx_t],
                   scaler=thruster_scaler, data_type='thruster'),
    batch_size=32, shuffle=True, drop_last=False)
thruster_te = DataLoader(
    UnifiedDataset(X_thruster[test_idx_t], y_thruster[test_idx_t],
                   scaler=thruster_scaler, data_type='thruster'),
    batch_size=len(test_idx_t), shuffle=False)

print(f"  Robot: Train={len(robot_tr.dataset)}, Test={len(robot_te.dataset)}")
print(f"  Thruster: Train={len(thruster_tr.dataset)}, Test={len(thruster_te.dataset)}")

# ═══════════════════════════════════════════════════════════════════════════════
# 2. 模型
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[Stage 2] Building model...")
from integrated_kan_diagnoser import LightKANDiagnoser

model = LightKANDiagnoser(
    robot_dim=ROBOT_DIM,
    thruster_dim=THRUSTER_DIM,
    robot_classes=ROBOT_CLASSES,
    thruster_classes=THRUSTER_CLASSES,
    hidden=256,
    k=3,
).to(DEVICE)

total_params = sum(p.numel() for p in model.parameters())
trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"  Total params: {total_params:,}  Trainable: {trainable:,}")

criterion = nn.CrossEntropyLoss(label_smoothing=0.05)
optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-3)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200)

# ═══════════════════════════════════════════════════════════════════════════════
# 3. 训练
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[Stage 3] Training...")
EPOCHS = 200
best_robot_acc = 0.0
best_thruster_acc = 0.0
best_state = None
hist = {
    'robot_tr_loss': [], 'robot_te_acc': [],
    'thruster_tr_loss': [], 'thruster_te_acc': [],
    'robot_tr_acc': [], 'thruster_tr_acc': [],
}

for ep in range(1, EPOCHS + 1):
    # ── 训练 ──────────────────────────────────────────────────────────────
    model.train()
    r_loss, r_correct, r_total = 0.0, 0, 0
    t_loss, t_correct, t_total = 0.0, 0, 0

    for xr, yr in robot_tr:
        xr, yr = xr.to(DEVICE), yr.to(DEVICE)
        optimizer.zero_grad()
        out = model.forward_robot(xr)
        loss = criterion(out, yr)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        r_loss += loss.item() * len(yr)
        r_correct += (out.argmax(1) == yr).sum().item()
        r_total += len(yr)

    for xt, yt in thruster_tr:
        xt, yt = xt.to(DEVICE), yt.to(DEVICE)
        optimizer.zero_grad()
        out = model.forward_thruster(xt)
        loss = criterion(out, yt)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        t_loss += loss.item() * len(yt)
        t_correct += (out.argmax(1) == yt).sum().item()
        t_total += len(yt)

    scheduler.step()

    # ── 评估 ──────────────────────────────────────────────────────────────
    model.eval()
    with torch.no_grad():
        # Robot test
        for xr, yr in robot_te:
            xr, yr = xr.to(DEVICE), yr.to(DEVICE)
            r_acc = (model.forward_robot(xr).argmax(1) == yr).float().mean().item() * 100

        # Thruster test
        for xt, yt in thruster_te:
            xt, yt = xt.to(DEVICE), yt.to(DEVICE)
            t_acc = (model.forward_thruster(xt).argmax(1) == yt).float().mean().item() * 100

    hist['robot_tr_loss'].append(r_loss / r_total)
    hist['robot_tr_acc'].append(r_correct / r_total * 100)
    hist['robot_te_acc'].append(r_acc)
    hist['thruster_tr_loss'].append(t_loss / t_total)
    hist['thruster_tr_acc'].append(t_correct / t_total * 100)
    hist['thruster_te_acc'].append(t_acc)

    if r_acc >= best_robot_acc and t_acc >= best_thruster_acc:
        best_robot_acc = r_acc
        best_thruster_acc = t_acc
        best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    if ep % 20 == 0 or ep == 1:
        print(f"  Ep {ep:3d}/{EPOCHS}  "
              f"R_acc={r_correct/r_total*100:.1f}%/{r_acc:.1f}%  "
              f"T_acc={t_correct/t_total*100:.1f}%/{t_acc:.1f}%  "
              f"(best: R={best_robot_acc:.1f}% T={best_thruster_acc:.1f}%)")

model.load_state_dict(best_state)
print(f"\n  Best: Robot={best_robot_acc:.1f}%  Thruster={best_thruster_acc:.1f}%")

# ═══════════════════════════════════════════════════════════════════════════════
# 4. 完整评估
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[Stage 4] Full evaluation...")
model.eval()

# 收集所有预测和标签
def collect_predictions(loader, forward_fn):
    preds, labels, feats = [], [], []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(DEVICE)
            logits = forward_fn(xb)
            preds.append(logits.argmax(1).cpu().numpy())
            labels.append(yb.numpy())
    return np.concatenate(preds), np.concatenate(labels)

r_preds, r_labels = collect_predictions(robot_te, model.forward_robot)
t_preds, t_labels = collect_predictions(thruster_te, model.forward_thruster)

r_acc_all = (r_preds == r_labels).mean() * 100
t_acc_all = (t_preds == t_labels).mean() * 100
print(f"\n  Robot Test Acc: {r_acc_all:.1f}%")
print(f"  Thruster Test Acc: {t_acc_all:.1f}%")

# ── 推进器故障位检测 ──────────────────────────────────────────────────────────
def fault_vec_thruster(lbl):
    """将推进器标签映射到故障位图 (垂推1-4)"""
    m = {
        0: [0,0,0,0],  # normal
        1: [1,0,0,0],  # fault_1
        2: [1,1,0,0],  # fault_12
        3: [1,0,1,0],  # fault_13
        4: [1,1,1,0],  # fault_123
        5: [1,0,0,0],  # push_normal
        6: [1,1,0,0],  # push_fault_12
        7: [1,0,1,0],  # push_fault_13
    }
    return m.get(lbl, [0,0,0,0])

thruster_detect_acc = []
for i in range(4):
    correct = sum(
        1 for p, l in zip(t_preds, t_labels)
        if fault_vec_thruster(p)[i] == fault_vec_thruster(l)[i]
    )
    acc = correct / len(t_preds) * 100
    thruster_detect_acc.append(acc)
    print(f"  Thruster {i+1} detection: {correct}/{len(t_preds)} = {acc:.0f}%")

# ═══════════════════════════════════════════════════════════════════════════════
# 5. 可视化
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[Stage 5] Generating visualizations...")
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'figure.facecolor': 'white',
    'axes.titlesize': 12, 'savefig.dpi': 150,
})
COLORS = plt.cm.tab10(np.linspace(0, 1, 16))
EX = range(1, EPOCHS + 1)

# ── 图1: 训练曲线 ─────────────────────────────────────────────────────────────
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
# Robot Loss
axes[0,0].plot(EX, hist['robot_tr_loss'], 'royalblue', lw=2)
axes[0,0].set_title('Robot Branch - Training Loss')
axes[0,0].set_xlabel('Epoch'); axes[0,0].set_ylabel('Loss')
axes[0,0].grid(alpha=0.3)
# Robot Acc
axes[0,1].plot(EX, hist['robot_tr_acc'], 'royalblue', lw=2, label='Train')
axes[0,1].plot(EX, hist['robot_te_acc'], 'tomato', lw=2, label='Test')
axes[0,1].axhline(best_robot_acc, ls='--', color='green', alpha=0.7, label=f'Best={best_robot_acc:.1f}%')
axes[0,1].set_title('Robot Branch - Accuracy')
axes[0,1].set_xlabel('Epoch'); axes[0,1].set_ylabel('Accuracy (%)')
axes[0,1].legend(); axes[0,1].grid(alpha=0.3)
# Thruster Loss
axes[1,0].plot(EX, hist['thruster_tr_loss'], 'darkgreen', lw=2)
axes[1,0].set_title('Thruster Branch - Training Loss')
axes[1,0].set_xlabel('Epoch'); axes[1,0].set_ylabel('Loss')
axes[1,0].grid(alpha=0.3)
# Thruster Acc
axes[1,1].plot(EX, hist['thruster_tr_acc'], 'darkgreen', lw=2, label='Train')
axes[1,1].plot(EX, hist['thruster_te_acc'], 'darkorange', lw=2, label='Test')
axes[1,1].axhline(best_thruster_acc, ls='--', color='purple', alpha=0.7, label=f'Best={best_thruster_acc:.1f}%')
axes[1,1].set_title('Thruster Branch - Accuracy')
axes[1,1].set_xlabel('Epoch'); axes[1,1].set_ylabel('Accuracy (%)')
axes[1,1].legend(); axes[1,1].grid(alpha=0.3)
plt.suptitle('Training History - Two-Stage KAN Diagnoser', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '01_training_curves.png', bbox_inches='tight')
plt.close()
print(f"  -> 01_training_curves.png")

# ── 图2: 两路混淆矩阵 ──────────────────────────────────────────────────────────
r_present = sorted(np.unique(r_labels))
t_present = sorted(np.unique(t_labels))
r_names = [ROBOT_SHORT.get(ROBOT_NAMES[i], ROBOT_NAMES[i]) for i in r_present]
t_names = [THRUSTER_SHORT.get(THRUSTER_NAMES[i], THRUSTER_NAMES[i]) for i in t_present]

fig, axes = plt.subplots(1, 2, figsize=(20, 8))

# Robot CM
r_cm = confusion_matrix(r_labels, r_preds, labels=r_present)
r_cm_n = r_cm.astype(float) / (r_cm.sum(axis=1, keepdims=True) + 1e-8)
sns.heatmap(r_cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=r_names, yticklabels=r_names,
            ax=axes[0], linewidths=0.5, annot_kws={'size': 9})
axes[0].set_xlabel('Predicted'); axes[0].set_ylabel('True')
axes[0].set_title(f'Robot Fault Detection CM  Acc: {r_acc_all:.1f}%')
axes[0].tick_params(axis='x', rotation=35)

# Thruster CM
t_cm = confusion_matrix(t_labels, t_preds, labels=t_present)
t_cm_n = t_cm.astype(float) / (t_cm.sum(axis=1, keepdims=True) + 1e-8)
sns.heatmap(t_cm_n, annot=True, fmt='.2f', cmap='Greens',
            xticklabels=t_names, yticklabels=t_names,
            ax=axes[1], linewidths=0.5, annot_kws={'size': 9})
axes[1].set_xlabel('Predicted'); axes[1].set_ylabel('True')
axes[1].set_title(f'Thruster Fault Localization CM  Acc: {t_acc_all:.1f}%')
axes[1].tick_params(axis='x', rotation=35)

plt.suptitle('Confusion Matrices - Two-Stage Diagnosis', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '02_confusion_matrices.png', bbox_inches='tight')
plt.close()
print(f"  -> 02_confusion_matrices.png")

# ── 图3: 特征空间可视化 ─────────────────────────────────────────────────────────
print("  Computing t-SNE...")
# Robot特征
model.eval()
with torch.no_grad():
    r_all_ds = UnifiedDataset(X_robot, y_robot, scaler=robot_scaler)
    r_all_loader = DataLoader(r_all_ds, batch_size=256, shuffle=False)
    r_feats, r_lbls = [], []
    for xb, yb in r_all_loader:
        logits = model.forward_robot(xb.to(DEVICE))
        # 取倒数第二层特征
        r_feats.append(model.robot_net(xb.to(DEVICE)).cpu().numpy())
        r_lbls.append(yb.numpy())
    r_feats = np.concatenate(r_feats)
    r_lbls = np.concatenate(r_lbls)

    t_all_ds = UnifiedDataset(X_thruster, y_thruster, scaler=thruster_scaler)
    t_all_loader = DataLoader(t_all_ds, batch_size=256, shuffle=False)
    t_feats, t_lbls = [], []
    for xb, yb in t_all_loader:
        t_f = model.thruster_norm1(model.thruster_kan1(xb.to(DEVICE)))
        t_f = F.gelu(t_f)
        t_f = model.thruster_norm2(model.thruster_kan2(t_f))
        t_f = F.gelu(t_f)
        t_feats.append(t_f.cpu().numpy())
        t_lbls.append(yb.numpy())
    t_feats = np.concatenate(t_feats)
    t_lbls = np.concatenate(t_lbls)

# t-SNE
tsne_r = TSNE(n_components=2, perplexity=min(30, len(r_feats)-1),
              random_state=42, n_iter=1000).fit_transform(r_feats)
tsne_t = TSNE(n_components=2, perplexity=min(30, len(t_feats)-1),
              random_state=42, n_iter=1000).fit_transform(t_feats)

fig, axes = plt.subplots(1, 2, figsize=(18, 8))
r_classes = sorted(np.unique(r_lbls))
for ci, lbl in enumerate(r_classes):
    mask = r_lbls == lbl
    axes[0].scatter(tsne_r[mask,0], tsne_r[mask,1],
                    label=ROBOT_SHORT.get(ROBOT_NAMES[lbl], ROBOT_NAMES[lbl]),
                    alpha=0.6, s=20, color=COLORS[ci%16])
axes[0].set_title('Robot Feature Space (t-SNE)')
axes[0].legend(fontsize=8, markerscale=1.5)
axes[0].set_xlabel('Dim 1'); axes[0].set_ylabel('Dim 2')
axes[0].grid(alpha=0.2)

t_classes = sorted(np.unique(t_lbls))
for ci, lbl in enumerate(t_classes):
    mask = t_lbls == lbl
    axes[1].scatter(tsne_t[mask,0], tsne_t[mask,1],
                    label=THRUSTER_SHORT.get(THRUSTER_NAMES[lbl], THRUSTER_NAMES[lbl]),
                    alpha=0.8, s=40, color=COLORS[ci%16])
axes[1].set_title('Thruster Feature Space (t-SNE)')
axes[1].legend(fontsize=9, markerscale=1.5)
axes[1].set_xlabel('Dim 1'); axes[1].set_ylabel('Dim 2')
axes[1].grid(alpha=0.2)

plt.suptitle('Feature Space Visualization', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '03_feature_tsne.png', bbox_inches='tight')
plt.close()
print(f"  -> 03_feature_tsne.png")

# ── 图4: 推进器故障位检测准确率 ────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# 各类别准确率
r_per_cls = [(r_preds[r_labels==l]==l).mean()*100 if (r_labels==l).sum()>0 else 0
              for l in r_present]
axes[0].bar(range(len(r_names)), r_per_cls,
            color=[COLORS[i%16] for i in range(len(r_names))],
            edgecolor='white')
axes[0].set_xticks(range(len(r_names)))
axes[0].set_xticklabels(r_names, rotation=30, ha='right', fontsize=10)
axes[0].set_ylim(0, 110)
axes[0].set_ylabel('Accuracy (%)')
axes[0].set_title(f'Robot - Per-Class Accuracy  ({r_acc_all:.1f}%)')
axes[0].axhline(r_acc_all, ls='--', color='gray', alpha=0.6)
axes[0].grid(axis='y', alpha=0.3)
for i, v in enumerate(r_per_cls):
    axes[0].text(i, v + 1, f'{v:.0f}%', ha='center', fontsize=9)

t_per_cls = [(t_preds[t_labels==l]==l).mean()*100 if (t_labels==l).sum()>0 else 0
              for l in t_present]
axes[1].bar(range(len(t_names)), t_per_cls,
            color=[COLORS[i%16] for i in range(len(t_names))],
            edgecolor='white')
axes[1].set_xticks(range(len(t_names)))
axes[1].set_xticklabels(t_names, rotation=30, ha='right', fontsize=10)
axes[1].set_ylim(0, 110)
axes[1].set_ylabel('Accuracy (%)')
axes[1].set_title(f'Thruster - Per-Class Accuracy  ({t_acc_all:.1f}%)')
axes[1].axhline(t_acc_all, ls='--', color='gray', alpha=0.6)
axes[1].grid(axis='y', alpha=0.3)
for i, v in enumerate(t_per_cls):
    axes[1].text(i, v + 1, f'{v:.0f}%', ha='center', fontsize=9)

plt.suptitle('Per-Class Accuracy Comparison', fontweight='bold', fontsize=14)
plt.tight_layout()
plt.savefig(OUT / '04_per_class_accuracy.png', bbox_inches='tight')
plt.close()
print(f"  -> 04_per_class_accuracy.png")

# ── 图5: 推进器故障位检测热力图 ────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(14, 6))
fault_true_t = np.array([fault_vec_thruster(l) for l in t_labels])
fault_pred_t = np.array([fault_vec_thruster(p) for p in t_preds])
combined = np.hstack([fault_true_t, fault_pred_t])  # (N, 8)
im = ax.imshow(combined.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
ax.set_yticks(range(len(t_labels)))
ax.set_yticklabels([f'S{i}' for i in range(len(t_labels))], fontsize=8)
ax.set_xticks(range(8))
ax.set_xticklabels([f'T{i+1}' for i in range(4)] + [f'T{i+1}' for i in range(4)], fontsize=10)
ax.axvline(3.5, color='black', lw=2)
ax.set_title('Thruster Fault Bitmap (True | Pred)  Green=No Fault, Red=Fault')
ax.set_xlabel('Thruster (Left=True, Right=Pred)')
plt.colorbar(im, ax=ax, shrink=0.8, ticks=[0, 1], label='Fault Status')
plt.tight_layout()
plt.savefig(OUT / '05_thruster_fault_bitmap.png', bbox_inches='tight')
plt.close()
print(f"  -> 05_thruster_fault_bitmap.png")

# ── 图6: 诊断汇总大图 ─────────────────────────────────────────────────────────
fig = plt.figure(figsize=(22, 18))
gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)

ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(EX, hist['robot_tr_acc'], 'royalblue', lw=2, label='Train')
ax1.plot(EX, hist['robot_te_acc'], 'tomato', lw=2, label='Test')
ax1.axhline(best_robot_acc, ls='--', color='green', alpha=0.7)
ax1.set_title('Robot Acc'); ax1.legend(); ax1.grid(alpha=0.3)
ax1.set_xlabel('Epoch'); ax1.set_ylabel('Acc (%)')

ax2 = fig.add_subplot(gs[0, 1])
ax2.plot(EX, hist['thruster_tr_acc'], 'darkgreen', lw=2, label='Train')
ax2.plot(EX, hist['thruster_te_acc'], 'darkorange', lw=2, label='Test')
ax2.axhline(best_thruster_acc, ls='--', color='purple', alpha=0.7)
ax2.set_title('Thruster Acc'); ax2.legend(); ax2.grid(alpha=0.3)
ax2.set_xlabel('Epoch'); ax2.set_ylabel('Acc (%)')

ax3 = fig.add_subplot(gs[0, 2])
thruster_names_short = [f'T{i+1}' for i in range(4)]
bars = ax3.bar(thruster_names_short, thruster_detect_acc,
               color=['#e74c3c' if a < 100 else '#2ecc71' for a in thruster_detect_acc],
               edgecolor='white')
for bar, v in zip(bars, thruster_detect_acc):
    ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
             f'{v:.0f}%', ha='center', fontsize=12, fontweight='bold')
ax3.set_ylim(0, 115)
ax3.set_ylabel('Detection Accuracy (%)')
ax3.set_title('Thruster Fault Detection Rate')
ax3.grid(axis='y', alpha=0.3)
ax3.axhline(100, ls='--', color='gray', alpha=0.5)

ax4 = fig.add_subplot(gs[1, :2])
sns.heatmap(r_cm_n, annot=True, fmt='.2f', cmap='Blues',
            xticklabels=r_names, yticklabels=r_names,
            ax=ax4, linewidths=0.5, annot_kws={'size': 9})
ax4.set_xlabel('Predicted'); ax4.set_ylabel('True')
ax4.set_title(f'Robot Fault Detection CM  ({r_acc_all:.1f}%)')
ax4.tick_params(axis='x', rotation=35)

ax5 = fig.add_subplot(gs[1, 2])
sns.heatmap(t_cm_n, annot=True, fmt='.2f', cmap='Greens',
            xticklabels=t_names, yticklabels=t_names,
            ax=ax5, linewidths=0.5, annot_kws={'size': 9})
ax5.set_xlabel('Predicted'); ax5.set_ylabel('True')
ax5.set_title(f'Thruster Localization CM  ({t_acc_all:.1f}%)')
ax5.tick_params(axis='x', rotation=35)

ax6 = fig.add_subplot(gs[2, 0])
for ci, lbl in enumerate(r_classes):
    mask = r_lbls == lbl
    ax6.scatter(tsne_r[mask,0], tsne_r[mask,1],
                label=ROBOT_SHORT.get(ROBOT_NAMES[lbl], ROBOT_NAMES[lbl]),
                alpha=0.5, s=15, color=COLORS[ci%16])
ax6.set_title('Robot t-SNE'); ax6.legend(fontsize=8, markerscale=1.5)
ax6.grid(alpha=0.2); ax6.set_xlabel('Dim1'); ax6.set_ylabel('Dim2')

ax7 = fig.add_subplot(gs[2, 1])
for ci, lbl in enumerate(t_classes):
    mask = t_lbls == lbl
    ax7.scatter(tsne_t[mask,0], tsne_t[mask,1],
                label=THRUSTER_SHORT.get(THRUSTER_NAMES[lbl], THRUSTER_NAMES[lbl]),
                alpha=0.7, s=30, color=COLORS[ci%16])
ax7.set_title('Thruster t-SNE'); ax7.legend(fontsize=8, markerscale=1.5)
ax7.grid(alpha=0.2); ax7.set_xlabel('Dim1'); ax7.set_ylabel('Dim2')

ax8 = fig.add_subplot(gs[2, 2])
im2 = ax8.imshow(combined.astype(float), cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=1)
ax8.set_yticks(range(len(t_labels)))
ax8.set_yticklabels([f'S{i}' for i in range(len(t_labels))], fontsize=7)
ax8.set_xticks(range(8))
ax8.set_xticklabels([f'T{i+1}' for i in range(4)] + [f'T{i+1}' for i in range(4)], fontsize=9)
ax8.axvline(3.5, color='black', lw=2)
ax8.set_title('Fault Bitmap (True|Pred)')
plt.colorbar(im2, ax=ax8, shrink=0.8)

fig.suptitle(
    f'Two-Stage KAN Fault Diagnosis System\n'
    f'Stage 1 (Robot): {r_acc_all:.1f}%  |  '
    f'Stage 2 (Thruster): {t_acc_all:.1f}%  |  '
    f'Thruster 1-4: {[f"{a:.0f}%" for a in thruster_detect_acc]}',
    fontsize=15, fontweight='bold'
)
plt.savefig(OUT / '00_summary.png', bbox_inches='tight')
plt.close()
print(f"  -> 00_summary.png")

# ── 保存模型 ──────────────────────────────────────────────────────────────────
torch.save({
    'model_state': best_state,
    'robot_scaler': robot_scaler,
    'thruster_scaler': thruster_scaler,
    'ROBOT_DIM': ROBOT_DIM,
    'THRUSTER_DIM': THRUSTER_DIM,
    'ROBOT_LABELS': ROBOT_LABELS,
    'THRUSTER_LABELS': THRUSTER_LABELS,
    'ROBOT_NAMES': ROBOT_NAMES,
    'THRUSTER_NAMES': THRUSTER_NAMES,
    'best_robot_acc': r_acc_all,
    'best_thruster_acc': t_acc_all,
    'thruster_detect_acc': thruster_detect_acc,
}, OUT / 'best_model.pt')
print(f"  -> best_model.pt")

# ═══════════════════════════════════════════════════════════════════════════════
# 6. 逐文件诊断演示
# ═══════════════════════════════════════════════════════════════════════════════
print("\n[Stage 6] File-level diagnosis demonstration...")

print("\n  === Robot (Whole Machine) Test Files ===")
model.eval()
with torch.no_grad():
    # Robot test files
    for xr, yr in robot_te:
        xr, yr = xr.to(DEVICE), yr.to(DEVICE)
        logits = model.forward_robot(xr)
        probs = torch.softmax(logits, dim=1).cpu().numpy()
        preds = logits.argmax(1).cpu().numpy()
        for i in range(len(preds)):
            true_cls = ROBOT_NAMES[int(yr[i].item())]
            pred_cls = ROBOT_NAMES[preds[i]]
            conf = probs[i].max() * 100
            ok = "OK" if preds[i] == yr[i].item() else "NG"
            print(f"  [{ok}]  True={ROBOT_SHORT[true_cls]:10s}  "
                  f"Pred={ROBOT_SHORT[pred_cls]:10s}  Conf={conf:.0f}%")

print("\n  === Thruster (Propulsion System) Test Files ===")
with torch.no_grad():
    for xt, yt in thruster_te:
        xt, yt = xt.to(DEVICE), yt.to(DEVICE)
        logits = model.forward_thruster(xt)
        probs = torch.softmax(logits, dim=1).cpu().numpy()
        preds = logits.argmax(1).cpu().numpy()
        for i in range(len(preds)):
            true_cls = THRUSTER_NAMES[int(yt[i].item())]
            pred_cls = THRUSTER_NAMES[preds[i]]
            conf = probs[i].max() * 100
            true_closed = fault_vec_thruster(yt[i].item())
            pred_closed = fault_vec_thruster(preds[i])
            ok = "OK" if preds[i] == yt[i].item() else "NG"
            print(f"  [{ok}]  True={THRUSTER_SHORT[true_cls]:15s}  "
                  f"Pred={THRUSTER_SHORT[pred_cls]:15s}  "
                  f"Closed_T={[i+1 for i,v in enumerate(true_closed) if v==1]}  "
                  f"Closed_P={[i+1 for i,v in enumerate(pred_closed) if v==1]}  "
                  f"Conf={conf:.0f}%")

print(f"\n{'='*60}")
print(f"  Training complete!")
print(f"  Robot Acc:     {r_acc_all:.1f}%")
print(f"  Thruster Acc:  {t_acc_all:.1f}%")
print(f"  Thruster 1-4:  {[f'{a:.0f}%' for a in thruster_detect_acc]}")
print(f"  Output:        {OUT}")
print(f"{'='*60}")
