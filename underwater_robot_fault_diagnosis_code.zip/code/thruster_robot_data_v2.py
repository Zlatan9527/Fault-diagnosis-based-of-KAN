"""
推进器故障诊断 - 机器人数据加载模块 v2
========================================
核心改进：对每行提取特征+滑动窗口扩充
诊断8个推进器（垂推1-4，侧推1-4）
"""

import os, sys
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from pathlib import Path
from typing import Tuple, List, Optional
import warnings
warnings.filterwarnings('ignore')

# ── 推进器定义 ────────────────────────────────────────────────────────────────
THRUSTER_NAMES = ['垂推1', '垂推2', '垂推3', '垂推4', '侧推1', '侧推2', '侧推3', '侧推4']

# ── 标签定义 ────────────────────────────────────────────────────────────────
FAULT_LABELS = {
    'normal':       0,
    'fault_1':      1,
    'fault_12':     2,
    'fault_13':     3,
    'fault_123':    4,
    'push_normal':  5,
    'push_fault_1': 6,
    'push_fault_12':7,
    'push_fault_13':8,
}
FAULT_NAMES  = {v: k for k, v in FAULT_LABELS.items()}
NUM_CLASSES  = len(FAULT_LABELS)

BASE_DING = Path(r'E:\范小龙\数据\数据\定向数据')
BASE_QIAN = Path(r'E:\范小龙\数据\数据\手柄前推数据')

DING_MAP = {
    '2025-01-05_17-26-54': 'normal',
    '2025-01-05_17-29-52': 'fault_1',
    '2025-01-05_17-32-17': 'fault_12',
    '2025-01-05_17-34-39': 'fault_12',
    '2025-01-05_17-36-18': 'fault_13',
    '2025-01-05_17-41-23': 'fault_123',
}
QIAN_MAP = {
    '2025-01-05_17-45-03': 'push_normal',
    '2025-01-05_18-00-14': 'push_fault_12',
    '2025-01-05_18-02-16': 'push_fault_13',
}


# ── 读取 ──────────────────────────────────────────────────────────────────────
def read_excel_safe(fpath: str) -> Optional[pd.DataFrame]:
    if os.path.basename(fpath).startswith('~$'):
        return None
    try:
        df = pd.read_excel(str(fpath))
        df = df.apply(pd.to_numeric, errors='coerce').dropna()
        return df if df.shape[0] >= 5 else None
    except Exception:
        return None


# ── 单行特征 ──────────────────────────────────────────────────────────────────
def row_feature(cols: np.ndarray) -> np.ndarray:
    """
    对单行（1×8推进器值）提取特征向量。
    8推进器 × 14特征 = 112
    """
    feats = []
    for i, val in enumerate(cols[:8]):  # 只用前8列（垂推1-4，侧推1-4）
        x = float(val)
        abs_x = abs(x)
        feats.extend([
            x,                      # 原始值
            abs_x,                  # 绝对值
            1.0 if abs_x > 5 else 0.0,  # 是否活跃(1=活跃,0=关闭)
            0.0,                    # 预留
        ])
    return np.array(feats, dtype=np.float32)  # 32维


# ── 滑动窗口特征（核心扩充函数）─────────────────────────────────────────────
def window_features(df: pd.DataFrame, window: int, step: int) -> np.ndarray:
    """
    对每个时间窗口提取统计特征。

    Args:
        df: DataFrame, 每行一个时刻, 列=推进器
        window: 窗口大小
        step: 步长
    Returns:
        (N, D) 特征矩阵
    """
    vals = df[THRUSTER_NAMES].values.astype(np.float32)  # (T, 8)
    T = len(vals)
    if T < window:
        # 数据不足则补零
        pad = np.zeros((window - T, 8), dtype=np.float32)
        vals = np.vstack([vals, pad])

    feats_list = []
    for start in range(0, len(vals) - window + 1, step):
        win = vals[start:start+window]  # (window, 8)
        row_feats = []

        for ch in range(8):
            x = win[:, ch]
            x_nonzero = np.where(np.abs(x) > 5, x, 0)
            nonzero_count = np.sum(np.abs(x) > 5)

            # 统计
            row_feats.extend([
                np.mean(x), np.std(x),
                np.max(np.abs(x)),
                np.sqrt(np.mean(x**2)),
                np.mean(np.abs(x)),
                np.max(np.abs(x)) / (np.sqrt(np.mean(x**2)) + 1e-8),  # 峰值因子
                np.mean((x-np.mean(x))**3) / (np.std(x)**3+1e-8),     # 偏度
                np.mean((x-np.mean(x))**4) / (np.std(x)**4+1e-8),     # 峭度
                np.min(x), np.max(x) - np.min(x),                    # 最小,峰峰值
                np.percentile(x, 25), np.percentile(x, 75),          # Q1,Q3
                nonzero_count / window,                               # 活跃比例
                np.mean(x_nonzero),                                   # 非零均值
                np.sum(np.sign(x[x<0])), np.sum(np.sign(x[x>0])),    # 正/负数个数
            ])

        # ── 结构化特征（跨通道组合）──────────────────────────────────────
        v_means = win[:, :4].mean(axis=0)   # 垂推1-4均值

        # 符号模式
        signs = np.sign(v_means)             # +1/-1/0
        row_feats.extend(signs.tolist())     # 4维

        # 故障位图
        fault_bmp = (np.abs(v_means) < 5).astype(float)  # 1=故障
        row_feats.extend(fault_bmp.tolist())             # 4维

        # 活跃数
        row_feats.append(np.sum(np.abs(v_means) >= 5))   # 1维

        # 推力差值（6对）
        for i in range(4):
            for j in range(i+1, 4):
                row_feats.append(v_means[j] - v_means[i])
        # 推力比值（6对）
        for i in range(4):
            for j in range(i+1, 4):
                row_feats.append(v_means[i] / (v_means[j] + 1e-8))
        # 推力和
        row_feats.extend([
            np.sum(v_means),                                 # 总和
            np.sum(np.abs(v_means)),                          # 总绝对值
            np.abs(v_means[0]+v_means[1]),                   # |垂1+垂2|
            np.abs(v_means[2]+v_means[3]),                   # |垂3+垂4|
            np.abs(v_means[0]+v_means[3]),                   # |垂1+垂4|
            np.abs(v_means[1]+v_means[2]),                   # |垂2+垂3|
        ])
        # 正负比
        neg = np.sum(v_means[v_means<0])
        pos = np.sum(v_means[v_means>0])
        row_feats.extend([neg, pos, neg/(pos+1e-8)])         # 3维

        # ── 控制上下文 ─────────────────────────────────────────────────
        ctrl_cols = ['深度', '航向', '俯仰', '横滚']
        for col in ctrl_cols:
            if col in df.columns:
                cx = df[col].values.astype(np.float32)
                row_feats.extend([np.mean(cx), np.std(cx)])
            else:
                row_feats.extend([0.0, 0.0])

        feats_list.append(np.array(row_feats, dtype=np.float32))

    return np.stack(feats_list)  # (N, D)


# ── 主加载函数 ────────────────────────────────────────────────────────────────
def load_robot_dataset(window: int = 5, step: int = 1) -> Tuple[np.ndarray, np.ndarray]:
    X_list, y_list = [], []

    for fname, fkey, base in [
        *[(f, k, BASE_DING) for f, k in DING_MAP.items()],
        *[(f, k, BASE_QIAN) for f, k in QIAN_MAP.items()],
    ]:
        fpath = base / f'{fname}.xlsx'
        if not fpath.exists(): continue
        df = read_excel_safe(str(fpath))
        if df is None: continue

        feat_win = window_features(df, window=window, step=step)
        X_list.append(feat_win)
        y_list.append(np.full(len(feat_win), FAULT_LABELS[fkey], dtype=np.int64))

        v_means = df[['垂推1','垂推2','垂推3','垂推4']].mean().values
        closed = [i+1 for i, v in enumerate(v_means) if abs(v) < 5]
        print(f'  [{fkey[:2]}  ] {fname} -> {fkey:15s}  样本={len(feat_win):3d}  关闭垂推: {closed}')

    X = np.concatenate(X_list, axis=0).astype(np.float32)
    y = np.concatenate(y_list, axis=0)
    X = np.nan_to_num(X, nan=0.0, posinf=1e6, neginf=-1e6)

    print(f'\n[总计] X={X.shape}  y={y.shape}')
    for lbl in sorted(np.unique(y)):
        print(f'  {FAULT_NAMES[lbl]:20s} (id={lbl}): {(y==lbl).sum():4d}')
    return X, y


# ── PyTorch Dataset ──────────────────────────────────────────────────────────
class RobotDataset(Dataset):
    def __init__(self, X, y, scaler=None, fit=False):
        if fit:
            scaler = StandardScaler()
            Xs = scaler.fit_transform(X)
        else:
            Xs = scaler.transform(X) if scaler else X
        self.X = torch.tensor(Xs, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)
        self.scaler = scaler
    def __len__(self): return len(self.y)
    def __getitem__(self, i): return self.X[i], self.y[i]
    @property
    def feat_dim(self): return self.X.shape[1]


def build_loaders(X, y, batch_size=16, test_ratio=0.2, seed=42):
    torch.manual_seed(seed); np.random.seed(seed)
    idx = np.random.permutation(len(X))
    n_test = max(1, int(len(X)*test_ratio))
    tr, te = idx[n_test:], idx[:n_test]
    ds = RobotDataset(X, y, fit=True)
    scaler = ds.scaler
    return (DataLoader(RobotDataset(X[tr], y[tr], scaler=scaler), batch_size=batch_size, shuffle=True),
            DataLoader(RobotDataset(X[te], y[te], scaler=scaler),  batch_size=batch_size, shuffle=False),
            scaler, ds.feat_dim)


if __name__ == '__main__':
    X, y = load_robot_dataset(window=5, step=1)
    print(f'\nFeature dim: {X.shape[1]}')
